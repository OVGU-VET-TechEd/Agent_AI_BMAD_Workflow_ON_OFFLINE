# Project Proposal Workflow System

This workflow system helps you develop comprehensive project proposals using AI agents.

## Overview

Five specialized agents work together to create a complete project proposal:

1. **Overseer Agent** - Coordinates the entire proposal development process
2. **Info Page Agent** - Creates concise 1-page project summary
3. **Outline Agent** - Develops full project proposal based on funding call
4. **Work Package Agent** - Defines detailed work packages and deliverables
5. **Budget Agent** - Calculates staff costs and project budget

## Directory Structure

```
project-proposal-workflow/
├── call/                    # Place your funding call documents here
│   └── [your-call].pdf
├── docs/                    # Generated proposal documents
│   ├── project-info-page.md
│   ├── project-outline.md
│   ├── work-packages.md
│   └── budget-calculation.md
├── templates/               # YAML templates for each component
├── tasks/                   # Task definitions for each agent
├── examples/                # Example outputs
└── skeletons/              # Skeleton/draft documents
```

## Workflow Steps

1. **Place call document** in `call/` directory
2. **Run overseer task**: Analyzes call and creates project strategy
3. **Run info-page task**: Creates 1-page project summary
4. **Run outline task**: Develops complete proposal outline
5. **Run work-packages task**: Defines WPs, tasks, and deliverables
6. **Run budget task**: Calculates costs and creates budget

## Getting Started

1. Add your funding call document to `call/` directory
2. Review templates in `templates/` for customization
3. Start with task: `/overseer-analysis`
4. Follow the sequential workflow through all agents

## Agent Handoffs

Each agent builds on previous outputs:
- Overseer → Info Page (strategic direction)
- Info Page → Outline (core objectives and scope)
- Outline → Work Packages (detailed structure)
- Work Packages → Budget (resource requirements)

Happy proposal writing! 📝
