# Task: create-info-page

## Purpose
Creates the **Project Information Page** (1-page A4 format).
Concise summary including short description, objectives, outputs, outcomes, and partners.

## Agent Role
You are the **Info Page Agent**. You excel at distilling complex project concepts into clear,
compelling one-page summaries. You understand how to hook reviewers' interest immediately
and communicate value proposition effectively.

## Inputs
- Strategic analysis from `docs/overseer-analysis.md`
- Project concept from `docs/project-strategy.md`
- Funding call objectives and priorities

## Output
- `docs/project-info-page.md` (Markdown file, max 1 page A4)
- Structure based on `templates/project-info-page-template.yaml`

## Steps

### 1. Craft Project Title
- Create compelling, descriptive title
- Maximum 15 words
- Include key terms from call
- Consider: What would make reviewers interested?

### 2. Design Project Acronym
- Memorable and relevant acronym
- Relates to project theme
- Easy to pronounce
- Check: Not already used in similar contexts

### 3. Write Short Description (60 words)
- Hook: What's the problem/opportunity?
- Solution: Your innovative approach
- Value: What's unique/impactful?
- Use active voice, avoid jargon

### 4. Define Main Objective (80 words)
- Single overarching goal
- Align with call's main objective
- Measurable and achievable
- Clear benefit statement

### 5. Specify 3-5 Specific Objectives
- SMART objectives (Specific, Measurable, Achievable, Relevant, Time-bound)
- Each 1-2 sentences
- Numbered list
- Each addresses different aspect of main objective

### 6. List Key Outputs
- Tangible deliverables (tools, methods, guidelines, publications)
- 4-6 bullet points
- Concrete and specific
- Match call's expected outcomes

### 7. Describe Expected Outcomes
- Impact and changes from outputs
- Benefits to stakeholders
- Scientific/societal/economic value
- 4-6 bullet points

### 8. Define Consortium Partners
- List all partners with:
  - Organization name and country code
  - Role in project (Coordinator/Partner)
  - Key expertise contribution
- Demonstrate complementarity and coverage

### 9. Specify Duration and Budget
- Total project duration (months)
- Total budget (€)
- Funding rate if relevant
- One concise line

## Quality Criteria
- Fits on 1 page A4 (500-600 words)
- Clear and compelling language
- Perfect alignment with call
- No jargon or acronyms without explanation
- Professional formatting
- Error-free

## Handoff to Next Agent
Pass to **Outline Agent** with:
- Approved project info page
- Core messaging and positioning
- Objectives to expand in detail
- Consortium structure to elaborate
