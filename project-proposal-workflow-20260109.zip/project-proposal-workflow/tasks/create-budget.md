# Task: create-budget

## Purpose
Creates **Detailed Budget Calculation** with staff costs, travel, equipment, and other costs.
Transforms person-month allocations into comprehensive financial plan.

## Agent Role
You are the **Budget Agent**. You are an expert in research project financial planning
and EU/research funding rules. You create accurate, justified, and compliant budgets
that optimize resource use while meeting all project needs.

## Inputs
- Work packages from `docs/work-packages.md` (PM allocations)
- Project outline from `docs/project-outline.md`
- Funding call budget rules and eligible costs
- Partner cost information (hourly rates, overhead rates)

## Output
- `docs/budget-calculation.md` (Detailed budget, 8-12 pages)
- Structure based on `templates/budget-calculation-template.yaml`
- Excel spreadsheet: `docs/budget-detailed.xlsx` (optional but recommended)

## Steps

### 1. Understand Funding Rules
From call document, extract:
- Eligible cost categories
- Funding rate (e.g., 100%, 70%, or other)
- Overhead calculation method (typically 25% of direct costs)
- Specific restrictions (max amounts, categories)
- Audit and compliance requirements

### 2. Budget Summary Table
Create overview:
```markdown
| Partner | Personnel | Travel | Equipment | Other | Subtotal | Indirect (25%) | Total | Funding |
|---------|-----------|--------|-----------|-------|----------|----------------|-------|---------|
| P1 (Lead) | €180,000 | €15,000 | €20,000 | €10,000 | €225,000 | €56,250 | €281,250 | €281,250 |
| P2 | €200,000 | €12,000 | €0 | €8,000 | €220,000 | €55,000 | €275,000 | €275,000 |
| ... | | | | | | | | |
| **Total** | €XXX | €XXX | €XXX | €XXX | €XXX | €XXX | €XXX | €XXX |
```

### 3. Personnel Costs

#### 3.1 Define Staff Categories per Partner
```markdown
**Partner 1: [Organization Name]**
- Professor/Senior Researcher: €75/hour
- Researcher (Postdoc): €55/hour
- PhD Student: €30/hour
- Project Manager: €65/hour
- Technician: €40/hour

[Basis: Institutional rates, national standards, or certified cost methodology]
```

#### 3.2 Person-Month Breakdown Table
```markdown
| WP | Role | P1 | P2 | P3 | Total PM |
|----|------|----|----|----|----- |
| WP1 | PM | 6 | 2 | - | 8 |
| WP1 | Admin | 2 | - | - | 2 |
| WP2 | Senior Res | 8 | 10 | 12 | 30 |
| WP2 | PhD | 6 | 12 | 18 | 36 |
| ... | | | | | |
```

#### 3.3 Personnel Cost Calculation
For each partner:
```markdown
**Partner 1 Personnel Costs:**

| Staff Category | PM | Hours/PM | Rate (€/h) | Total (€) |
|----------------|----|---------|-----------| ---------|
| Senior Researcher | 14 | 140 | 75 | 147,000 |
| Researcher | 8 | 140 | 55 | 61,600 |
| PhD Student | 18 | 140 | 30 | 75,600 |
| Project Manager | 8 | 140 | 65 | 72,800 |
| **Subtotal Personnel P1** | **48** | | | **€357,000** |

Calculation: PM × 140 hours/PM × hourly rate
(Note: Standard 1 PM = 140 productive hours, or as per call rules)
```

### 4. Travel and Subsistence

#### 4.1 Project Meetings
```markdown
**Consortium Meetings**
- Number of meetings: 6 (one every 6 months)
- Participants per meeting: Average 2 per partner × 5 partners = 10
- Cost per participant: €800 (€600 travel + €200 accommodation/meals)
- Total: 6 × 10 × €800 = €48,000

Breakdown by partner:
- P1: €9,600 (2 people × 6 meetings × €800)
- P2: €9,600
- ...
```

#### 4.2 Conferences and Dissemination
```markdown
**Conference Participation**
- Number of conferences: 8 (2 per year, different partners)
- Average cost: €1,500 per conference (registration €500 + travel/stay €1,000)
- Total: 8 × €1,500 = €12,000

- P1: €4,500 (3 conferences)
- P2: €4,500 (3 conferences)
- P3: €3,000 (2 conferences)
```

#### 4.3 Research Visits/Secondments
If applicable:
```markdown
**Research Visits**
- PhD exchange between P2 and P3: 1 month
- Cost: €2,500 (travel + subsistence)
```

**Total Travel Budget: €XX,XXX**

### 5. Equipment and Infrastructure

List major items (typically >€1,000):
```markdown
**Partner 1:**
- High-performance Computing Server: €15,000
  - Justification: Required for data processing in WP3
  - Specifications: [details]
  - Depreciation: If >€5,000, may need to calculate depreciation
  
- Specialized Software Licenses: €5,000
  - Justification: Analysis tools for WP4 and WP5

**Partner 2:**
- Laboratory Equipment: €25,000
  - Justification: Testing and validation in WP6
  - [Details]

**Total Equipment: €45,000**

Note: Only direct project use. General office equipment not eligible.
```

### 6. Other Direct Costs

#### 6.1 Consumables
```markdown
**Consumables and Supplies**
- Lab materials (P2): €8,000 over 36 months
- Office supplies (all partners): €3,000
- Printing and copying: €2,000
**Total Consumables: €13,000**
```

#### 6.2 Subcontracting
```markdown
**Subcontracting Services**
- User testing and validation (external company): €20,000
  - Justification: Specialized expertise not available in consortium
  - WP5, M18-M24
  
- Professional translation services: €5,000
  - Justification: Dissemination materials in 5 languages

**Total Subcontracting: €25,000**

Note: Subcontracting must be justified (expertise not in consortium) 
and should not exceed 25-30% of direct costs.
```

#### 6.3 Other Costs
```markdown
**Publication Costs**
- Open Access publications: €10,000 (5 articles × €2,000 average APC)
- Conference proceedings: €3,000

**Audit Costs** (if required):
- External audit (if total >€750k): €15,000

**Ethics and Legal**
- Ethics board reviews: €3,000
- Legal advice on IPR: €5,000

**Total Other Costs: €XX,XXX**
```

### 7. Indirect Costs (Overheads)

```markdown
**Indirect Costs Calculation**

Indirect costs cover:
- General administration
- Premises (heating, electricity, rent)
- IT infrastructure
- Libraries
- Human resources departments
- Finance and accounting

Calculation: 25% of direct eligible costs (standard EU rate)

| Partner | Direct Costs | Indirect (25%) | Total |
|---------|-------------|----------------|-------|
| P1 | €450,000 | €112,500 | €562,500 |
| P2 | €380,000 | €95,000 | €475,000 |
| ... | | | |
| **Total** | €X,XXX,XXX | €XXX,XXX | €X,XXX,XXX |

Note: Some funding schemes use different overhead rates or calculation methods.
Check call-specific rules.
```

### 8. Total Budget Summary

```markdown
## Final Budget Summary

| Cost Category | Amount (€) | % of Total |
|---------------|-----------|------------|
| Personnel | 1,200,000 | 65% |
| Travel | 65,000 | 4% |
| Equipment | 45,000 | 2% |
| Other Direct | 85,000 | 5% |
| **Subtotal Direct** | **1,395,000** | **76%** |
| Indirect (25%) | 348,750 | 24% |
| **TOTAL** | **1,743,750** | **100%** |

**Requested Funding**: €1,743,750 (100% funding rate)

Distribution by Partner:
- P1 (Coordinator): €562,500 (32%)
- P2: €475,000 (27%)
- P3: €380,000 (22%)
- P4: €326,250 (19%)
```

### 9. Budget Justification Narrative

For each major budget category, explain:
- **Why necessary**: How does it support project objectives?
- **Realism**: Are costs realistic and competitive?
- **Efficiency**: Are resources used optimally?
- **Compliance**: Do costs meet funding rules?

Example:
```markdown
## Budget Justification

### Personnel Costs (€1,200,000 - 69% of direct costs)
The personnel budget reflects the high intellectual input required for this research project.
The allocation of 112 person-months across 36 months ensures adequate expertise while maintaining
cost-efficiency. Senior researchers (30% of PM) provide scientific leadership and methodology
development, while PhD students (40% of PM) conduct core research activities. Project management
(8% of PM) ensures effective coordination. All rates are based on certified institutional cost models.

### Travel (€65,000)
Travel budget supports essential collaboration (semi-annual consortium meetings) and dissemination
(conference presentations of results). The project's international nature requires face-to-face
coordination to ensure quality. Conference presentations are crucial for scientific validation
and impact. Costs are calculated conservatively based on average EU travel expenses.

[Continue for each category...]
```

### 10. Cost-Effectiveness Analysis

```markdown
## Cost-Effectiveness

- **Cost per expected output**: €XXX,XXX per major deliverable
- **Benchmarking**: Compared to similar projects, budget is X% lower/comparable
- **Value for money**: Expected impact justifies investment
- **Efficiency measures**:
  - Use of existing infrastructure where possible
  - Shared resources across WPs
  - Leveraging partner in-kind contributions
  - Open-source tools to minimize licensing costs
```

### 11. Budget Compliance Checklist

```markdown
## Compliance with Funding Rules

- ✓ All costs are eligible per call guidelines
- ✓ Costs are necessary and reasonable
- ✓ Costs are actual (not estimated without basis)
- ✓ Costs are identifiable and verifiable
- ✓ No double funding with other grants
- ✓ Overhead rate compliant (25% or as specified)
- ✓ Subcontracting justified and within limits
- ✓ Equipment depreciation correctly calculated
- ✓ Personnel costs based on certified methodology
- ✓ Audit trail documentation available
```

## Quality Criteria
- Accurate calculations (no errors)
- Realistic cost estimates
- Complete justification
- Full compliance with funding rules
- Clear presentation
- Consistent with work packages
- Optimal resource allocation
- Professional formatting

## Final Deliverables
1. Budget narrative document (markdown)
2. Detailed budget tables
3. Optional: Excel spreadsheet with calculations
4. Budget justification integrated into proposal

## Integration Note
This budget must be perfectly aligned with:
- Work package person-month allocations
- Project timeline and activities
- Partnership agreements
- Call budget limits and rules
