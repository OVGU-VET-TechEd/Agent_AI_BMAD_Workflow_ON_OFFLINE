# Task: create-outline

## Purpose
Creates the **Complete Project Proposal Outline**.
Develops full proposal structure based on funding call requirements.

## Agent Role
You are the **Outline Agent**. You are an expert proposal writer with deep knowledge of
research funding mechanisms. You create comprehensive, well-structured proposals that
address all evaluation criteria and tell a compelling story.

## Inputs
- Project info page from `docs/project-info-page.md`
- Funding call document from `call/`
- Strategic analysis from `docs/overseer-analysis.md`
- Call-specific proposal template/structure

## Output
- `docs/project-outline.md` (Complete proposal outline, 15-25 pages)
- Structure based on `templates/project-outline-template.yaml`
- Adapted to specific call requirements

## Steps

### 1. Call Structure Analysis
- Identify required proposal sections from call
- Note page limits per section
- Map evaluation criteria to sections
- Understand scoring/weighting

### 2. Executive Summary
- Comprehensive overview (1-2 pages)
- Cover: Context, approach, innovation, impact, consortium
- Can stand alone - reviewers may read only this
- Write LAST (after all other sections)

### 3. Section 1: Context and Challenge
**1.1 Background**
- State of the art in field
- Current approaches and limitations
- Market/policy context if relevant

**1.2 Problem Statement**
- Clear articulation of problem
- Why is it important? Who is affected?
- Quantify impact of problem if possible

**1.3 Relevance to Call**
- Direct mapping to call priorities
- Quote specific call objectives
- Show perfect fit

### 4. Section 2: Objectives and Approach
**2.1 Overall Objective**
- Single main goal
- Aligned with call's overall objective
- Ambitious yet achievable

**2.2 Specific Objectives**
- 3-6 SMART objectives
- Each linked to call priorities
- Logical progression

**2.3 Methodology and Approach**
- How will objectives be achieved?
- Methods, frameworks, standards
- Work flow and interdependencies
- Innovation in methodology

**2.4 Innovation and Beyond State-of-Art**
- What's novel in your approach?
- How does it advance beyond current practice?
- Breakthrough potential
- Risk and ambition

### 5. Section 3: Impact and Dissemination
**3.1 Expected Impact**
- Scientific impact: Publications, new knowledge
- Societal impact: Benefits to society
- Economic impact: Market potential, efficiency gains
- Map to call's expected impacts

**3.2 Target Groups and Stakeholders**
- Who will benefit?
- How will they be engaged?
- Letters of support if required

**3.3 Dissemination and Exploitation**
- Communication strategy
- Publication plan (Open Access)
- IP management and exploitation
- Sustainability after project

**3.4 Sustainability**
- How will results persist?
- Business model if relevant
- Scaling potential

### 6. Section 4: Consortium and Resources
**4.1 Partner Overview**
- 1-2 paragraphs per partner
- Expertise, track record, facilities
- Specific role in project

**4.2 Expertise and Complementarity**
- Coverage of all needed expertise
- No gaps or overlaps
- Synergies and added value

**4.3 Management Structure**
- Governance bodies (Steering Committee, etc.)
- Decision-making processes
- Coordination mechanisms
- Communication plan

### 7. Section 5: Work Plan (High-Level)
- Overview of work package structure
- Gantt chart or timeline
- Dependencies and critical path
- Note: Detailed WPs in separate document

### 8. Section 6: Budget Overview
- Total budget and breakdown by category
- Budget per partner
- Cost-effectiveness narrative
- Note: Detailed budget in separate document

### 9. Section 7: Risks and Quality
**7.1 Risk Analysis**
- Identify 5-8 key risks
- For each: description, probability, impact, mitigation
- Show proactive management

**7.2 Quality Assurance**
- Quality standards to be applied
- Review processes
- Validation methods

### 10. Section 8: Ethics and Data
**8.1 Ethical Considerations**
- Ethics self-assessment
- Issues identified and how addressed
- Ethics approvals needed

**8.2 Data Management**
- FAIR data principles
- Data Management Plan outline
- Security and privacy
- Open data commitments

## Quality Criteria
- Complete coverage of all call requirements
- Compelling narrative flow
- Clear alignment with evaluation criteria
- Professional, error-free writing
- Appropriate use of figures/tables
- Within page limits
- Consistent with info page

## Handoff to Next Agent
Pass to **Work Package Agent** with:
- Approved outline
- Work package structure (number and titles)
- Objectives to be distributed across WPs
- Deliverables and milestones framework
