# Work Package 2: Learning Content Development

**Lead Partner**: P2 - Polytechnic University of Madrid  
**Duration**: Month 6 - Month 30  
**Total Person-Months**: 68 PM

## Participating Partners
- P1: Technical University of Berlin (18 PM)
- P2: Polytechnic University of Madrid - Lead (25 PM)
- P3: National Association Construction SMEs Poland (8 PM)
- P5: Italian Construction Training Institute (15 PM)
- P6: Digital Skills Europe Foundation (2 PM)

## Objectives
1. Develop comprehensive, modular training content covering 4 key digital technology areas relevant to construction SMEs
2. Ensure content is pedagogically sound, industry-validated, and adaptable to different learning contexts and prior knowledge levels
3. Create content in formats optimized for AI-powered personalization and adaptive learning pathways
4. Produce content in 6 European languages with cultural and regional adaptations

## Description of Work
WP2 focuses on creating the intellectual foundation of the DigiConstruct platform: high-quality, engaging learning content that addresses real construction sector needs while being optimized for AI-driven personalization. Content development follows a co-creation methodology involving educational experts, industry practitioners, and technology specialists.

The work is organized around four technology clusters: (1) Building Information Modeling (BIM), (2) Internet of Things (IoT) for construction monitoring, (3) Data analytics for project management, and (4) Augmented/Virtual Reality (AR/VR) for safety and training. Each cluster comprises 30+ hours of structured learning content including video lectures, interactive simulations, case studies, practical exercises, and assessments.

Content is designed following Universal Design for Learning (UDL) principles to accommodate diverse learner needs, backgrounds, and learning preferences. Metadata tagging enables the AI algorithms developed in WP3 to effectively map content to learner profiles and dynamically adjust learning paths.

## Tasks

### Task 2.1: Needs Analysis and Learning Objectives Definition
**Lead**: P2 | **Contributing**: P1, P3, P5  
**Duration**: M6-M12

Conduct comprehensive analysis of digital skills gaps in construction SMEs through:
- Literature review of construction sector digitalization trends
- Survey of 200+ SME employees on current competencies and training needs
- Focus groups with 6 SME clusters (2 per pilot country)
- Expert consultations with technology vendors and industry associations

Deliverables from this task feed into precise learning objective formulation for each technology cluster, ensuring content directly addresses industry-identified needs while aligning with European Digital Competence Framework (DigComp) standards.

**Dependencies**: Initial platform design from WP3 (to understand technical constraints)

### Task 2.2: Instructional Design Framework
**Lead**: P1 | **Contributing**: P2, P5  
**Duration**: M8-M14

Develop comprehensive instructional design framework including:
- Pedagogical model adapted for adult learners in workplace contexts
- Content structure templates for different content types
- Assessment design principles and item banks
- Multimedia production guidelines
- Accessibility and inclusion standards
- AI-readiness specifications (metadata schemas, granularity standards)

Framework reviewed by external advisory board including adult education experts and construction industry representatives.

**Dependencies**: Learning objectives from Task 2.1

### Task 2.3: BIM Content Development
**Lead**: P2 | **Contributing**: P5  
**Duration**: M12-M24

Create comprehensive BIM training content (30 hours) covering:
- BIM fundamentals and industry standards (ISO 19650)
- Software tools (Revit, ArchiCAD - tool-agnostic where possible)
- Collaborative workflows and coordination
- Quantity take-off and cost estimation from BIM
- 4D/5D BIM applications
- Mobile BIM and on-site usage

Content includes 15 video lectures, 20 interactive exercises, 8 case studies based on real projects, and 5 simulation-based challenges. All content produced in English, Spanish, and Italian with professional translation.

### Task 2.4: IoT and Sensor Technology Content
**Lead**: P1 | **Contributing**: P2  
**Duration**: M12-M24

Develop IoT training module (25 hours) addressing:
- Sensor types and applications in construction (temperature, humidity, vibration, progress monitoring)
- Data collection and wireless transmission protocols
- Real-time monitoring dashboards
- Predictive maintenance applications
- Integration with project management systems

Includes hands-on exercises with affordable IoT kits that SMEs can replicate, video demonstrations from real construction sites, and troubleshooting guides.

### Task 2.5: Data Analytics Content Creation
**Lead**: P1 | **Contributing**: P3  
**Duration**: M14-M26

Produce data analytics module (35 hours) covering:
- Construction data types and sources
- Data cleaning and preparation
- Descriptive analytics and visualization
- Introduction to predictive analytics for planning
- Key Performance Indicators (KPIs) for construction projects
- Excel and Power BI applications (accessible tools for SMEs)

Emphasis on practical, immediately applicable techniques. Includes 10 worked examples using anonymized real project data, step-by-step tutorials, and downloadable templates.

### Task 2.6: AR/VR for Safety and Training Content
**Lead**: P5 | **Contributing**: P2  
**Duration**: M14-M26

Create AR/VR training content (30 hours) including:
- Safety training scenarios (fall prevention, equipment operation, hazard identification)
- Virtual construction site walkthroughs
- Equipment operation simulations
- Collaborative virtual design reviews
- Mobile AR for on-site information overlay

Develop 5 VR scenarios and 8 AR applications optimized for affordable headsets (Meta Quest, smartphones). Include implementation guides for SMEs with limited tech infrastructure.

### Task 2.7: Assessment and Evaluation Development
**Lead**: P1 | **Contributing**: All partners  
**Duration**: M16-M28

Design comprehensive assessment system:
- Pre-assessment diagnostics (knowledge and skill level)
- Formative assessments embedded in learning content (100+ interactive questions/activities)
- Summative assessments for each technology cluster
- Practical competency demonstrations (portfolio-based)
- Peer and supervisor assessment templates

All assessments mapped to learning objectives and competency frameworks. Item banks created to enable adaptive testing.

### Task 2.8: Translation, Localization, and Cultural Adaptation
**Lead**: P6 | **Contributing**: All partners  
**Duration**: M20-M30

Translate all content into 6 languages (English, German, Spanish, Polish, Italian, Dutch) with:
- Professional translation by native speakers with construction sector knowledge
- Cultural adaptation of examples and case studies
- Regional regulatory context adjustments (e.g., safety standards, BIM protocols)
- Quality review by bilingual subject matter experts

Localization includes not just language but also units of measurement, currency, typical project types, and visual representations relevant to each context.

### Task 2.9: Content Integration and Quality Assurance
**Lead**: P2 | **Contributing**: All partners  
**Duration**: M24-M30

Final integration of all content into platform with:
- Technical quality checks (all media functional, links working)
- Pedagogical review (alignment with framework from Task 2.2)
- User acceptance testing with 50 pilot learners
- Accessibility compliance verification (WCAG 2.1 AA standard)
- Industry validation by partner SMEs

Iterative refinement based on feedback. Final sign-off by all content developers.

## Deliverables

- **D2.1: Needs Analysis Report** (M12, R, PU)
  - Comprehensive report on digital skills gaps, learning needs, and training priorities in construction SMEs
  - Quality: Validated through 200+ survey responses and 6 focus groups

- **D2.2: Instructional Design Framework** (M14, R, PU)
  - Complete framework document including templates, guidelines, and quality standards for all content
  - Quality: Reviewed and approved by external pedagogical experts

- **D2.3: BIM Training Content** (M24, DEM, PU)
  - 30 hours of BIM training content in 3 languages, fully integrated into platform
  - Quality: Tested with 20 users, industry validation by 5 BIM experts

- **D2.4: IoT and Sensor Technology Content** (M24, DEM, PU)
  - 25 hours of IoT training content with hands-on exercises
  - Quality: Technical review by 3 IoT specialists, pilot tested

- **D2.5: Data Analytics Training Content** (M26, DEM, PU)
  - 35 hours of data analytics content with real-world examples and templates
  - Quality: Validated with actual construction project data, user tested

- **D2.6: AR/VR Safety and Training Content** (M26, DEM, PU)
  - 30 hours of AR/VR content including 5 VR scenarios and 8 AR applications
  - Quality: Safety content reviewed by health & safety professionals, tech tested on target devices

- **D2.7: Assessment System** (M28, R+DEM, PU)
  - Complete assessment framework and item banks for all content areas
  - Quality: Psychometric validation, alignment check with learning objectives

- **D2.8: Multilingual Content Package** (M30, DEM, PU)
  - All content available in 6 languages with cultural adaptations
  - Quality: Native speaker review, cultural appropriateness check

- **D2.9: Content Quality Assurance Report** (M30, R, CO)
  - Comprehensive QA documentation including testing results, validation outcomes, and refinement log
  - Quality: Independent QA audit

## Milestones

- **MS4: Learning Objectives Defined and Validated** (M12)
  - Means of verification: D2.1 approved by consortium and 15+ industry partners confirm relevance

- **MS5: Instructional Design Framework Approved** (M14)
  - Means of verification: D2.2 reviewed by external experts and adopted by all content developers

- **MS6: Core Content Modules Completed (BIM + IoT)** (M24)
  - Means of verification: D2.3 and D2.4 delivered, pilot tested with positive feedback (>4/5 rating)

- **MS7: All Content Development Finalized** (M26)
  - Means of verification: All content modules (D2.3-2.6) delivered and integrated into platform

- **MS8: Multilingual Content Ready for Pilot** (M30)
  - Means of verification: D2.8 delivered, content accessible in all 6 languages on platform

## Risk Analysis and Mitigation

**Risk 1: Industry Involvement Below Target**
- *Probability*: Medium | *Impact*: High
- *Mitigation*: P3 (SME association) commits to mobilizing members; early engagement strategy; incentives for participation (free training, certificates)

**Risk 2: Content Development Delays**
- *Probability*: Medium | *Impact*: Medium
- *Mitigation*: Staggered development schedule; monthly progress reviews; buffer time built into timeline; contingency content from previous projects

**Risk 3: Translation Quality Issues**
- *Probability*: Low | *Impact*: Medium
- *Mitigation*: Professional translators with sector expertise; native speaker review; pilot testing in each language; iteration budget allocated

**Risk 4: Rapidly Changing Technology (esp. AI/AR/VR)**
- *Probability*: High | *Impact*: Medium
- *Mitigation*: Focus on principles rather than specific tools; modular structure allows updates; tool-agnostic where possible; final development late in project

## Dependencies

**From Other WPs:**
- WP3 (Platform Development): Technical specifications for content format and metadata
- WP1 (Management): Quality assurance framework and ethical clearance for industry data
- WP5 (Piloting): Feedback for content refinement

**To Other WPs:**
- WP3: Content specifications for platform design; assessment requirements for AI algorithms
- WP5: Content modules for pilot implementation
- WP6: Content samples for dissemination and promotional materials
