# Budget Calculation - Partner 2: Polytechnic University of Madrid

## Partner Overview
- **Country**: Spain
- **Role**: WP2 Lead (Content Development), WP5 Co-lead (Spanish Pilot)
- **Total Budget**: €478,750

## Personnel Costs

### Staff Categories and Rates
Based on certified institutional cost methodology (audited 2024):
- **Full Professor**: €72/hour
- **Associate Professor**: €58/hour
- **Research Fellow (Postdoc)**: €45/hour
- **PhD Researcher**: €28/hour
- **Instructional Designer**: €42/hour
- **Administrative Support**: €32/hour

### Person-Month Allocation by Work Package

| WP | Role | PM | Hours | Rate | Total |
|----|------|----|----- |------|-------|
| **WP1: Management** | | | | | |
| WP1 | Admin Support | 3 | 420 | €32 | €13,440 |
| **WP2: Content Development (LEAD)** | | | | | |
| WP2 | Full Professor | 8 | 1,120 | €72 | €80,640 |
| WP2 | Associate Professor | 12 | 1,680 | €58 | €97,440 |
| WP2 | Instructional Designer | 15 | 2,100 | €42 | €88,200 |
| WP2 | PhD Researcher | 22 | 3,080 | €28 | €86,240 |
| **WP3: Platform Development** | | | | | |
| WP3 | Associate Professor | 4 | 560 | €58 | €32,480 |
| WP3 | Research Fellow | 6 | 840 | €45 | €37,800 |
| **WP5: Piloting and Validation** | | | | | |
| WP5 | Associate Professor | 6 | 840 | €58 | €48,720 |
| WP5 | Research Fellow | 8 | 1,120 | €45 | €50,400 |
| WP5 | PhD Researcher | 10 | 1,400 | €28 | €39,200 |
| **WP6: Dissemination** | | | | | |
| WP6 | Full Professor | 2 | 280 | €72 | €20,160 |
| WP6 | Admin Support | 2 | 280 | €32 | €8,960 |
| | | | | | |
| **TOTAL PERSONNEL** | | **98 PM** | **13,720h** | | **€603,680** |

*Note: 1 Person-Month = 140 productive hours (excluding holidays, sick leave, administrative time)*
*Calculation basis: Spanish national standards for university research projects*

## Travel and Subsistence

### Consortium Meetings
- **Number of meetings**: 6 (semi-annual, months 6, 12, 18, 24, 30, 36)
- **Participants per meeting**: 2 (WP2 lead + management representative)
- **Average cost per trip**: €850
  - Flight/train: €450 (average within EU)
  - Hotel (2 nights): €280 (€140/night)
  - Per diem (3 days): €120 (€40/day - Spanish government rates)
- **Total consortium meetings**: 6 × 2 × €850 = **€10,200**

### Conferences and Dissemination Events
- **Academic conferences**: 4 participations over 3 years
  - Average cost: €1,400 (registration €500 + travel/stay €900)
  - Total: 4 × €1,400 = €5,600

- **Industry workshops**: 3 events (presenting project to construction sector)
  - Average cost: €600 (local/regional travel + materials)
  - Total: 3 × €600 = €1,800

### Research/Validation Visits
- **Pilot site visits in Spain**: 8 visits to partner SMEs for content validation
  - Average cost: €200/visit (local travel, meals)
  - Total: 8 × €200 = €1,600

- **Partner exchange visits**: 2 working visits to P1 (Berlin) for methodology alignment
  - Cost: €900 each × 2 = €1,800

**TOTAL TRAVEL**: €10,200 + €5,600 + €1,800 + €1,600 + €1,800 = **€21,000**

## Equipment and Infrastructure

### Computer Hardware
- **High-performance workstations for content creation**: 3 units
  - Specs: Video editing capable, 32GB RAM, dedicated GPU
  - Cost: €2,200 per unit
  - Total: 3 × €2,200 = €6,600
  - Justification: Required for AR/VR content development and video production (WP2)

### Software Licenses
- **Professional video production suite**: €3,500
  - Adobe Creative Cloud Team license (3 years)
  - For instructional video creation (WP2)

- **BIM software educational licenses**: €2,800
  - Autodesk Revit + ArchiCAD (3-year educational)
  - Essential for BIM content development (WP2, Task 2.3)

- **VR/AR development tools**: €1,500
  - Unity Pro licenses for VR scenario development
  - WP2, Task 2.6

### VR/AR Hardware for Testing
- **VR headsets**: 3 units × €450 = €1,350
  - Meta Quest 3 for testing VR content
  - Necessary to ensure content works on target consumer devices

- **AR-capable tablets**: 2 units × €800 = €1,600
  - iPad Pro for AR application testing
  - Ensures cross-platform compatibility

**TOTAL EQUIPMENT**: €6,600 + €3,500 + €2,800 + €1,500 + €1,350 + €1,600 = **€17,350**

*Note: Equipment >€1,000 follows institutional depreciation rules. Items used 100% for project; no depreciation split needed.*

## Other Direct Costs

### Consumables and Supplies
- **Office supplies and materials**: €1,200 (€400/year × 3 years)
- **Printing costs for validation materials**: €800
  - User guides, assessment forms, pilot materials
- **Cloud storage and backup**: €600 (€200/year × 3 years)
  - Additional storage for large multimedia files

**Subtotal consumables**: €2,600

### Subcontracting Services
- **Professional video production support**: €12,000
  - External production company for 6 high-quality instructional videos
  - Justification: Professional quality required; expertise not available in-house
  - WP2, months 15-24

- **Expert consultations - BIM specialists**: €4,000
  - Industry experts to review and validate BIM content
  - 8 consultations × €500
  - WP2, Task 2.3

- **Usability testing - professional UX firm**: €6,000
  - External firm to conduct structured usability testing of Spanish pilot
  - WP5, month 32

**Subtotal subcontracting**: €22,000

*Note: All subcontracting justified by absence of expertise in consortium; total subcontracting = €22,000 (3.4% of direct costs, well within 30% limit)*

### Dissemination and Publishing
- **Open Access publication charges**: €8,000
  - 4 journal articles × €2,000 average APC
  - Gold Open Access as per EU mandate

- **Conference registration fees**: Already included in Travel budget above

- **Project website hosting and maintenance**: €900 (€300/year × 3 years)
  - Spanish localized content portal

- **Promotional materials**: €1,500
  - Brochures, posters, roll-up banners for events
  - Spanish language dissemination materials

**Subtotal dissemination**: €10,400

### Other Costs
- **Ethics and data protection compliance**: €2,000
  - Legal review of pilot participant data handling
  - GDPR compliance audit

- **Translation and interpretation**: €3,000
  - Professional interpretation at 2 consortium meetings in Spain
  - Technical document translation (contract, reports)

**Subtotal other**: €5,000

**TOTAL OTHER DIRECT COSTS**: €2,600 + €22,000 + €10,400 + €5,000 = **€40,000**

## Indirect Costs (Overheads)

Calculated as **25%** of total eligible direct costs (standard EU rate):

**Direct costs eligible for overhead calculation:**
- Personnel: €603,680
- Travel: €21,000
- Equipment: €17,350
- Other direct: €40,000
- **Total direct costs**: €682,030

**Indirect costs (25%)**: €682,030 × 0.25 = **€170,507.50** → **€170,508**

Indirect costs cover:
- General administration and management
- Building costs (heating, electricity, maintenance, rent)
- IT infrastructure (network, central systems)
- Library and information resources
- Human resources and personnel administration
- Financial and accounting services
- Legal and procurement support

*Basis: Institutional overhead rate certified by Spanish Ministry of Science and Innovation, 2024*

## Total Partner Budget Summary

| Cost Category | Amount (€) | % of Partner Total |
|---------------|-----------|-------------------|
| Personnel | 603,680 | 69.6% |
| Travel & Subsistence | 21,000 | 2.4% |
| Equipment | 17,350 | 2.0% |
| Other Direct Costs | 40,000 | 4.6% |
| **Subtotal Direct** | **682,030** | **78.6%** |
| Indirect Costs (25%) | 170,508 | 19.7% |
| **TOTAL P2 BUDGET** | **852,538** | **100%** |

**Requested EU Funding**: €852,538 (100% funding rate, Erasmus+ KA2)

## Budget Justification - Partner 2

### Personnel (69.6% of total)
The personnel budget reflects the substantial intellectual effort required for developing 120+ hours of high-quality, industry-validated training content across four technology domains (BIM, IoT, Data Analytics, AR/VR). As WP2 lead, P2 coordinates content development with 25 PM allocated to this work package.

Senior academic staff (Full and Associate Professors, 20 PM total) provide scientific leadership, pedagogical expertise, and ensure academic rigor. Their involvement is essential for methodology development, industry expert coordination, and quality assurance.

Instructional designers (15 PM) bring specialized expertise in adult learning, multimedia design, and e-learning content creation - critical for producing engaging, pedagogically sound materials. PhD researchers (32 PM total across all WPs) conduct literature reviews, develop case studies, create exercises, and support piloting - cost-effective while ensuring quality.

Administrative support (5 PM) handles coordination tasks, documentation, and reporting, freeing senior staff for high-value activities.

All rates are based on institutional certified cost model, audited annually, and aligned with Spanish national standards for university research projects.

### Travel (2.4% of total)
Travel budget supports essential face-to-face collaboration in this multinational project. Semi-annual consortium meetings are necessary for complex decision-making, content alignment across partners, and relationship building. Two representatives per meeting ensure WP2 leadership presence and continuity.

Conference participation (4 over 3 years) is moderate and necessary for disseminating findings, networking with construction education community, and ensuring research impact. Selection focuses on high-quality venues with clear dissemination value.

Industry workshop participation connects project with Spanish construction sector, validates content relevance, and builds exploitation partnerships. Local/regional focus keeps costs minimal.

Research visits to pilot sites are essential for understanding real workplace contexts and validating content applicability. Exchange visits to P1 (coordinator) ensure methodological alignment and knowledge transfer.

All travel costs calculated conservatively using Spanish government per diem rates and average EU transport costs.

### Equipment (2.0% of total)
Equipment requests are limited to items essential for content development that aren't available through normal institutional infrastructure.

High-performance workstations are necessary for professional video editing and VR/AR content creation - standard university PCs lack required GPU and RAM. Content production demands are well beyond typical academic computing needs.

Software licenses cover industry-standard tools (Adobe suite, BIM platforms, Unity) necessary for professional-quality content. Educational licenses used where available to minimize cost.

VR headsets and AR tablets are critical for testing developed content on actual consumer devices that SMEs would use - cannot rely solely on high-end development equipment. Ensures content accessibility and functionality.

All equipment will be used 100% for project purposes during project lifetime, with institutional ownership afterward supporting continued educational innovation.

### Other Direct Costs (4.6% of total)
Subcontracting (€22,000, 3.2% of direct costs) is limited to areas where external expertise provides clear value and efficiency:
- Professional video production for flagship instructional content ensures broadcast quality
- BIM expert consultations bring current industry practice and validation
- Professional UX testing provides objective assessment of pilot

Consumables are modest - primarily materials for pilot implementation and cloud storage for large multimedia files.

Dissemination costs, particularly Open Access publication, ensure compliance with EU open science requirements and maximize project impact. Costs are competitive (average APC for education/engineering journals).

Ethics and translation support essential project functions not available in-house.

### Indirect Costs (19.7% of total)
Overhead at 25% is standard EU rate and reflects actual institutional costs of providing research infrastructure, administration, financial management, legal support, and facilities. Rate is certified by Spanish authorities and subject to audit.

### Cost-Effectiveness
- **Cost per training hour developed**: €852,538 ÷ 120 hours = €7,104/hour
  - Includes research, design, development, validation, and multilingual production
  - Comparable to industry e-learning development costs (€5,000-15,000/hour for high-quality content)
  
- **Cost per pilot user (Spanish pilot)**: €852,538 ÷ 100 users = €8,525/user
  - Includes content development benefiting all 5,000 final users
  - Actual cost per end user across project: €2,450,000 ÷ 5,000 = €490/user (highly cost-effective)

- **Value for money**: Partner brings critical mass of BIM and construction expertise, strong SME network in Spain, and experienced content development team. Budget enables leadership of project's core intellectual output.

Partner 2 budget represents excellent value, combining academic excellence with industry relevance, and delivering scalable content that will benefit European construction sector for years beyond project completion.
