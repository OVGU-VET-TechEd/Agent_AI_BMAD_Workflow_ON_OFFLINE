# Project Information Page

## Project Title
Innovative Digital Skills Training for Small and Medium Enterprises in the Construction Sector

## Project Acronym
DigiConstruct

## Short Description
DigiConstruct addresses the critical digital skills gap in the European construction sector by developing and piloting an innovative, AI-powered training platform specifically designed for SME employees. The project combines cutting-edge educational technology with industry-specific content to deliver personalized, workplace-integrated learning experiences that improve productivity, safety, and competitiveness in an increasingly digitalized construction industry.

## Main Objective
To develop, validate, and deploy a comprehensive digital skills training ecosystem that enables 5,000+ construction sector SME employees across five European countries to acquire essential digital competencies (BIM, IoT, data analytics, AR/VR) through personalized, AI-supported learning pathways, thereby increasing SME competitiveness and contributing to the digital transformation of the European construction industry.

## Specific Objectives
1. **Develop an AI-Powered Training Platform**: Create an adaptive learning management system that personalizes content delivery based on individual learner profiles, prior knowledge, and workplace context, achieving 80% learner satisfaction and 70% completion rates.

2. **Co-Create Industry-Specific Content**: Work with construction SMEs and educational institutions to develop 120+ hours of modular, practical training content covering BIM, IoT sensors, data analytics, and AR/VR applications, validated by at least 30 industry partners.

3. **Implement and Pilot in 5 Countries**: Deploy and test the platform with 250 pilot users across Germany, Spain, Poland, Netherlands, and Italy, collecting quantitative and qualitative data to demonstrate effectiveness and gather improvement insights.

4. **Establish Sustainable Business Model**: Develop and validate a financially sustainable exploitation strategy including certification pathways, licensing models, and partnership frameworks ensuring platform viability beyond project funding.

5. **Disseminate Best Practices**: Reach 10,000+ stakeholders through conferences, publications, workshops, and digital channels, creating a European-wide community of practice around digital skills in construction.

## Key Outputs
- **AI-Powered Learning Platform**: Open-source LMS with adaptive learning algorithms, available in 6 languages
- **Training Content Library**: 120+ hours of modular, workplace-oriented training materials covering 4 key digital technology areas
- **Assessment and Certification Framework**: Validated competency assessment tools and micro-credential certification system
- **Implementation Toolkit**: Guidelines, templates, and resources for SMEs to adopt and integrate the training platform
- **Policy Recommendations**: Evidence-based policy brief for EU and national stakeholders on digital skills development in construction
- **Research Publications**: Minimum 8 peer-reviewed publications on digital pedagogy, AI in vocational training, and construction sector innovation

## Expected Outcomes
- **Enhanced Digital Competencies**: 5,000+ construction sector workers gain measurable improvements in digital skills, with 70% achieving recognized micro-credentials
- **Increased SME Competitiveness**: Participating SMEs report 25% average improvement in project efficiency and 15% reduction in error rates through digital tool adoption
- **Industry-Education Collaboration**: Strengthened partnerships between 50+ SMEs and 15 educational institutions, creating sustainable pipeline for future skills development
- **Scalable Training Model**: Validated, replicable training approach transferable to other sectors and regions, with 10+ organizations expressing interest in adoption
- **Policy Impact**: Research findings integrated into 3+ national digital skills strategies and European construction sector policy discussions
- **Economic Impact**: Contribution to EU construction sector digitalization, supporting industry competitiveness and sustainability goals

## Project Partners
1. **Technical University of Berlin (Germany)** - Coordinator
   - Expertise: Engineering pedagogy, educational technology, AI in education
   - Role: Project coordination, platform development, research leadership

2. **Polytechnic University of Madrid (Spain)** - Partner
   - Expertise: Construction engineering, BIM, professional training
   - Role: Content development (BIM), Spanish pilot, validation

3. **National Association of Construction SMEs Poland** - Partner
   - Expertise: Industry needs assessment, SME networks, workforce development
   - Role: Industry liaison, Polish pilot, exploitation strategy

4. **TechEd Innovations B.V. (Netherlands)** - Partner
   - Expertise: EdTech development, LMS platforms, AI/machine learning
   - Role: Technical platform development, AI implementation

5. **Italian Construction Training Institute (Italy)** - Partner
   - Expertise: Vocational training, certification systems, adult education
   - Role: Content development (safety, AR/VR), Italian pilot, certification framework

6. **Digital Skills Europe Foundation (Belgium)** - Partner
   - Expertise: EU policy, digital skills frameworks, dissemination
   - Role: Policy engagement, dissemination, European network building

## Duration & Budget
**Duration**: 36 months (January 2026 - December 2028)  
**Total Budget**: €2,450,000  
**EU Contribution**: €2,450,000 (100% funding rate under Erasmus+ KA2)
