#!/usr/bin/env python3
"""
Proposal Workflow Runner — Local Ollama Version
================================================
Runs all 6 proposal agents against your local Ollama model
and saves each output to the docs/ folder.

Integrates: tasks/ + templates/ + skeletons/ for richer agent context.

Requirements:
    pip install ollama pypdf

Usage:
    python run_proposal_agents.py             ← run all 6 agents
    python run_proposal_agents.py --agent 1   ← run only Agent 1
    python run_proposal_agents.py --from 3    ← resume from Agent 3
    python run_proposal_agents.py -y          ← skip confirmation prompts
    python run_proposal_agents.py --force     ← re-run even if output exists

Auto-resume: agents whose output files already exist are skipped.
Use --force to regenerate them.
"""

import os
import sys
import argparse
from pathlib import Path

# Dependencies are checked at runtime (see check_dependencies)
ollama = None
PdfReader = None

# —— Config ————————————————————————————————————————————————————————————

BASE_DIR      = Path(__file__).parent
CALL_DIR      = BASE_DIR / "call"
DOCS_DIR      = BASE_DIR / "docs"
TASKS_DIR     = BASE_DIR / "tasks"
TEMPLATES_DIR = BASE_DIR / "templates"
SKELETONS_DIR = BASE_DIR / "skeletons"

# IMPORTANT: Use a GENERAL-PURPOSE model, NOT a code model.
# Code models (deepseek-coder, codellama, etc.) will refuse to write proposals.
# Good choices: "mistral", "llama3.2", "deepseek-r1:latest", "qwen2.5"
MODEL = "mistral"

# Max characters of previous docs to include as context (keeps requests manageable)
MAX_CONTEXT_CHARS = 8000

# Ollama context window (tokens). Must be large enough for call PDF + instructions + output.
# 32768 works for most models. Increase to 65536 if your GPU has ≥16 GB VRAM.
NUM_CTX = 32768

# No timeout — Ollama will run as long as needed to complete each agent.

# Minimum file size (bytes) to consider an agent's output "complete".
# Placeholder files are ~70 bytes; real output is typically 5–50 KB.
MIN_COMPLETE_SIZE = 500

# —— System Prompt (shared with mega_proposal_runner.py) ———————————————

SYSTEM_PROMPT = """
You are the Project Proposal Workflow System — a multi-agent assistant that writes
high-quality EU and national funding proposals (Erasmus+, Horizon Europe, and similar).

QUALITY STANDARDS — enforce these in every output:
- Info page: MAX 600 words, fits exactly 1 page A4
- Work packages: use typed deliverables (R, DATA, DEMO, SW, WEB, G, TOOL, CERT)
  and dissemination levels (PU = Public, CO = Confidential, RE = Restricted)
- Budget: per-partner breakdown, all totals mathematically correct, narrative justification
- All documents MUST be internally consistent (same partners, objectives, timelines)
- Write in full — never truncate, never use placeholder text like "[to be completed]"

FINANCIAL DEFAULTS (use if call document does not specify):
- 1 Person-Month (PM) = 140 productive hours
  (Basis: 22 working days × 8 hours × 80% productive time)
- Overhead / Indirect costs: 25% flat rate on direct costs
- Default staff rates (replace with actual institutional rates if available):
    Full Professor / Senior Researcher:  €75/hour
    Associate Professor / Researcher:    €55/hour
    Postdoctoral Researcher:             €45/hour
    PhD Researcher:                      €30/hour
    Project Manager / Coordinator:       €40/hour
    Administrative Support:              €28/hour

CRITICAL INSTRUCTION:
You are a WRITER, not a programmer. Your job is to write the actual proposal TEXT
content in Markdown format. Do NOT write code. Do NOT say you cannot generate documents.
Do NOT mention JavaScript, React, HTML, or CSS. Simply write the document content directly.

OUTPUT FORMAT RULE:
Wrap every document you produce with start/end markers:
    ---START: docs/filename.md---
    [full document content here]
    ---END: docs/filename.md---
This allows the system to automatically save your output to the correct file.
""".strip()

# —— Agent Registry ————————————————————————————————————————————————————
# Each agent maps to its task file, template, skeleton, and output files.

AGENTS = [
    {
        "number":   1,
        "name":     "Overseer Agent",
        "command":  "/overseer",
        "task":     "agent-1-overseer.md",
        "template": None,                           # no YAML template for overseer
        "skeleton": None,                            # no skeleton for overseer
        "outputs":  ["docs/overseer-analysis.md", "docs/project-strategy.md"],
        "save_as":  ["overseer-analysis.md", "project-strategy.md"],
        "prompt":  (
            "@proposal-agent /overseer\n\n"
            "The full funding call document is provided above. "
            "Produce BOTH outputs in full:\n"
            "1. docs/overseer-analysis.md — full strategic analysis\n"
            "2. docs/project-strategy.md — concise project framework for Agent 2\n\n"
            "Separate the two documents clearly with:\n"
            "---START: docs/overseer-analysis.md---\n"
            "[content]\n"
            "---END: docs/overseer-analysis.md---\n\n"
            "---START: docs/project-strategy.md---\n"
            "[content]\n"
            "---END: docs/project-strategy.md---"
        ),
    },
    {
        "number":   2,
        "name":     "Info Page Agent",
        "command":  "/info-page",
        "task":     "agent-2-info-page.md",
        "template": "project-info-page-template.yaml",
        "skeleton": "example-project-info-page.md",
        "outputs":  ["docs/project-info-page.md"],
        "save_as":  ["project-info-page.md"],
        "prompt":  (
            "@proposal-agent /info-page\n\n"
            "Read docs/overseer-analysis.md and docs/project-strategy.md above, "
            "then produce the 1-page A4 project info page (max 600 words).\n\n"
            "Wrap output as:\n"
            "---START: docs/project-info-page.md---\n"
            "[content]\n"
            "---END: docs/project-info-page.md---"
        ),
    },
    {
        "number":   3,
        "name":     "Outline Agent",
        "command":  "/outline",
        "task":     "agent-3-outline.md",
        "template": "project-outline-template.yaml",
        "skeleton": None,
        "outputs":  ["docs/project-outline.md"],
        "save_as":  ["project-outline.md"],
        "prompt":  (
            "@proposal-agent /outline\n\n"
            "Read all previous outputs above and produce the full 15-25 page proposal.\n\n"
            "Wrap output as:\n"
            "---START: docs/project-outline.md---\n"
            "[content]\n"
            "---END: docs/project-outline.md---"
        ),
    },
    {
        "number":   4,
        "name":     "Work Package Agent",
        "command":  "/work-packages",
        "task":     "agent-4-work-packages.md",
        "template": "work-packages-template.yaml",
        "skeleton": "example-work-package.md",
        "outputs":  ["docs/work-packages.md"],
        "save_as":  ["work-packages.md"],
        "prompt":  (
            "@proposal-agent /work-packages\n\n"
            "Read all previous outputs above and produce the detailed work package plan "
            "(10-20 pages) with WP overview tables and full WP descriptions.\n\n"
            "Wrap output as:\n"
            "---START: docs/work-packages.md---\n"
            "[content]\n"
            "---END: docs/work-packages.md---"
        ),
    },
    {
        "number":   5,
        "name":     "Budget Agent",
        "command":  "/budget",
        "task":     "agent-5-budget.md",
        "template": "budget-calculation-template.yaml",
        "skeleton": "example-budget-excerpt.md",
        "outputs":  ["docs/budget-calculation.md"],
        "save_as":  ["budget-calculation.md"],
        "prompt":  (
            "@proposal-agent /budget\n\n"
            "Read all previous outputs above (especially work-packages.md for PM allocations) "
            "and produce the full budget calculation (8-12 pages).\n\n"
            "Wrap output as:\n"
            "---START: docs/budget-calculation.md---\n"
            "[content]\n"
            "---END: docs/budget-calculation.md---"
        ),
    },
    {
        "number":   6,
        "name":     "Quality Review Agent",
        "command":  "/review",
        "task":     "agent-6-review.md",
        "template": None,
        "skeleton": None,
        "outputs":  ["docs/quality-review.md"],
        "save_as":  ["quality-review.md"],
        "prompt":  (
            "@proposal-agent /review\n\n"
            "Read ALL previous agent outputs above and perform a comprehensive "
            "quality and consistency review of the entire proposal.\n\n"
            "Wrap output as:\n"
            "---START: docs/quality-review.md---\n"
            "[content]\n"
            "---END: docs/quality-review.md---"
        ),
    },
]

# —— Helpers ———————————————————————————————————————————————————————————

def read_pdf(pdf_path: Path) -> str:
    """Extract text from PDF."""
    print(f"   📄 Reading PDF: {pdf_path.name}")
    reader = PdfReader(str(pdf_path))
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    print(f"   ✓ Extracted {len(reader.pages)} pages, {len(text):,} characters")
    return text


def check_dependencies():
    """Import required packages at runtime so --help works without them."""
    global ollama, PdfReader
    try:
        import ollama as _ollama
        globals()['ollama'] = _ollama
    except ImportError:
        print("❌ Missing package: ollama\n   Run: pip install ollama"); sys.exit(1)
    try:
        from pypdf import PdfReader as _PdfReader
        globals()['PdfReader'] = _PdfReader
    except ImportError:
        print("❌ Missing package: pypdf\n   Run: pip install pypdf"); sys.exit(1)


def read_file_safe(path: Path) -> str:
    """Read a text file, returning empty string if missing or unreadable."""
    if path.exists() and path.stat().st_size > 0:
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            return ""
    return ""


def read_task(task_filename: str) -> str:
    """Read an agent task file from tasks/."""
    return read_file_safe(TASKS_DIR / task_filename)


def read_template(template_filename: str | None) -> str:
    """Read a YAML template from templates/."""
    if not template_filename:
        return ""
    return read_file_safe(TEMPLATES_DIR / template_filename)


def read_skeleton(skeleton_filename: str | None) -> str:
    """Read an example skeleton from skeletons/."""
    if not skeleton_filename:
        return ""
    return read_file_safe(SKELETONS_DIR / skeleton_filename)


def read_docs() -> str:
    """Read all existing docs into context, trimmed to MAX_CONTEXT_CHARS each."""
    context = ""
    for md_file in sorted(DOCS_DIR.glob("*.md")):
        if md_file.stat().st_size > 0:
            content = md_file.read_text(encoding="utf-8")
            # Skip placeholder files
            if content.strip().startswith("<!-- Placeholder"):
                continue
            if len(content) > MAX_CONTEXT_CHARS:
                content = content[:MAX_CONTEXT_CHARS] + "\n\n[... truncated for context length ...]"
            context += f"\n\n=== EXISTING DOC: {md_file.name} ===\n"
            context += content
    return context


def extract_output(response: str, filename: str) -> str:
    """Extract content between ---START: filename--- and ---END: filename--- markers."""
    start_marker = f"---START: {filename}---"
    end_marker   = f"---END: {filename}---"
    if start_marker in response and end_marker in response:
        start = response.index(start_marker) + len(start_marker)
        end   = response.index(end_marker)
        return response[start:end].strip()
    # Fallback: return full response if markers not found
    print(f"   ⚠️  No ---START/END--- markers found for {filename}; using full response.")
    return response.strip()


# Phrases that indicate the model refused or misunderstood the task
REFUSAL_PATTERNS = [
    "i'm sorry",
    "i am sorry",
    "i apologize",
    "i am unable",
    "i cannot generate",
    "as an ai",
    "as a textual assistant",
    "javascript react",
    "html/css",
    "placeholder text",
    "out of scope",
    "cannot provide",
]


def validate_output(content: str, agent_name: str) -> bool:
    """Check that the model actually produced useful content, not a refusal."""
    lower = content.lower()
    for pattern in REFUSAL_PATTERNS:
        if pattern in lower:
            print(f"\n   ❌  VALIDATION FAILED for {agent_name}!")
            print(f"       The model appears to have REFUSED or MISUNDERSTOOD the task.")
            print(f"       Detected refusal phrase: '{pattern}'")
            print(f"       This usually means the model is a CODE model, not a general-purpose model.")
            print(f"       Fix: Change MODEL at the top of this file to 'mistral', 'llama3.2', or similar.")
            return False
    if len(content) < 300:
        print(f"\n   ⚠️  WARNING: Output for {agent_name} is very short ({len(content)} chars).")
        print(f"       Expected several thousand characters of proposal content.")
        return False
    return True


def save_doc(filename: str, content: str):
    """Save content to docs/ folder."""
    DOCS_DIR.mkdir(exist_ok=True)
    out_path = DOCS_DIR / filename
    out_path.write_text(content, encoding="utf-8")
    size_kb = len(content) / 1024
    print(f"   ✓ Saved: docs/{filename} ({size_kb:.1f} KB)")

def agent_already_complete(agent: dict) -> bool:
    """Check if ALL output files for this agent already contain real content."""
    for filename in agent["save_as"]:
        path = DOCS_DIR / filename
        if not path.exists():
            return False
        if path.stat().st_size < MIN_COMPLETE_SIZE:
            return False
        content = path.read_text(encoding="utf-8").strip()
        if content.startswith("<!-- Placeholder"):
            return False
    return True

def ask_ollama(messages: list) -> str:
    """Send messages to Ollama and return response text."""
    print(f"   🤖 Querying {MODEL} (num_ctx={NUM_CTX}, no timeout — will run until complete)...")
    try:
        response = ollama.chat(
            model=MODEL,
            messages=messages,
            options={"num_ctx": NUM_CTX},
        )
        return response["message"]["content"]
    except KeyboardInterrupt:
        print("\n⚠️  Interrupted by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌  Ollama error: {e}")
        print("   Make sure Ollama is running: ollama serve")
        sys.exit(1)


# —— Argument Parsing ——————————————————————————————————————————————————

def parse_args():
    p = argparse.ArgumentParser(
        description="Proposal Workflow Runner — Local Ollama Version"
    )
    g = p.add_mutually_exclusive_group()
    g.add_argument("--agent", type=int, metavar="N",
                   help="Run only agent N (1–6)")
    g.add_argument("--from", type=int, metavar="N", dest="from_agent",
                   help="Run from agent N onwards (e.g. --from 3 runs agents 3–6)")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Skip confirmation prompts, run all automatically")
    p.add_argument("--force", action="store_true",
                   help="Re-run agents even if their output files already exist")
    return p.parse_args()


# —— Main —————————————————————————————————————————————————————————————

def main():
    args = parse_args()

    # Check dependencies now (after argparse, so --help works without packages)
    check_dependencies()

    print()
    print("=" * 64)
    print("  Project Proposal Workflow — Local Ollama Runner")
    print(f"  Model: {MODEL}")
    print("=" * 64)

    # 1. Find the call PDF
    pdf_files = list(CALL_DIR.glob("*.pdf"))
    if not pdf_files:
        print(f"\n❌ No PDF found in call/ directory.")
        print(f"   Place your funding call PDF in: {CALL_DIR}")
        sys.exit(1)

    pdf_path = pdf_files[0]
    if len(pdf_files) > 1:
        print(f"\n⚠️  Multiple PDFs found. Using: {pdf_path.name}")

    # 2. Read the call PDF
    print(f"\n📂 Call document: {pdf_path.name}")
    call_text = read_pdf(pdf_path)

    # 3. Decide which agents to run
    if args.agent:
        agents_to_run = [a for a in AGENTS if a["number"] == args.agent]
        if not agents_to_run:
            print(f"❌  No agent with number {args.agent}"); sys.exit(1)
    elif args.from_agent:
        agents_to_run = [a for a in AGENTS if a["number"] >= args.from_agent]
    else:
        agents_to_run = AGENTS

    total = len(agents_to_run)
    print(f"\n🚀  Running {total} agent(s): "
          + ", ".join(f"Agent {a['number']}" for a in agents_to_run))

    # 4. Run each agent in sequence
    DOCS_DIR.mkdir(exist_ok=True)

    for i, agent in enumerate(agents_to_run, 1):
        # —— Auto-skip agents that already have complete output ——
        if not args.force and agent_already_complete(agent):
            existing = ", ".join(f"docs/{f}" for f in agent["save_as"])
            print(f"\n   ⏭ Agent {agent['number']} — {agent['name']}")
            print(f"      Already complete: {existing}")
            print(f"      (use --force to regenerate)")
            continue

        print(f"\n{'─' * 64}")
        print(f"  Agent {agent['number']}/6 — {agent['name']} ({agent['command']})")
        print(f"{'─' * 64}")

        # Load task instructions
        task_text = read_task(agent["task"])

        # Load template (YAML structure guide)
        template_text = read_template(agent.get("template"))

        # Load skeleton (quality reference example)
        skeleton_text = read_skeleton(agent.get("skeleton"))

        # Load existing docs as context
        docs_context = read_docs()

        # Compose the full user message
        user_message = f"=== FUNDING CALL DOCUMENT ===\n{call_text}\n\n"

        if task_text.strip():
            user_message += f"=== AGENT TASK INSTRUCTIONS ===\n{task_text}\n\n"

        if template_text.strip():
            user_message += f"=== OUTPUT STRUCTURE TEMPLATE ===\n{template_text}\n\n"

        if skeleton_text.strip():
            user_message += f"=== QUALITY REFERENCE EXAMPLE ===\n{skeleton_text}\n\n"

        if docs_context.strip():
            user_message += f"=== PREVIOUS AGENT OUTPUTS (read these before producing your output) ===\n{docs_context}\n\n"

        user_message += agent["prompt"]

        # Call Ollama
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": user_message},
        ]

        response = ask_ollama(messages)

        # Save each output file (with validation)
        all_valid = True
        for output_filename, save_filename in zip(agent["outputs"], agent["save_as"]):
            content = extract_output(response, output_filename)
            if not validate_output(content, agent["name"]):
                all_valid = False
                content = f"<!-- FAILED: Model did not produce valid output -->\n{content}"
            save_doc(save_filename, content)

        if all_valid:
            print(f"   ✅ {agent['name']} complete.")
        else:
            print(f"\n   🔴 {agent['name']} produced INVALID output.")
            print(f"      The saved files contain the model's refusal, not proposal content.")
            print(f"      Action: Change MODEL to a general-purpose model and re-run with --force")
            print(f"      Recommended models: mistral, llama3.2, deepseek-r1:latest, qwen2.5")

        # Ask user if they want to continue
        if i < total and not args.yes:
            nxt = agents_to_run[i]
            print(f"\n   Next: Agent {nxt['number']} — {nxt['name']}")
            choice = input("   Continue? [Enter = yes / q = quit]: ").strip().lower()
            if choice == "q":
                print(f"\n⏸  Paused after Agent {agent['number']}.")
                print(f"   Resume later with:  python run_proposal_agents.py --from {agent['number']+1}")
                sys.exit(0)

    print()
    print("=" * 64)
    print("  ✅ All agents complete! Outputs saved to docs/")
    print("=" * 64)
    print()
    print("  Files created:")
    for f in sorted(DOCS_DIR.glob("*.md")):
        if f.stat().st_size > 0:
            content = f.read_text(encoding="utf-8")
            if not content.strip().startswith("<!-- Placeholder"):
                print(f"    ✓ docs/{f.name}  ({f.stat().st_size / 1024:.1f} KB)")
    print()
    print("  Tip: Open each .md file in VS Code to review and edit.")
    print("  Tip: Run --agent 6 for a final consistency review.")
    print()


if __name__ == "__main__":
    main()
