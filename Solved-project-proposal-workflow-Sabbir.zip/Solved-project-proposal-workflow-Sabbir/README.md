# Project Proposal Workflow System

> AI-powered 6-agent workflow for writing EU and national funding proposals
> Built on the same architecture as the BMAD Teaching Agent System

---

## What This Is

This system enables anyone with access to Claude or ChatGPT to produce a complete,
high-quality funding proposal through a series of structured agent activations.

You provide: a funding call document + project context
The agents provide: strategic analysis → 1-page summary → full proposal → work packages → budget

---

## Architecture

This system is a direct parallel to the BMAD Teaching Agent System (LiaScript blog):

```
BMAD Teaching System          →    Project Proposal System
─────────────────────────────────────────────────────────────
Teaching Agent                →    Proposal Agent
@teaching-agent /[command]    →    @proposal-agent /[command]
Phase 1: Foundation           →    Stage 1: Overseer Analysis
Phase 2: Didactics            →    Stage 2: Project Info Page
Phase 3: Planning             →    Stage 3: Full Proposal Outline
Phase 4: Development          →    Stage 4: Work Packages
Phase 5: Finalization         →    Stage 5: Budget + Review
```

The folder design decision — separating `tasks/`, `templates/`, `skeletons/`, and `docs/` —
mirrors the BMAD method's emphasis on structured, reusable workflow components.

---

## 6-Agent Sequential Workflow

```
[Funding Call] ──→ [Overseer] ──→ [Info Page] ──→ [Outline] ──→ [WP Agent] ──→ [Budget] ──→ [Review]
      call/         docs/1            docs/2          docs/3        docs/4       docs/5     docs/6
```

| Stage | Agent | Command | Output |
|-------|-------|---------|--------|
| 1 | Overseer Agent | `/overseer` | Strategic analysis + project concept |
| 2 | Info Page Agent | `/info-page` | 1-page A4 summary (≤600 words) |
| 3 | Outline Agent | `/outline` | Full proposal (15–25 pages) |
| 4 | Work Package Agent | `/work-packages` | Detailed work plan (10–20 pages) |
| 5 | Budget Agent | `/budget` | Budget calculation (8–12 pages) |
| 6 | Quality Review Agent | `/review` | Consistency check report |

---

## Folder Structure

```
[YOUR_PROJECT_ACRONYM]/
│
├── call/                          ← Place funding call document here (INPUT)
│   └── README.md
│
├── docs/                          ← Agent outputs land here (OUTPUT)
│   ├── overseer-analysis.md
│   ├── project-info-page.md
│   ├── project-outline.md
│   ├── work-packages.md
│   ├── budget-calculation.md
│   └── quality-review.md
│
├── tasks/                         ← Agent instructions (read by AI)
│   ├── agent-1-overseer.md
│   ├── agent-2-info-page.md
│   ├── agent-3-outline.md
│   ├── agent-4-work-packages.md
│   ├── agent-5-budget.md
│   └── agent-6-review.md
│
├── templates/                     ← YAML output structure templates
│   ├── project-info-page-template.yaml
│   ├── project-outline-template.yaml
│   ├── work-packages-template.yaml
│   └── budget-calculation-template.yaml
│
├── skeletons/                     ← Example outputs (quality reference)
│   ├── example-project-info-page.md
│   ├── example-work-package.md
│   └── example-budget-excerpt.md
│
├── README.md                       ← This file
├── AGENT_COMMANDS_GUIDE.md         ← Full command reference
├── SESSION_INIT_PROMPT.md          ← Copy-paste AI session initialisation
├── USAGE_GUIDE.md                  ← Step-by-step workflow guide
├── run_proposal_agents.py          ← Ollama runner (loads task files)
└── mega_proposal_runner.py         ← Ollama runner (self-contained)
```

---

## Quick Start (3 Steps)

### Step 1 — Initialise the AI
Paste the prompt from `SESSION_INIT_PROMPT.md` into a new Claude/ChatGPT session.
Wait for: `✅ Project Proposal Workflow System is ready.`

### Step 2 — Add Funding Call
Place your call document in the `call/` directory.
Say: `@proposal-agent /start`

### Step 3 — Run the Agents in Order
```
@proposal-agent /overseer
@proposal-agent /info-page
@proposal-agent /outline
@proposal-agent /work-packages
@proposal-agent /budget
@proposal-agent /review
```

Or use the automated runner with local Ollama:
```
python run_proposal_agents.py      ← interactive mode
python run_proposal_agents.py -y   ← automatic mode
```

Full workflow takes approximately **2 hours** for a complete first draft.

---

## Supported Funding Programmes

| Programme | Budget Range | Duration |
|-----------|-------------|---------|
| Erasmus+ KA2 (VET/HE/Adult) | €200K–€500K | 24–36 months |
| Erasmus+ KA2 Design Systems | €500K–€1M | 24–48 months |
| Horizon Europe RIA | €2M–€10M+ | 36–60 months |
| Horizon Europe IA | €4M–€15M+ | 36–60 months |
| Interreg (EU cross-border) | €500K–€5M | 30–48 months |
| National research councils | Varies | 24–48 months |

The agent system adapts to any programme — provide call document and parameters.

---

Generated: 2026-02-20 | Programme: Horizon Europe (HORIZON-CL4-2025-DIGITAL-01-03) | Project: TRUSTEDAI
