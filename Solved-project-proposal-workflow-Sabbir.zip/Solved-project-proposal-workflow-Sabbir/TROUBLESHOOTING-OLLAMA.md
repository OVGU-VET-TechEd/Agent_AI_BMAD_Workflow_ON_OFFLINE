# Troubleshooting Guide — Running Proposal Agents with Ollama

> Lessons learned from running a 6-agent EU proposal pipeline locally,
> why `deepseek-coder` fails, why `mistral` works, and why full-length
> proposals overwhelm local LLMs

---

## 1. The Problem: `deepseek-coder` Cannot Write Proposals

### What Happened

The initial setup used `deepseek-coder:latest` as the Ollama model. It was already
installed, it's a capable model, and Ollama pulled it without issues. The assumption
was: "It's an AI model, it can write text."

That assumption was wrong.

### Why It Fails

`deepseek-coder` is a **code-specialised model**. Its training data is overwhelmingly
source code, documentation snippets, and programming Q&A. When asked to write a
15-page EU Horizon Europe proposal narrative, it does one of the following:

| Behaviour | What You See |
|-----------|-------------|
| **Refuses outright** | "I'm a coding assistant. I can help you write code but I cannot generate a project proposal." |
| **Writes code instead** | Produces a JavaScript/React app skeleton for a "proposal generator" instead of the actual proposal text |
| **Produces thin output** | Writes 50–100 words of generic filler then stops — nowhere near the 15–25 page target |
| **Hallucinates structure** | Outputs HTML/CSS markup or JSON schemas instead of Markdown prose |
| **Loops on complexity** | Repeats the same paragraph, or outputs "This task requires human expertise" after 30 minutes of spinning |

The system prompt explicitly instructs the model: *"You are a WRITER, not a programmer.
Do NOT write code."* — but a code-finetuned model has this behaviour baked into its
weights. No prompt can fully override the training distribution.

### The Same Problem Applies to Other Code Models

| Model | Type | Result with Proposal Tasks |
|-------|------|---------------------------|
| `deepseek-coder:latest` | Code | Refuses or writes code scaffolding |
| `codellama:latest` | Code | Same — tries to write Python/JS |
| `starcoder2:latest` | Code | Same — defaults to code generation |
| `deepseek-coder-v2:latest` | Code | Occasionally writes some text, but thin and unreliable |

**Rule: Never use a code-finetuned model for proposal writing.**

---

## 2. The Solution: `mistral:latest`

### Why Mistral Works

```
mistral:latest           6577803aa9a0    4.4 GB
```

Mistral 7B is a **general-purpose language model** trained on a broad mixture of text:
academic papers, policy documents, reports, structured writing, and conversational
language. This makes it fundamentally different from code models:

| Capability | `deepseek-coder` | `mistral:latest` |
|------------|-------------------|-------------------|
| Write structured Markdown prose | ❌ Refuses / writes code | ✅ Produces full sections |
| Follow EU proposal conventions | ❌ No training on this domain | ✅ Familiar with academic/policy writing |
| Maintain consistent terminology across pages | ❌ Drifts to code patterns | ✅ Maintains register |
| Produce SMART objectives with measurable targets | ❌ Writes function signatures | ✅ Writes "validated through 2 pilots by M30" |
| Fill 15–25 page target length | ❌ Stops at ~100 words | ✅ Produces 3,000–8,000 words per agent |
| Handle financial calculations in prose | ❌ Writes Python `calculate_budget()` | ✅ Writes "€75/hour × 140 hours × 25 PM = €262,500" |

### Why 4.4 GB Matters

At 4.4 GB, Mistral 7B fits entirely in GPU VRAM on most modern machines (8 GB+ VRAM)
or runs adequately in CPU mode on 16 GB+ RAM systems. This is the sweet spot:

- **Large enough** to write coherent multi-page documents with consistent terminology
- **Small enough** to run locally without a data centre
- **Fast enough** to complete a single agent in 5–20 minutes (vs. 2+ hours for larger models)

Larger models like `llama3.1:70b` (40 GB) would produce better output but require
enterprise-grade hardware. Mistral 7B is the practical floor for proposal writing.

### Other Viable General-Purpose Models

If Mistral doesn't suit your needs, these alternatives also work:

| Model | Size | Notes |
|-------|------|-------|
| `mistral:latest` | 4.4 GB | **Recommended** — best balance of quality and speed |
| `llama3.2:latest` | 2.0 GB | Smaller and faster, but thinner output |
| `qwen2.5:latest` | 4.7 GB | Good multilingual support |
| `deepseek-r1:latest` | 4.7 GB | Reasoning model — slower but more analytical |
| `gemma2:latest` | 5.4 GB | Google's model — strong on structured text |

---

## 3. Ollama Alone Is Not Enough — Required Dependencies

### The Minimum Stack

Installing Ollama and pulling a model is only the first step. The proposal runner
scripts require additional software to function:

```
Component 1: Ollama          ← LLM inference engine
Component 2: A model         ← mistral:latest (not a code model)
Component 3: Python 3.10+    ← script runtime
Component 4: ollama package  ← Python client for Ollama API
Component 5: pypdf package   ← PDF reader for call documents
```

### Step-by-Step Installation

#### 1. Install Ollama

Download from [ollama.ai](https://ollama.ai/) and install. Verify:

```powershell
ollama --version
```

#### 2. Pull the Correct Model

```powershell
ollama pull mistral
```

Verify it downloaded:

```powershell
ollama list
```

Expected output:

```
NAME                 ID              SIZE      MODIFIED
mistral:latest       6577803aa9a0    4.4 GB    ...
```

**Do NOT use:** `deepseek-coder`, `codellama`, `starcoder2`, or any model with
"code" in its name.

#### 3. Install Python

Download from [python.org](https://www.python.org/downloads/) (3.10 or later). Verify:

```powershell
python --version
```

#### 4. Install Python Packages

```powershell
pip install ollama pypdf
```

These are the two packages imported by the runner scripts:
- **`ollama`** — Python client that communicates with the local Ollama server via its REST API
- **`pypdf`** — Reads the funding call PDF from the `call/` directory and extracts text

Without `ollama`, the script cannot send prompts to the model.
Without `pypdf`, the script cannot read your call document (if it's a PDF).

#### 5. Place Your Call Document

Put your funding call in the `call/` directory:

```
call/
  └── Call-README.md        ← Markdown or plain text
  └── your-call.pdf         ← or PDF (pypdf extracts the text)
```

#### 6. Run the Pipeline

```powershell
python run_proposal_agents.py           # interactive mode
python run_proposal_agents.py -y        # automatic mode (no pauses)
```

### What Happens If You Skip a Dependency

| Missing | Error |
|---------|-------|
| Ollama not installed | `ollama: command not found` or connection refused |
| No model pulled | `model 'mistral' not found, try pulling it first` |
| Python not installed | `python: command not recognized` |
| `ollama` package missing | `ModuleNotFoundError: No module named 'ollama'` |
| `pypdf` package missing | `ModuleNotFoundError: No module named 'pypdf'` |
| No call document in `call/` | Script warns "No call document found" and produces generic output |

---

## 4. The 50+ Page Problem — Why Local LLMs Cannot Handle Full Proposals

### The Scale of an EU Proposal

A complete Horizon Europe RIA proposal (the kind this system produces) consists of:

| Document | Typical Length | Tokens (approx.) |
|----------|---------------|-------------------|
| Overseer Analysis | 5–8 pages | ~4,000 tokens |
| Project Strategy | 2 pages | ~1,500 tokens |
| Project Info Page | 1 page | ~800 tokens |
| Project Outline | 15–25 pages | ~12,000 tokens |
| Work Packages | 20–30 pages | ~18,000 tokens |
| Budget Calculation | 8–12 pages | ~8,000 tokens |
| **Total** | **51–78 pages** | **~44,000 tokens** |

Now add the **input context** each agent needs to read:

| Agent | Must Read | Input Tokens |
|-------|-----------|-------------|
| Agent 1 | Call document (10–20 pages) | ~8,000 |
| Agent 4 | Call + all 4 previous docs | ~18,000 |
| Agent 5 | Call + all 5 previous docs + rate tables | ~26,000 |
| Agent 6 | Call + ALL 6 docs | ~36,000 |

By Agent 4, the input context alone approaches the model's entire context window.

### What Goes Wrong Without `MAX_CONTEXT_CHARS` Trimming

The runner scripts include a critical parameter:

```python
MAX_CONTEXT_CHARS = 8000
```

This trims each previously generated document to 8,000 characters before sending it as
context to the next agent. Here's why this exists:

| `MAX_CONTEXT_CHARS` | What Happens |
|---------------------|-------------|
| `20000` (original) | Agent 4 hangs for **2+ hours** then produces nothing or gives up |
| `8000` (current) | Agent 4 completes in **10–20 minutes** with usable output |
| `4000` | Faster, but agents lose important details from upstream docs |
| `No limit` | Ollama crashes, runs out of memory, or loops indefinitely |

### The Fundamental Limitation

A 7B parameter model with a 32K token context window simply cannot:

1. **Read** 30+ pages of prior documents (input)
2. **Hold** all cross-references in working memory (reasoning)
3. **Write** a 20-page detailed work package document (output)
4. **Verify** consistency with all prior documents (quality)

...all in a single inference pass. This is not a software bug — it is a hard
constraint of the model's architecture.

### How It Fails in Practice

When the context is too large, the model exhibits these failure modes:

| Failure Mode | Symptom | Agent Most Affected |
|-------------|---------|---------------------|
| **Infinite generation** | Ollama runs for 2–4 hours, producing repetitive text or looping | Agent 4 (Work Packages) |
| **Truncated output** | Model stops mid-sentence after ~2,000 words, far short of target | Agent 3 (Outline) |
| **Complexity refusal** | Model outputs: *"This task is too complex and requires human attention"* | Agent 5 (Budget) |
| **Amnesia** | Model forgets partner names or objectives from earlier context, invents new ones | Agent 4, 5 |
| **Structural collapse** | Model abandons the template structure and writes free-form paragraphs | Agent 4, 5 |
| **Arithmetic failure** | Budget totals don't add up — 330 PM costed as if 200 PM, overhead miscalculated | Agent 5 (Budget) |

The budget agent (Agent 5) is the worst affected because it must simultaneously:
- Remember 5 partner names and their PM allocations from `work-packages.md`
- Apply different hourly rates per staff role per partner
- Calculate subtotals per category per partner
- Apply 25% overhead correctly
- Ensure the grand total hits exactly EUR 4,000,000
- Write a justification narrative explaining every line

This is **mathematical reasoning + long-form writing + cross-referencing** — the exact
combination that overwhelms small local models.

### The "This Task Is Too Complex" Response

When Mistral (or any 7B model) hits its cognitive ceiling, it often produces a response
like:

> *"This is a highly complex task that involves multiple financial calculations,
> cross-referencing between documents, and detailed justification writing. I recommend
> working with a human expert or using a larger model to complete this section accurately."*

This is the model's learned behaviour when it recognises that the task exceeds its
capacity. It is not being lazy — it genuinely cannot maintain the required state
across 20+ pages of interconnected financial data in a single pass.

---

## 5. The Practical Workflow — What Actually Works

### Local Ollama (Agents 1–3): Feasible

| Agent | Input Size | Output Size | Local Feasibility |
|-------|-----------|-------------|-------------------|
| Agent 1 — Overseer | ~8,000 tokens (call only) | ~4,000 tokens | ✅ Works well |
| Agent 2 — Info Page | ~6,000 tokens | ~800 tokens | ✅ Works well |
| Agent 3 — Outline | ~12,000 tokens | ~12,000 tokens | ⚠️ Works, but output may be thin |

Agents 1–3 are feasible on local Ollama because their input contexts are small and
their outputs are within the model's comfortable generation range.

### Local Ollama (Agents 4–6): Problematic

| Agent | Input Size | Output Size | Local Feasibility |
|-------|-----------|-------------|-------------------|
| Agent 4 — Work Packages | ~18,000 tokens | ~18,000 tokens | ❌ Hangs or produces thin output |
| Agent 5 — Budget | ~26,000 tokens | ~8,000 tokens | ❌ Arithmetic errors, refusals |
| Agent 6 — Quality Review | ~36,000 tokens | ~3,000 tokens | ⚠️ May work if context trimmed |

### Recommended Hybrid Approach

The most reliable workflow combines local Ollama for early agents with a capable
AI assistant (Claude, ChatGPT, or GitHub Copilot) for the complex later stages:

```
Agents 1–3:  Run locally with Ollama (mistral:latest)
             → produces: overseer-analysis, project-strategy, info-page, outline

Agent 4–6:   Write manually with AI assistant help
             → produces: work-packages, budget-calculation, quality-review
             → or use the task files as instructions for Claude/ChatGPT
```

This hybrid approach was the actual workflow used to produce the TRUSTEDAI proposal
in this repository:

1. **Agents 1–2** ran on Ollama — output was usable but required significant manual rewriting
2. **Agent 3** ran on Ollama — produced a reasonable outline structure, Section 9 needed rewriting
3. **Agent 4** hung for 2+ hours on `MAX_CONTEXT_CHARS = 20000` — reducing to 8000 didn't fully solve it
4. **Agents 4–6** were written manually with AI assistance — producing the authoritative `work-packages.md`, `budget-calculation.md`, and `quality-review.md`

### Why Cloud LLMs Handle This Better

| Factor | Local Ollama (7B) | Cloud (Claude, GPT-4) |
|--------|-------------------|----------------------|
| Context window | 32K tokens | 100K–200K tokens |
| Parameters | 7 billion | 100B+ (estimated) |
| Working memory | Struggles above ~10K tokens | Comfortable at 50K+ tokens |
| Arithmetic | Frequent errors | Reliable for budget-scale math |
| Cross-referencing | Forgets earlier context | Maintains consistency across docs |
| Generation speed | 5–20 min per agent | 1–5 min per agent |
| Cost | Free (local hardware) | Per-token pricing |
| Privacy | Fully offline | Data sent to cloud |

The trade-off is clear: local is free and private but limited; cloud is powerful but
costs money and sends your data externally.

---

## 6. Configuration Reference

### Runner Script Settings

Both `run_proposal_agents.py` and `mega_proposal_runner.py` share these settings:

```python
MODEL             = "mistral"     # General-purpose model (NOT code)
MAX_CONTEXT_CHARS = 8000          # Trim each doc to this before sending
NUM_CTX           = 32768         # Ollama context window in tokens
MIN_COMPLETE_SIZE = 500           # Minimum bytes to consider output valid
```

### Tuning for Your Hardware

| Your Setup | Recommended Settings |
|------------|---------------------|
| 8 GB VRAM GPU | `MODEL = "mistral"`, `NUM_CTX = 32768`, `MAX_CONTEXT_CHARS = 8000` |
| 16 GB VRAM GPU | `MODEL = "mistral"`, `NUM_CTX = 65536`, `MAX_CONTEXT_CHARS = 12000` |
| CPU only (16 GB RAM) | `MODEL = "mistral"`, `NUM_CTX = 16384`, `MAX_CONTEXT_CHARS = 6000` |
| CPU only (8 GB RAM) | `MODEL = "llama3.2"` (2 GB), `NUM_CTX = 8192`, `MAX_CONTEXT_CHARS = 4000` |

### Warning Signs During Execution

| Sign | Meaning | Action |
|------|---------|--------|
| Agent runs >30 minutes | Context too large or model struggling | Reduce `MAX_CONTEXT_CHARS` |
| Output is <500 bytes | Model produced placeholder/refusal | Re-run with `--force`, check model choice |
| Terminal shows no output for >10 minutes | Model may be stuck in a loop | Kill and reduce `NUM_CTX` |
| "This task is too complex" in output | Model hit its capacity ceiling | Switch to manual mode for this agent |
| Budget totals don't add up | Arithmetic beyond model capacity | Write budget manually |

---

## 7. Quick Fix Checklist

If the agents aren't working, check these in order:

- [ ] **Is Ollama running?** — `ollama list` should show your model
- [ ] **Is the model `mistral` (not `deepseek-coder`)?** — code models cannot write proposals
- [ ] **Are Python packages installed?** — `pip install ollama pypdf`
- [ ] **Is there a call document in `call/`?** — the agents need input to analyse
- [ ] **Is `MAX_CONTEXT_CHARS` set to 8000?** — higher values cause hangs on later agents
- [ ] **Are you running agents in order?** — each agent reads all predecessor outputs
- [ ] **Is the output file already there?** — use `--force` to regenerate existing files

---

Generated: 2026-02-22 | Repository: project-proposal-workflow
