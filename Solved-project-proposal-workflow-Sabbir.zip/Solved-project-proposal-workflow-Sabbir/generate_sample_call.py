#!/usr/bin/env python3
"""Generate a realistic sample EU Horizon Europe funding call PDF (~10 pages)."""

from fpdf import FPDF
from pathlib import Path

class CallPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 9)
        self.set_text_color(0, 51, 153)
        self.cell(0, 6, "HORIZON EUROPE  -  Work Programme 2025-2027", align="L")
        self.cell(0, 6, "HORIZON-CL4-2025-DIGITAL-01-03", align="R", new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(0, 51, 153)
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(128)
        self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

    def section_title(self, title, level=1):
        if level == 1:
            self.set_font("Helvetica", "B", 14)
            self.set_text_color(0, 51, 153)
            self.ln(4)
            self.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
            self.set_draw_color(0, 51, 153)
            self.line(10, self.get_y(), 200, self.get_y())
            self.ln(3)
        elif level == 2:
            self.set_font("Helvetica", "B", 12)
            self.set_text_color(0, 51, 153)
            self.ln(3)
            self.cell(0, 8, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(2)
        else:
            self.set_font("Helvetica", "B", 10)
            self.set_text_color(51, 51, 51)
            self.ln(2)
            self.cell(0, 7, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(1)

    def body_text(self, text):
        self.set_font("Helvetica", "", 10)
        self.set_text_color(0)
        self.multi_cell(0, 5.5, text)
        self.ln(2)

    def bullet(self, text):
        self.set_font("Helvetica", "", 10)
        self.set_text_color(0)
        x = self.get_x()
        self.cell(6, 5.5, "-")
        self.multi_cell(0, 5.5, text)
        self.ln(1)

    def key_value(self, key, value):
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(51, 51, 51)
        self.cell(55, 6, key + ":")
        self.set_font("Helvetica", "", 10)
        self.set_text_color(0)
        self.multi_cell(0, 6, value)
        self.ln(1)


def build_pdf():
    pdf = CallPDF()
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(auto=True, margin=20)
    pdf.add_page()

    # -- COVER / TITLE --
    pdf.ln(15)
    pdf.set_font("Helvetica", "B", 22)
    pdf.set_text_color(0, 51, 153)
    pdf.multi_cell(0, 12, "HORIZON EUROPE\nCall for Proposals", align="C")
    pdf.ln(6)
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0)
    pdf.multi_cell(0, 10, "HORIZON-CL4-2025-DIGITAL-01-03", align="C")
    pdf.ln(4)
    pdf.set_font("Helvetica", "", 13)
    pdf.set_text_color(51, 51, 51)
    pdf.multi_cell(0, 8,
        "Trustworthy Artificial Intelligence for Resilient\n"
        "Digital Infrastructure and Public Services",
        align="C")
    pdf.ln(10)

    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(0)
    pdf.key_value("Cluster", "4  -  Digital, Industry and Space")
    pdf.key_value("Destination", "A globally competitive, green and digital Europe")
    pdf.key_value("Type of Action", "Research and Innovation Action (RIA)")
    pdf.key_value("Funding Rate", "100% of eligible costs")
    pdf.key_value("Budget for this topic", "EUR 8,000,000 (indicative: 2 projects)")
    pdf.key_value("Max EU contribution per project", "EUR 4,000,000")
    pdf.key_value("Project Duration", "36 months")
    pdf.key_value("Opening Date", "15 January 2025")
    pdf.key_value("Deadline", "23 September 2025, 17:00 Brussels time")
    pdf.key_value("Evaluation Procedure", "Single-stage submission")

    # -- PAGE 2-3: TOPIC DESCRIPTION --
    pdf.add_page()
    pdf.section_title("1. Topic Description and Scope")
    pdf.body_text(
        "The rapid deployment of artificial intelligence across critical digital infrastructure "
        "and public services creates both opportunities and risks. This topic addresses the need "
        "for trustworthy, explainable, and resilient AI systems that can be deployed in high-stakes "
        "environments such as public administration, healthcare informatics, smart energy grids, "
        "and cybersecurity monitoring."
    )
    pdf.body_text(
        "Proposals should develop novel AI frameworks, methods, or tools that demonstrably improve "
        "the trustworthiness and resilience of digital systems. Research should combine foundational "
        "AI advances with practical validation in real-world pilot environments."
    )

    pdf.section_title("1.1 Specific Objectives", level=2)
    pdf.body_text("Proposals must address ALL of the following objectives:")
    pdf.bullet("Develop explainable AI (XAI) methods suitable for high-stakes decision support in public services, ensuring outputs are interpretable by non-technical stakeholders.")
    pdf.bullet("Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure.")
    pdf.bullet("Create privacy-preserving AI techniques (e.g., federated learning, differential privacy) that comply with GDPR while maintaining model performance.")
    pdf.bullet("Build open-source AI toolkits and benchmarks for trustworthiness assessment, covering fairness, robustness, transparency, and accountability dimensions.")
    pdf.bullet("Demonstrate the developed solutions through at least two real-world pilot deployments in different EU Member States, involving end-user organisations.")

    pdf.section_title("1.2 Expected Outcomes and Impact", level=2)
    pdf.body_text(
        "Projects funded under this topic are expected to contribute to the following outcomes:"
    )
    pdf.bullet("Increased trust in AI-based public services, measured through user acceptance studies and compliance with the EU AI Act risk categories.")
    pdf.bullet("Improved cyber-resilience of critical digital infrastructure through AI-powered threat detection with demonstrated reduction in mean-time-to-detect (MTTD) by at least 40%.")
    pdf.bullet("At least 3 open-source tools or libraries published under permissive licences (Apache 2.0 or equivalent) and registered in the EU AI-on-Demand platform.")
    pdf.bullet("Policy recommendations for AI governance in public services, validated with at least 2 national or regional public authorities.")
    pdf.bullet("Contribution to European standardisation bodies (CEN/CENELEC, ETSI) with at least one standards-track document submitted during the project lifetime.")

    pdf.body_text(
        "In the longer term, the action is expected to strengthen Europe's position as a global leader "
        "in trustworthy AI, reduce dependency on non-European AI technology, and support the uptake of "
        "AI in public administration while safeguarding fundamental rights."
    )

    # -- PAGE 4: ELIGIBILITY & CONSORTIUM --
    pdf.add_page()
    pdf.section_title("2. Eligibility and Admissibility Conditions")

    pdf.section_title("2.1 Consortium Composition", level=2)
    pdf.body_text(
        "Proposals must be submitted by a consortium of at least 3 independent legal entities "
        "established in at least 3 different EU Member States or Horizon Europe Associated Countries. "
        "The consortium must include:"
    )
    pdf.bullet("At least one university or public research organisation with demonstrated expertise in AI and/or cybersecurity research (evidenced by peer-reviewed publications in the last 5 years).")
    pdf.bullet("At least one SME or start-up (as defined in the EU SME definition, Commission Recommendation 2003/361/EC) active in AI technology development or digital services.")
    pdf.bullet("At least one public administration body, public service provider, or critical infrastructure operator that will serve as a pilot deployment site.")

    pdf.body_text(
        "Participation of entities from non-associated third countries is possible but they will "
        "not receive EU funding. The coordinator must be established in an EU Member State or "
        "Associated Country."
    )

    pdf.section_title("2.2 Other Eligibility Conditions", level=2)
    pdf.bullet("Maximum project duration: 36 months.")
    pdf.bullet("Maximum EU contribution: EUR 4,000,000 per project.")
    pdf.bullet("Each partner must contribute a minimum of 3 person-months to the project.")
    pdf.bullet("Subcontracting may not exceed 20% of total direct costs per partner.")
    pdf.bullet("Equipment costs are eligible only if specifically justified and essential for the research. Depreciation rules apply for equipment with a useful life exceeding the project duration.")
    pdf.bullet("The proposal (Part B) must not exceed 45 pages (excluding annexes).")

    # -- PAGE 5: EVALUATION CRITERIA --
    pdf.add_page()
    pdf.section_title("3. Award Criteria and Evaluation")

    pdf.body_text(
        "Proposals will be evaluated by independent expert panels using the standard Horizon Europe "
        "evaluation criteria. Each criterion is scored from 0 to 5. The overall threshold is 10/15, "
        "with a minimum of 3/5 for each individual criterion."
    )

    pdf.section_title("3.1 Excellence (Threshold: 3/5, Weight: 40%)", level=2)
    pdf.bullet("Clarity and depth of the research objectives and their alignment with the call scope.")
    pdf.bullet("Novelty and ambition of the proposed AI methods (beyond state of the art).")
    pdf.bullet("Soundness and credibility of the proposed methodology, including appropriate use of interdisciplinary approaches.")
    pdf.bullet("Quality of the open science practices (data management, open-source publication, FAIR principles).")

    pdf.section_title("3.2 Impact (Threshold: 3/5, Weight: 30%)", level=2)
    pdf.bullet("Credibility and scale of the expected scientific, economic, and societal impact.")
    pdf.bullet("Effectiveness of the exploitation and dissemination plan, including pathways to market and policy uptake.")
    pdf.bullet("Contribution to EU policy objectives (AI Act, Digital Decade, European Data Strategy).")
    pdf.bullet("Inclusiveness and diversity of the pilot deployment contexts (geographic, sectoral).")

    pdf.section_title("3.3 Implementation (Threshold: 3/5, Weight: 30%)", level=2)
    pdf.bullet("Quality and coherence of the work plan (WPs, tasks, deliverables, milestones).")
    pdf.bullet("Appropriateness and justification of the allocated resources (budget, personnel, equipment).")
    pdf.bullet("Complementarity and balance of the consortium, including role clarity and governance structure.")
    pdf.bullet("Adequacy of risk management, including identification of critical risks and mitigation measures.")

    # -- PAGE 6: FINANCIAL PROVISIONS --
    pdf.add_page()
    pdf.section_title("4. Financial Provisions")

    pdf.section_title("4.1 Funding Model", level=2)
    pdf.body_text(
        "This is a Research and Innovation Action (RIA). The EU funding rate is 100% of eligible "
        "costs. Indirect costs (overhead) are calculated as a flat rate of 25% of eligible direct "
        "costs, excluding subcontracting and costs of in-kind contributions not used on the premises."
    )

    pdf.section_title("4.2 Eligible Cost Categories", level=2)
    pdf.body_text("The following cost categories are eligible under this call:")
    pdf.bullet("Personnel costs: Actual costs based on gross salary plus mandatory employer charges. Person-month definition: 140 productive hours per month. Each staff member's hourly rate must be documented and auditable.")
    pdf.bullet("Travel and subsistence: Actual costs for project-related travel, including consortium meetings (minimum 2 per year), conferences, and research visits. Per diem rates must not exceed the institution's standard rates or the European Commission daily allowance tables.")
    pdf.bullet("Equipment: Depreciation costs only, unless the equipment is fully consumed during the project. Depreciation is calculated as: Eligible cost = Purchase price x (months of project use / total useful life in months). Equipment items above EUR 15,000 require individual justification.")
    pdf.bullet("Other direct costs: Consumables, software licenses, publication charges (including Open Access fees), subcontracting, audit costs (mandatory for EU contributions above EUR 325,000 per partner).")
    pdf.bullet("Indirect costs: Flat rate of 25% applied automatically to all direct costs except subcontracting and in-kind contributions not used on premises.")

    pdf.section_title("4.3 Budget Ceilings and Limits", level=2)
    pdf.bullet("Maximum EU contribution per project: EUR 4,000,000.")
    pdf.bullet("Subcontracting limit: Maximum 20% of total eligible direct costs.")
    pdf.bullet("No minimum budget per partner, but each partner must have a meaningful role justified by at least 3 person-months of effort.")
    pdf.bullet("Financial support to third parties (cascade funding / open calls) is NOT allowed under this topic.")

    # -- PAGE 7: DELIVERABLES AND MILESTONES --
    pdf.add_page()
    pdf.section_title("5. Expected Deliverables and Milestones")

    pdf.section_title("5.1 Mandatory Deliverables", level=2)
    pdf.body_text("All projects must produce at minimum the following deliverables:")
    pdf.bullet("D1.1  -  Project Management Plan (Month 2, Report, Public)")
    pdf.bullet("D1.2  -  Data Management Plan, initial version (Month 3, DMP, Public)")
    pdf.bullet("D1.3  -  Data Management Plan, final version (Month 34, DMP, Public)")
    pdf.bullet("D2.x  -  State-of-the-art report and requirements analysis (Month 6, Report, Public)")
    pdf.bullet("Dx.x  -  Pilot deployment reports for each pilot site (Month 30, Report, Confidential)")
    pdf.bullet("Dx.x  -  Open-source toolkit release with documentation (Month 32, Software/Dataset, Public)")
    pdf.bullet("Dx.x  -  Policy recommendations report (Month 34, Report, Public)")
    pdf.bullet("Dx.x  -  Final project report including lessons learned (Month 36, Report, Public)")

    pdf.section_title("5.2 Mandatory Milestones", level=2)
    pdf.body_text("Projects must define at minimum the following milestones:")
    pdf.bullet("MS1  -  Requirements and architecture finalised (Month 6). Verification: Requirements document approved by all partners and pilot sites.")
    pdf.bullet("MS2  -  Core AI components v1.0 ready for integration (Month 14). Verification: Successful integration test report with defined KPIs met.")
    pdf.bullet("MS3  -  Pilot deployments launched at all sites (Month 20). Verification: Deployment certificates signed by pilot site operators.")
    pdf.bullet("MS4  -  Pilot evaluation complete, results validated (Month 30). Verification: Evaluation report with statistical analysis of KPI achievement.")
    pdf.bullet("MS5  -  Exploitation roadmap finalised (Month 34). Verification: Signed exploitation agreements or letters of intent from at least 2 consortium members.")

    # -- PAGE 8: CROSS-CUTTING PRIORITIES --
    pdf.add_page()
    pdf.section_title("6. Cross-Cutting Priorities")

    pdf.section_title("6.1 Open Science", level=2)
    pdf.body_text(
        "Proposals must adopt open science practices in line with the Horizon Europe requirements. "
        "This includes: immediate open access to peer-reviewed publications (no embargo period); "
        "FAIR management of research data with deposition in trusted repositories; open-source release "
        "of software tools under permissive licences. A Data Management Plan must be submitted within "
        "3 months of the project start."
    )

    pdf.section_title("6.2 Ethics and Responsible AI", level=2)
    pdf.body_text(
        "Given the sensitivity of AI deployment in public services, proposals must include a dedicated "
        "ethics work package or task addressing: GDPR compliance and data protection impact assessment; "
        "algorithmic bias detection and mitigation strategy; human oversight mechanisms in AI-assisted "
        "decision-making; alignment with the EU Ethics Guidelines for Trustworthy AI; and assessment "
        "against EU AI Act risk categories. An ethics advisory board with at least one external member "
        "is recommended."
    )

    pdf.section_title("6.3 Dissemination and Communication", level=2)
    pdf.body_text(
        "Proposals must include a comprehensive dissemination and communication plan with: "
        "at least 6 peer-reviewed publications in high-impact journals or conferences; "
        "at least 2 policy briefs targeting EU and national policy-makers; "
        "a public project website operational within 2 months of project start; "
        "active engagement with the European AI community through workshops, webinars, and "
        "the AI-on-Demand platform; social media presence and regular public updates."
    )

    pdf.section_title("6.4 Gender and Inclusiveness", level=2)
    pdf.body_text(
        "Proposals should integrate the gender dimension in R&I content (e.g., bias in AI systems "
        "affecting different demographic groups). Consortia are encouraged to aim for gender balance "
        "in project teams and leadership positions. Pilot deployments should consider diverse user "
        "groups and accessibility requirements."
    )

    # -- PAGE 9: SUBMISSION PROCEDURES --
    pdf.add_page()
    pdf.section_title("7. Submission Procedures")

    pdf.body_text(
        "Proposals must be submitted electronically via the EU Funding & Tenders Portal "
        "(https://ec.europa.eu/info/funding-tenders/opportunities/portal/) before the deadline "
        "of 23 September 2025, 17:00:00 Brussels time (CET). Late submissions will not be accepted."
    )

    pdf.section_title("7.1 Proposal Structure (Part B)", level=2)
    pdf.body_text("The technical description (Part B) must follow this structure:")
    pdf.bullet("Section 1  -  Excellence: Scientific/technological quality and novelty of the approach. Maximum 15 pages.")
    pdf.bullet("Section 2  -  Impact: Expected impact and measures to maximise it. Maximum 10 pages.")
    pdf.bullet("Section 3  -  Implementation: Work plan, consortium, resources. Maximum 20 pages.")
    pdf.bullet("Section 3.1  -  Work Plan: Work packages, tasks, deliverables, milestones, Gantt chart, PERT diagram.")
    pdf.bullet("Section 3.2  -  Consortium description and management structure.")
    pdf.bullet("Section 3.3  -  Resource allocation and budget justification table.")
    pdf.bullet("Section 4  -  Ethics: Self-assessment table and ethics issues description (no page limit, not counted towards the 45-page maximum).")

    pdf.section_title("7.2 Indicative Timetable", level=2)
    pdf.key_value("Call opening", "15 January 2025")
    pdf.key_value("Submission deadline", "23 September 2025, 17:00 CET")
    pdf.key_value("Evaluation period", "October - December 2025")
    pdf.key_value("Results notification", "February 2026")
    pdf.key_value("Grant agreement preparation", "March - May 2026")
    pdf.key_value("Earliest project start", "1 June 2026")

    # -- PAGE 10: CONTACTS & ANNEXES --
    pdf.add_page()
    pdf.section_title("8. Further Information and Contacts")

    pdf.body_text(
        "For questions regarding this call topic, please contact the European Commission "
        "project officer team via the Funding & Tenders Portal messaging system. General enquiries "
        "about Horizon Europe can be directed to the Research Enquiry Service (https://rea.ec.europa.eu)."
    )

    pdf.section_title("8.1 Relevant EU Policy Documents", level=2)
    pdf.bullet("Regulation (EU) 2024/1689  -  Artificial Intelligence Act")
    pdf.bullet("Regulation (EU) 2016/679  -  General Data Protection Regulation (GDPR)")
    pdf.bullet("European Commission: Coordinated Plan on AI (2024 update)")
    pdf.bullet("European Commission: Digital Decade Policy Programme 2030")
    pdf.bullet("European Commission: European Data Strategy (COM/2020/66)")
    pdf.bullet("Ethics Guidelines for Trustworthy AI  -  AI HLEG (2019)")

    pdf.section_title("8.2 Reference Documents for Applicants", level=2)
    pdf.bullet("Horizon Europe Model Grant Agreement (version 1.1, April 2024)")
    pdf.bullet("Annotated Grant Agreement (AGA)  -  Financial rules and reporting guidance")
    pdf.bullet("Guide for Applicants: Horizon Europe Research and Innovation Actions")
    pdf.bullet("EU Financial Regulation (2018/1046)  -  Rules on eligibility of costs")
    pdf.bullet("Open Science Policy Platform recommendations for Horizon Europe")

    pdf.ln(6)
    pdf.set_font("Helvetica", "I", 10)
    pdf.set_text_color(100)
    pdf.multi_cell(0, 6,
        "This document is a call for proposals under the Horizon Europe Framework Programme. "
        "The European Commission reserves the right to modify the terms of this call. "
        "Only the version published on the Funding & Tenders Portal is legally binding."
    )

    pdf.ln(4)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(0, 51, 153)
    pdf.cell(0, 8, "--- END OF CALL DOCUMENT ---", align="C")

    # Save
    out = Path(__file__).parent / "call" / "HORIZON-CL4-2025-DIGITAL-01-03.pdf"
    pdf.output(str(out))
    print(f"PDF saved: {out}  ({out.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    build_pdf()
