# Usage Guide — Project Proposal Workflow System

> Step-by-step guide for generating a complete funding proposal

---

## Option A: Using Claude / ChatGPT (Manual Mode)

### Step 1 — Start a Session
1. Open a new Claude or ChatGPT conversation
2. Copy-paste the full prompt from `SESSION_INIT_PROMPT.md`
3. Wait for: `✅ Project Proposal Workflow System is ready.`

### Step 2 — Provide the Funding Call
- Upload your call document (PDF) or paste the text directly
- Say: `@proposal-agent /start` or simply begin with `/overseer`

### Step 3 — Run Agents in Sequence
Run each command one at a time, waiting for completion before the next:

```
@proposal-agent /overseer        → produces overseer-analysis.md + project-strategy.md
@proposal-agent /info-page       → produces project-info-page.md
@proposal-agent /outline         → produces project-outline.md
@proposal-agent /work-packages   → produces work-packages.md
@proposal-agent /budget          → produces budget-calculation.md
@proposal-agent /review          → produces quality-review.md
```

### Step 4 — Save Outputs
Copy-paste each output into the corresponding file in `docs/`.

### Step 5 — Review and Iterate
- Read `docs/quality-review.md` for improvement suggestions
- Edit documents manually or re-run specific agents with corrections

---

## Option B: Using Local Ollama (Automated Mode)

### Prerequisites
1. Install [Ollama](https://ollama.ai/)
2. Pull a model: `ollama pull mistral`
3. Install Python dependencies: `pip install ollama pypdf`
4. Place your funding call PDF in the `call/` directory

### Run All 6 Agents
```bash
python run_proposal_agents.py           # interactive (pauses between agents)
python run_proposal_agents.py -y        # non-interactive (runs all automatically)
```

### Run a Specific Agent
```bash
python run_proposal_agents.py --agent 1    # run only the Overseer
python run_proposal_agents.py --agent 6    # run only the Quality Review
```

### Resume from a Specific Agent
```bash
python run_proposal_agents.py --from 3     # run agents 3, 4, 5, 6
```

### Alternative: Mega Runner (Self-Contained)
The mega runner has all agent instructions embedded — no need for task files:
```bash
python mega_proposal_runner.py             # same CLI options apply
python mega_proposal_runner.py --agent 2
python mega_proposal_runner.py --from 4
```

---

## Two Runner Files — When to Use Which

| Feature | `run_proposal_agents.py` | `mega_proposal_runner.py` |
|---------|--------------------------|---------------------------|
| Agent instructions | Loaded from `tasks/` files | Embedded inline |
| Templates/Skeletons | Loaded and sent as context | Loaded and sent as context |
| Best for | Iterating on task files | Single-file deployment |
| Customisation | Edit task files separately | Edit agent blocks in one file |

Both runners produce identical output in `docs/` and use the same system prompt.

---

## Output Files

After a full run, `docs/` will contain:

| File | Agent | Description |
|------|-------|-------------|
| `overseer-analysis.md` | Agent 1 | Strategic call analysis and project concept |
| `project-strategy.md` | Agent 1 | Concise framework for subsequent agents |
| `project-info-page.md` | Agent 2 | 1-page A4 summary (≤600 words) |
| `project-outline.md` | Agent 3 | Full proposal narrative (15–25 pages) |
| `work-packages.md` | Agent 4 | Detailed work plan with deliverables (10–20 pages) |
| `budget-calculation.md` | Agent 5 | Budget with per-partner breakdown (8–12 pages) |
| `quality-review.md` | Agent 6 | Consistency check and scoring prediction |

---

## Tips

- **Model choice**: Change `MODEL` in the runner script to use a different Ollama model
- **Context size**: Adjust `MAX_CONTEXT_CHARS` if your model handles more/less context
- **Timeout**: Increase `REQUEST_TIMEOUT` if agents time out on slower hardware
- **Iteration**: After the review, fix issues manually then re-run agents 3–6 for polishing

---

Generated: 2026-02-20
