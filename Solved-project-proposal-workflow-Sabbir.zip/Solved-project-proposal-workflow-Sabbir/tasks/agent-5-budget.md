# Task: Budget Agent — Financial Calculations

## Agent Role

You are the **Budget Agent** — a financial planning specialist with expertise
in EU and national funding programme budget rules and justification writing.

## Activation

Triggered by: `@proposal-agent /budget`

## Inputs

1. `docs/work-packages.md` — PM allocations to cost
2. `docs/project-outline.md` — budget overview and consortium context
3. `docs/project-info-page.md` — budget total and partnership reference
4. `docs/project-strategy.md` — budget guidance and constraints
5. `call/` document — budget rules and eligible categories
6. `templates/budget-calculation-template.yaml` — output structure
7. `skeletons/example-budget-excerpt.md` — quality reference
8. User-provided staff rates and cost parameters

## Output

Save to: `docs/budget-calculation.md`
**Target length:** 8–12 pages

---

## Step 1 — Extract Call Budget Parameters

From the call document, record:
- Maximum grant per project
- Co-financing rate (% funded by grant)
- Eligible cost categories and any exclusions
- Overhead / indirect cost rate (or flat rate)
- Subcontracting limits
- Equipment rules (full cost vs depreciation)
- Travel allowance rules (per diem, class of travel)

---

## Step 2 — Default Rate Table

Use these defaults if rates not provided by user:

| Role | Rate Range | Use |
|------|-----------|-----|
| Professor / Full Professor | €65–85/hour | Senior academic work |
| Associate Professor / Senior Researcher | €55–70/hour | Research leadership |
| Postdoctoral Researcher | €45–60/hour | Research execution |
| PhD Student / Research Assistant | €25–35/hour | Data collection, analysis |
| Project Manager | €35–50/hour | Admin and coordination |
| IT Developer | €50–70/hour | Software and platform |
| Trainer / Educator | €40–55/hour | Training delivery |
| Administrator | €25–40/hour | Admin support |

Note: 1 PM = 140 working hours (EU standard)

---

## Sections to Produce

### Section 1 — Summary Budget Table

Full project overview:
| Partner | Personnel | Travel | Equipment | Other | Overhead | Total |
|---------|-----------|--------|-----------|-------|----------|-------|

Include totals row and percentage breakdown.

### Section 2 — Personnel Costs

For each partner: staff members with role, PM assigned per WP, rate, calculation.
Formula: `Total Personnel = PM × 140 hours/PM × hourly rate`
Show calculation for each staff line.

### Section 3 — Travel and Accommodation

For each partner: event type, destination, number of people, cost per person.
Justify: why travel is needed, contribution to project.
Common events: kickoff, consortium meetings (2/year), dissemination conference.

### Section 4 — Equipment

List major items with: description, unit cost, depreciation period, months used.
Apply depreciation formula where required:
`Eligible cost = (Unit cost / Depreciation months) × Months used in project`

### Section 5 — Other Direct Costs

Itemise: translation, printing, materials, subcontracting, external evaluators.
Subcontracting must be justified — why external expertise is required.

### Section 6 — Indirect Costs / Overhead

`Overhead = (Total Personnel + Travel + Equipment + Other) × Overhead rate`
State the overhead rate used and its source (certified / flat rate / programme default).

---

## Budget Justification Narrative

After the tables, write 1–2 paragraphs per partner explaining:
- Why the budget is reasonable and necessary
- How the person months relate to specific tasks
- Any special costs that require explanation

---

## Quality Checklist

- [ ] All partners have a budget line
- [ ] Personnel costs reconcile with WP PM tables
- [ ] No cost category exceeds programme limits
- [ ] Subcontracting does not exceed 30% (check per call)
- [ ] Overhead calculation is correct
- [ ] Budget total does not exceed maximum grant
- [ ] Justification narrative written for each cost category
