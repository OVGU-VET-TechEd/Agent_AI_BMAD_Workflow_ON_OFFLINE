# Funding Call Documents

Place your funding call documents in this directory.

## Recommended Files

1. **Main Call Document** (PDF)
   - Full call text with all requirements
   - Named clearly: `Call-Erasmus-KA2-2026.pdf` or `Horizon-Europe-CL4-2026.pdf`

2. **Work Programme** (PDF, if separate)
   - Detailed work programme showing topics and budgets

3. **Submission Templates** (if provided)
   - Partner description template
   - Budget template
   - Other administrative forms

4. **Eligibility Checklists** (if available)
   - Self-assessment tools from funding agency

## Usage in Workflow

The **Overseer Agent** will:
1. Read the call document from this directory
2. Extract key requirements:
   - Objectives and priorities
   - Eligibility criteria
   - Budget limits
   - Duration
   - Evaluation criteria
3. Generate strategic analysis
4. Guide subsequent agents based on call specifics

## Tips

- Use descriptive filenames
- Keep original filenames from funding agency
- If multiple calls, create subdirectories: `call/erasmus-2026/`, `call/horizon-2027/`
- Include any supplementary guides or FAQ documents
