# Agent Commands Reference

> Complete reference for all 6 proposal agent commands

---

## Command Syntax

```
@proposal-agent /[command]
```

All commands are run sequentially. Each agent reads the outputs of all previous agents.

---

## Agent 1 — Overseer Agent

**Command:** `@proposal-agent /overseer`

**Purpose:** Analyse the funding call and design the strategic blueprint for the proposal.

**Inputs:** Funding call document from `call/`

**Outputs:**
- `docs/overseer-analysis.md` — Full strategic analysis (call requirements, project concept, consortium design, WP architecture, risks)
- `docs/project-strategy.md` — Concise 1-page framework for subsequent agents

**Key Sections:**
1. Call Requirements Summary
2. Strategic Opportunities
3. Proposed Project Concept (title, acronym, objectives)
4. Consortium Design
5. Work Package Architecture
6. Risk and Compliance Flags
7. Handoff Brief for Agent 2

---

## Agent 2 — Info Page Agent

**Command:** `@proposal-agent /info-page`

**Purpose:** Distill the project concept into a compelling 1-page A4 summary.

**Inputs:** `docs/overseer-analysis.md`, `docs/project-strategy.md`

**Output:** `docs/project-info-page.md`

**Constraints:**
- Maximum 600 words
- Must fit on 1 page A4
- All objectives must be SMART

**Sections:** Title, Acronym, Short Description, Objectives, Outputs, Outcomes, Partnership, Budget & Duration

---

## Agent 3 — Outline Agent

**Command:** `@proposal-agent /outline`

**Purpose:** Write the full proposal narrative document.

**Inputs:** All previous docs

**Output:** `docs/project-outline.md`

**Target:** 15–25 pages

**Sections:**
1. Executive Summary (written last)
2. Context and Problem Analysis
3. Objectives and Methodology
4. Expected Impact
5. Consortium Description
6. Work Plan Overview
7. Budget Overview
8. Risk Management
9. Ethics, Data, and Sustainability

---

## Agent 4 — Work Package Agent

**Command:** `@proposal-agent /work-packages`

**Purpose:** Transform the outline into a concrete, actionable work plan.

**Inputs:** All previous docs

**Output:** `docs/work-packages.md`

**Target:** 10–20 pages

**Structure per WP:**
- Header (number, title, lead, duration, PM)
- Objectives (3–5)
- Description of Work (150–250 words)
- Tasks (4–8 per WP) with leads, contributors, dependencies
- Deliverables table (typed: R, DATA, DEMO, SW, WEB, G, TOOL, CERT)
- Milestones table
- Risks and dependencies

**Required Tables:**
- WP Summary (all WPs)
- PM Allocation by Partner

---

## Agent 5 — Budget Agent

**Command:** `@proposal-agent /budget`

**Purpose:** Calculate the complete project budget with justification.

**Inputs:** All previous docs (especially `work-packages.md`)

**Output:** `docs/budget-calculation.md`

**Target:** 8–12 pages

**Financial Defaults:**
| Parameter | Default |
|-----------|---------|
| Hours per PM | 140 |
| Overhead rate | 25% flat |
| Professor rate | €75/hour |
| Researcher rate | €55/hour |
| Postdoc rate | €45/hour |
| PhD rate | €30/hour |
| Project Manager | €40/hour |
| Admin | €28/hour |

**Required Sections:**
1. Budget Summary Table
2. Personnel Costs (per partner, per WP)
3. Travel and Subsistence
4. Equipment and Infrastructure
5. Other Direct Costs
6. Indirect Costs / Overhead
7. Budget Justification Narrative

---

## Agent 6 — Quality Review Agent

**Command:** `@proposal-agent /review`

**Purpose:** Final consistency and quality check of the entire proposal package.

**Inputs:** All 5 previous documents + original call

**Output:** `docs/quality-review.md`

**Target:** 3–5 pages

**Review Areas:**
1. Internal Consistency (same data across all docs)
2. Call Compliance (eligibility, budget limits, mandatory sections)
3. Quality Assessment (per-document rating)
4. Gap Analysis (thin sections, missing references)
5. Scoring Prediction (strongest/weakest areas)

**Output Format:**
- Overall Assessment: PASS / PASS WITH REVISIONS / FAIL
- Consistency Matrix
- Compliance Checklist
- Priority Action List (Critical / Major / Minor)
- Scoring Prediction

---

## Running Order

Always run in this order — each agent depends on the outputs of previous agents:

```
/overseer → /info-page → /outline → /work-packages → /budget → /review
```

You can re-run individual agents after making manual edits. For example:
- Edit the info page, then re-run `/outline` onwards
- Fix budget issues, then re-run `/review` to recheck

---

Generated: 2026-02-20
