# Example: Budget Calculation Excerpt
## EcoVET-AI Project — UPM (P1) Detailed Budget
### Quality reference for Budget Agent output

---

## Full Project Budget Summary

| Partner | Personnel | Travel | Equipment | Other | Overhead (25%) | **Total** |
|---------|-----------|--------|-----------|-------|----------------|-----------|
| UPM (P1) | €267,750 | €19,600 | €9,800 | €8,500 | €76,413 | **€382,063** |
| HAN (P2) | €238,350 | €17,200 | €6,500 | €7,800 | €67,463 | **€337,313** |
| LUT (P3) | €207,900 | €16,100 | €5,200 | €6,900 | €59,025 | **€295,125** |
| MBO (P4) | €196,875 | €15,800 | €4,800 | €7,200 | €56,169 | **€280,844** |
| TechLearn (P5) | €234,000 | €14,600 | €18,500 | €11,500 | €69,650 | **€348,250** |
| **Total** | **€1,144,875** | **€83,300** | **€44,800** | **€41,900** | **€328,720** | **€1,643,595** |

*Co-financing (UPM in-kind contributions): €206,405 | **Total Project Cost: €1,850,000***

---

## UPM (P1) Detailed Budget

**Institution:** Technical University of Madrid | **Role:** Coordinator | **Total PM:** 50

### Personnel Costs

#### Staff Allocation

| Name/Role | WP1 PM | WP2 PM | WP3 PM | WP4 PM | WP5 PM | WP6 PM | Total PM | Rate (€/h) | Total (€) |
|-----------|--------|--------|--------|--------|--------|--------|----------|------------|-----------|
| Prof. García (Project Lead) | 3 | 3 | 2 | 2 | 1 | 3 | 14 | €82 | €161,672 |
| Dr. Fernández (Researcher) | 2 | 4 | 3 | 4 | 2 | 3 | 18 | €52 | €131,040 |
| Ms. Santos (Project Manager) | 2 | 2 | 2 | 2 | 1 | 2 | 11 | €38 | €58,520 |
| Mr. Ruiz (Admin) | 1 | 1 | 1 | 2 | 1 | 1 | 7 | €29 | €28,420 |
| **Total** | **8** | **10** | **8** | **10** | **5** | **9** | **50** | | **€379,652** |

*Note: Calculation = PM × 140 hours/PM × hourly rate*

**Prof. García example:** 14 PM × 140 h × €82/h = €160,720 (rounded to €161,672 with holiday provision)

**Total UPM Personnel: €267,750**
*(Rates reflect UPM certified personnel cost system, available on request)*

---

### Travel and Accommodation

| Event | Destination | Participants | Cost/Person | Total |
|-------|------------|-------------|-------------|-------|
| Kickoff Meeting (M2) | Madrid (host) | 2 staff | €450 | €900 |
| Consortium Meeting 1 (M10) | Amsterdam | 2 staff | €1,250 | €2,500 |
| Consortium Meeting 2 (M18) | Tampere | 2 staff | €1,400 | €2,800 |
| Consortium Meeting 3 (M26) | Rotterdam | 2 staff | €1,250 | €2,500 |
| International Dissemination Conference | Brussels | 2 staff | €1,450 | €2,900 |
| Industry Advisory Panel Workshop (M10) | Madrid (host) | 1 staff | €350 | €350 |
| Final Event (M30) | Madrid (host) | 1 staff | €380 | €380 |
| Short-term study visits (×3) | Various | 1 staff × 3 | €1,424 avg | €4,270 |
| **Total Travel** | | | | **€16,600** |
| Per diem allowances (EU rates) | | | | **€3,000** |
| **Total Travel & Accommodation** | | | | **€19,600** |

*All flights at economy class per Erasmus+ rules. Per diem at EU standard rates.*

---

### Equipment

| Item | Unit Cost | Depreciation (months) | Months Used | Eligible Cost |
|------|-----------|----------------------|-------------|---------------|
| High-performance workstation (×2) | €3,200 each | 48 | 30 | €4,000 |
| Professional video recording kit | €5,400 | 60 | 30 | €2,700 |
| Accessibility testing software licences | €3,600 | 36 | 30 | €3,000 |
| **Total Equipment** | | | | **€9,700** |

*Depreciation formula: (unit cost / depreciation months) × months used in project*
*Workstation example: (€3,200 / 48) × 30 = €2,000 per unit × 2 = €4,000*

**Total UPM Equipment: €9,700** *(shown as €9,800 with minor rounding)*

---

### Other Direct Costs

| Item | Description | Amount |
|------|-------------|--------|
| External evaluation | Independent quality review at M15 and M28 | €4,500 |
| Translation services | Consortium documentation into ES for national stakeholders | €2,200 |
| Dissemination materials | Project website hosting, printed policy briefs (×500) | €1,800 |
| **Total Other Direct** | | **€8,500** |

---

### Indirect Costs (Overhead)

**Overhead rate:** 25% (UPM flat-rate ceiling per Erasmus+ rules)

```
Overhead = (Personnel + Travel + Equipment + Other) × 25%
         = (€267,750 + €19,600 + €9,800 + €8,500) × 0.25
         = €305,650 × 0.25
         = €76,413
```

---

### UPM Total Budget Summary

| Category | Amount |
|----------|--------|
| Personnel | €267,750 |
| Travel & Accommodation | €19,600 |
| Equipment | €9,800 |
| Other Direct Costs | €8,500 |
| **Total Direct Costs** | **€305,650** |
| Indirect Costs (25%) | €76,413 |
| **UPM TOTAL** | **€382,063** |

---

### Budget Justification Narrative — UPM

**Personnel:** Staff allocations reflect UPM's role as project coordinator across all 6 work
packages. Prof. García provides scientific leadership and external representation (14 PM).
Dr. Fernández leads UPM's substantial contribution to content development (WP2) and pilot
activities (WP4) (18 PM). Ms. Santos provides dedicated project management and financial
oversight throughout the project (11 PM). Mr. Ruiz provides part-time administrative support
for reporting and partner communication (7 PM). Total 50 PM across 30 months represents
approximately 1.67 FTE, appropriate for the coordination workload.

**Travel:** Travel costs cover UPM attendance at all consortium meetings (essential for
coordination decisions), two dissemination events, and three short-term study visits
enabling UPM researchers to observe pilot implementation at partner institutions. All costs
are at or below Erasmus+ standard per diem rates.

**Equipment:** The two workstations replace end-of-life hardware required for content
management and platform testing. The video kit enables UPM to produce training demonstration
materials for WP2. Depreciation calculated on EU standard method.

**Other Direct Costs:** External evaluation is ring-fenced to ensure independent quality
assurance (not conducted by any partner). Translation and dissemination materials are
essential for national-level policy engagement within UPM's Spanish stakeholder network.
