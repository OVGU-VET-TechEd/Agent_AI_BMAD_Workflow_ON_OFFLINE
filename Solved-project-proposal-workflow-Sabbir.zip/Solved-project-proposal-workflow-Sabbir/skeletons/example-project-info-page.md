# Example: Project Info Page
## EcoVET-AI — AI-Powered VET for Green Energy Transitions
### Quality reference for Info Page Agent output

---

**Project Title:** AI-Powered Vocational Training for the Green Energy Workforce
**Acronym:** EcoVET-AI
**Programme:** Erasmus+ KA2 — Cooperation Partnerships in Vocational Education and Training
**Call Reference:** ERASMUS-EDU-2026-PEX-COOP-PART

---

## Short Description (78 words)

EcoVET-AI is a 30-month Erasmus+ partnership designing, developing, and validating an
AI-powered vocational training platform for the green energy sector. The platform delivers
personalised learning pathways for solar, wind, and energy efficiency technician roles,
targeting VET learners, workplace trainers, and career changers across five EU countries.
By combining competency frameworks, real-world simulations, and intelligent tutoring,
EcoVET-AI bridges the widening skills gap between employer demands and available green
energy talent.

## Problem Statement (58 words)

The EU targets 55% emissions reduction by 2030, requiring 1.5 million new green energy
workers (IRENA, 2024). Existing VET curricula are outdated — 72% of surveyed employers
report graduates lack job-ready skills (Cedefop, 2023). No EU-wide, AI-enhanced VET
platform currently addresses this gap across multiple countries and languages simultaneously.

## Objectives

- **O1:** Develop an EU Green Energy VET Competency Framework aligned with EQF Levels 3–5,
  validated with 50+ industry partners by Month 12
- **O2:** Create 120+ hours of AI-personalised VET learning content covering solar, wind,
  and energy efficiency by Month 18
- **O3:** Pilot the EcoVET-AI platform with 300 VET learners and 60 trainers across 5 EU
  countries with ≥75% completion rate by Month 27
- **O4:** Publish an Open Educational Resource (OER) repository of all materials under CC
  BY 4.0 by Month 29
- **O5:** Achieve formal recognition of the EcoVET-AI pathway by at least 3 national VET
  authorities by Month 30

## Outputs

- **Green Energy VET Competency Framework** — EQF-aligned, covering 12 occupational profiles
- **EcoVET-AI Digital Platform** — AI-tutoring, gamified simulations, multilingual (5 languages)
- **120+ Hours of Modular Learning Content** — sector-specific, industry-validated
- **Trainer Upskilling Package** — 40-hour programme for VET educators
- **Quality Assurance Framework** — for ongoing platform governance post-project
- **Open Access Knowledge Repository** — all materials CC BY 4.0, hosted on Zenodo

## Outcomes and Impact (48 words)

VET learners gain industry-recognised green energy credentials. Employers access a skilled
pipeline. Platform operates post-funding through institution licensing. Policy impact through
national VET authority endorsements. Estimated reach: 3,000+ learners by Year 3 through
replication across consortium countries.

## Partnership

5 partners | 5 EU countries | HEI × 2, VET school × 2, SME technology partner × 1

## Budget and Duration

**Total budget:** €1,850,000 | **Duration:** 30 months | **Programme:** Erasmus+ KA2

## Coordinator

Technical University of Madrid (UPM), Spain

---
*Total word count: 387 words — well within 600-word limit*  
*Fits on 1 page A4 at 11pt font with standard margins*
