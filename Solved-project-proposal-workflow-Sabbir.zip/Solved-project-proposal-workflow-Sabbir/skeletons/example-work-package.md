# Example: Work Package Detail
## WP2 — Training Content Development | EcoVET-AI
### Quality reference for Work Package Agent output

---

## WP Overview Table (Full Project)

| WP | Title | Lead | PM | M Start | M End |
|----|-------|------|----|---------|-------|
| WP1 | Project Management & QA | UPM | 24 | 1 | 30 |
| WP2 | Training Content Development | HAN | 68 | 4 | 22 |
| WP3 | Platform Development | TechLearn | 55 | 4 | 24 |
| WP4 | Pilot and Validation | LUT | 48 | 20 | 28 |
| WP5 | Trainer Upskilling | MBO | 32 | 14 | 26 |
| WP6 | Dissemination & Sustainability | UPM | 19 | 1 | 30 |
| **Total** | | | **246** | | |

## PM Allocation by Partner

| WP | UPM (P1) | HAN (P2) | LUT (P3) | MBO (P4) | TechLearn (P5) | Total |
|----|----------|----------|----------|----------|----------------|-------|
| WP1 | 8 | 3 | 3 | 3 | 7 | 24 |
| WP2 | 10 | 22 | 16 | 14 | 6 | 68 |
| WP3 | 8 | 5 | 5 | 4 | 33 | 55 |
| WP4 | 10 | 12 | 14 | 10 | 2 | 48 |
| WP5 | 5 | 7 | 6 | 12 | 2 | 32 |
| WP6 | 9 | 4 | 2 | 2 | 2 | 19 |
| **Total** | **50** | **53** | **46** | **45** | **52** | **246** |

---

## WP2 — Training Content Development

**Lead Partner:** HAN University of Applied Sciences (P2, NL)
**Duration:** Month 4–22
**Total PM:** 68

### Objectives

- Develop a validated EU Green Energy VET Competency Framework covering 12 occupational profiles at EQF Levels 3–5
- Create 120+ hours of modular, AI-ready learning content for solar, wind, and energy efficiency technician roles
- Produce all content in 5 EU languages (EN, DE, FI, NL, ES) with industry validation from 50+ employers
- Establish an open educational resources (OER) repository for all content assets

### Description of Work

WP2 is the core content development work package for EcoVET-AI. Beginning in Month 4 following
the needs analysis in WP1, HAN University leads an iterative content creation cycle across all
five consortium countries.

The first phase (M4–M10) establishes the competency framework through structured employer surveys,
sector expert interviews, and cross-referencing with existing EU skills frameworks (ESCO, Cedefop
sector reports). The framework is iteratively refined with a 50-member industry advisory panel.

The second phase (M10–M18) translates the framework into modular learning units. Each unit is
designed to be deployable as a standalone AI-tutored lesson on the EcoVET-AI platform (WP3),
supporting personalised sequencing based on prior knowledge assessment. Content types include
text-based theory, embedded video demonstrations, interactive simulations, and practical
assessment scenarios reflecting real workplace tasks.

The final phase (M18–M22) covers translation, accessibility review (WCAG 2.1 AA), and industry
validation through structured walkthroughs with 12 employer reviewers per country.

### Tasks

**T2.1: Industry Needs Analysis and Competency Mapping**
- Lead: HAN | Contributors: All partners
- Duration: M4–M8
- Dependencies: None
- Conduct employer surveys (target: 50+ SMEs and large firms), synthesise findings against
  ESCO and Cedefop frameworks. Produce draft competency map for consortium review.

**T2.2: EU Green Energy VET Competency Framework**
- Lead: HAN | Contributors: UPM, LUT, MBO
- Duration: M7–M12
- Dependencies: T2.1
- Finalise 12-occupational-profile competency framework with EQF level mapping. Validate
  through industry advisory panel (M10 workshop). Publish as D2.1.

**T2.3: Learning Content Design and Development**
- Lead: HAN | Contributors: LUT, MBO, UPM
- Duration: M10–M18
- Dependencies: T2.2
- Develop 120 learning units across 4 thematic streams: Solar PV, Wind Energy, Energy Efficiency,
  and Cross-Cutting Skills. Each unit: objectives, theory component, simulation/activity,
  self-assessment. Stored in structured JSON for platform integration (WP3).

**T2.4: Multilingual Translation and Localisation**
- Lead: MBO | Contributors: All partners
- Duration: M16–M20
- Dependencies: T2.3 (80% complete)
- Professional translation of all content into DE, FI, NL, ES. Partner review of localised
  content for cultural and technical accuracy.

**T2.5: Industry Validation and OER Preparation**
- Lead: HAN | Contributors: all
- Duration: M18–M22
- Dependencies: T2.3, T2.4
- Structured validation walkthroughs with 12 employers per country. Incorporate feedback.
  Prepare and upload all assets to Zenodo under CC BY 4.0. Publish D2.3.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D2.1 | EU Green Energy VET Competency Framework | R | HAN | M12 | PU | Full framework with 12 occupational profiles, EQF mapping |
| D2.2 | EcoVET-AI Learning Content Library (120+ hours) | DATA | HAN | M20 | PU | Full structured content in JSON + PDF format |
| D2.3 | Multilingual Content Repository on Zenodo | WEB | MBO | M22 | PU | All assets CC BY 4.0, 5 languages |
| D2.4 | Industry Validation Report | R | HAN | M22 | PU | Validation methodology, findings, changes made |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| M2.1 | Competency Framework v1.0 approved | HAN | M12 | Signed letter from industry advisory panel |
| M2.2 | 60 learning units complete (50%) | HAN | M16 | Content availability in platform staging |
| M2.3 | All 120 units translated and validated | MBO | M22 | Zenodo repository live and confirmed |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Employer survey response rate < 30 | Medium | High | Use professional survey firm; offer incentive; partner networks activate in parallel |
| Translation quality issues in specialised technical terms | Low | Medium | Create glossary in M8; use sector-specialist translators |
| Content development delay due to staff turnover at HAN | Low | High | Shadow roles assigned for all key tasks; M12 review point |
