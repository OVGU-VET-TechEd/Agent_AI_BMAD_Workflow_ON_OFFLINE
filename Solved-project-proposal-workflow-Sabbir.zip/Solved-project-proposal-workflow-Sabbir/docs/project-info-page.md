# TRUSTEDAI — Enhancing Trustworthy Artificial Intelligence for Europe's Digital Infrastructure and Public Services

**Acronym:** TRUSTEDAI
**Programme:** Horizon Europe | **Call Reference:** HORIZON-CL4-2025-DIGITAL-01-03
**Type of Action:** Research and Innovation Action (RIA)

---

## Short Description

TRUSTEDAI is a 36-month Horizon Europe research and innovation project developing trustworthy, explainable, and resilient AI systems for public services and critical digital infrastructure. Five partners from four EU countries combine expertise in explainable AI, privacy-preserving machine learning, and AI-driven cybersecurity to build open-source toolkits validated through real-world pilots in Estonia and Germany. TRUSTEDAI directly addresses Europe's urgent need for AI that citizens and decision-makers can understand, trust, and rely upon.

## Problem Statement

AI systems deployed in European public services lack transparency — 68% of EU citizens distrust AI-driven decisions affecting their lives (Eurobarometer 2024). Cybersecurity monitoring tools cannot keep pace with threats to distributed infrastructure. Existing AI solutions inadequately comply with GDPR and the EU AI Act. Without trustworthy, explainable AI, Europe risks undermining public confidence in digital government and critical services.

## Objectives

1. **O1:** Develop explainable AI (XAI) methods that make high-stakes public-service decisions interpretable by non-technical stakeholders, validated through 2 pilot deployments by Month 30
2. **O2:** Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure by Month 28
3. **O3:** Create privacy-preserving AI techniques (federated learning, differential privacy) that comply with GDPR while maintaining ≥95% of baseline model performance by Month 30
4. **O4:** Build and publish ≥3 open-source AI trustworthiness toolkits under Apache 2.0, registered on the EU AI-on-Demand platform by Month 32
5. **O5:** Demonstrate solutions through 2 real-world pilots (Estonian e-Government, German Healthcare) and produce ≥2 validated policy recommendations by Month 34

## Outputs

- **XAI Framework and Toolkit** — novel explainability methods for public-service decision support, open-source
- **Real-Time Cybersecurity Monitoring Platform** — AI-driven threat detection for distributed infrastructure
- **Privacy-Preserving AI Modules** — federated learning and differential privacy components, GDPR-compliant
- **Trustworthiness Assessment Toolkit** — open-source fairness, robustness, transparency, and accountability tools with benchmarks
- **Policy Briefs and Standards Contribution** — ≥2 policy briefs validated with public authorities; ≥1 standards-track document submitted to CEN/CENELEC or ETSI

## Outcomes and Impact

TRUSTEDAI will increase citizen trust in AI-powered public services, strengthen the cyber-resilience of critical European infrastructure, and provide governance frameworks for responsible AI deployment. Post-project sustainability is ensured through open-source licensing, EU AI-on-Demand platform integration, and institutional adoption by pilot partners.

## Partnership

5 partners | 4 EU countries (DE, BE, IT, EE) | 2 Universities, 1 Research Centre, 1 SME, 1 Technical University

| ID | Institution | Country | Type | Role |
|----|------------|---------|------|------|
| P1 | Technische Universität München (TUM) | Germany | University | Coordinator — XAI research lead |
| P2 | KU Leuven | Belgium | University | Privacy-preserving AI, federated learning |
| P3 | CyberEthics Lab | Italy | SME | AI ethics toolkits, ELSI, dissemination lead |
| P4 | Fraunhofer AISEC | Germany | Research Centre | Cybersecurity frameworks, threat detection |
| P5 | Tallinn University of Technology (TalTech) | Estonia | University | E-government pilots, policy validation |

## Budget and Duration

**Total budget:** €4,000,000 | **Duration:** 36 months | **Programme:** Horizon Europe (HORIZON-CL4-2025-DIGITAL-01-03)

## Coordinator

Technische Universität München (TUM), Germany

---
*Total word count: ~420 words — within 600-word limit*
*Fits on 1 page A4 at 11pt font with standard margins*