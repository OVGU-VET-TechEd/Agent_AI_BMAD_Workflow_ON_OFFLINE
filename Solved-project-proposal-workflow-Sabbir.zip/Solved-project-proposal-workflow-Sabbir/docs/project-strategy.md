# TRUSTEDAI — Project Strategy Framework

> Concise strategic reference for all subsequent agents (Agents 2–6)

---

## Identity

- **Title:** TRUSTEDAI — Enhancing Trustworthy Artificial Intelligence for Europe's Digital Infrastructure and Public Services
- **Acronym:** TRUSTEDAI
- **Programme:** Horizon Europe | **Call:** HORIZON-CL4-2025-DIGITAL-01-03
- **Type of Action:** Research and Innovation Action (RIA) | **Funding rate:** 100%
- **Budget:** EUR 4,000,000 | **Duration:** 36 months

---

## Core Problem

AI systems deployed in public services and critical infrastructure across Europe lack trustworthiness, explainability, and resilience. Citizens and non-technical decision-makers cannot interpret AI-driven recommendations. Cybersecurity monitoring tools are insufficient for distributed infrastructure. Existing AI solutions do not adequately comply with GDPR or the EU AI Act.

## Strategic Response

TRUSTEDAI develops, integrates, and validates three reinforcing technology pillars — explainable AI, privacy-preserving AI, and AI-driven cybersecurity — into open-source toolkits tested through real-world pilots in two EU Member States, supported by policy recommendations and European standardisation contributions.

---

## Consortium (5 Partners, 4 Countries)

| ID | Institution | Country | Type | Primary Role |
|----|------------|---------|------|-------------|
| P1 | Technische Universität München (TUM) | DE | University | Coordinator — XAI research, project lead |
| P2 | KU Leuven | BE | University | Privacy-preserving AI, federated learning |
| P3 | CyberEthics Lab | IT | SME | AI ethics toolkits, ELSI, dissemination lead |
| P4 | Fraunhofer AISEC | DE | Research Centre | Cybersecurity frameworks, threat detection |
| P5 | Tallinn University of Technology (TalTech) | EE | University | E-government pilots, policy validation |

---

## Objectives (SMART)

1. **O1:** Develop XAI methods that make high-stakes public-service decisions interpretable by non-technical stakeholders, validated through 2 pilots by M30
2. **O2:** Design and validate AI-driven cybersecurity monitoring that detects and responds to threats in real time across distributed infrastructure by M28
3. **O3:** Create privacy-preserving AI techniques (federated learning, differential privacy) that comply with GDPR while maintaining ≥95% of baseline model performance by M30
4. **O4:** Build and publish ≥3 open-source AI trustworthiness toolkits under Apache 2.0, registered on EU AI-on-Demand platform by M32
5. **O5:** Demonstrate solutions through 2 real-world pilots (Estonian e-Government, German Healthcare) and produce ≥2 validated policy recommendations by M34

---

## Work Package Structure (7 WPs, 330 PM Total)

| WP | Title | Lead | PM | Months |
|----|-------|------|----|--------|
| WP1 | Project Management, QA & Coordination | TUM (P1) | 30 | M1–M36 |
| WP2 | Explainable AI Methods for Public Services | TUM (P1) | 60 | M1–M30 |
| WP3 | AI-Driven Cybersecurity & Threat Detection | Fraunhofer AISEC (P4) | 55 | M1–M28 |
| WP4 | Privacy-Preserving AI Techniques | KU Leuven (P2) | 50 | M4–M30 |
| WP5 | Open-Source Trustworthiness Toolkits & Benchmarks | CyberEthics Lab (P3) | 45 | M6–M32 |
| WP6 | Real-World Pilot Deployments & Validation | TalTech (P5) | 50 | M18–M34 |
| WP7 | Dissemination, Exploitation, Ethics & Sustainability | CyberEthics Lab (P3) | 40 | M1–M36 |

**Critical path:** WP2/WP3/WP4 (research) → WP5 (toolkits) → WP6 (pilots) → WP7 (policy/standards)

---

## Pilot Deployments

| Pilot | Country | Domain | Technologies Deployed | Lead |
|-------|---------|--------|----------------------|------|
| Pilot 1 | Estonia | e-Government — public service decision support | XAI + Privacy-preserving AI | TalTech (P5) |
| Pilot 2 | Germany | Healthcare — hospital digital infrastructure security | XAI + Cybersecurity monitoring | Fraunhofer AISEC (P4) |

---

## Budget Guidance (EUR 4,000,000 total)

| Category | Approx. % | Approx. EUR |
|----------|-----------|-------------|
| Personnel (330 PM) | ~59% | ~2,370,000 |
| Travel & Subsistence | ~4% | ~152,000 |
| Equipment | ~4% | ~176,000 |
| Other Direct (subcontracting, dissemination, evaluation) | ~13% | ~500,000 |
| Indirect / Overhead (25% flat) | ~20% | ~800,000 |

---

## Key Constraints for All Agents

- All documents must use the same 5 partner names and roles listed above
- All objectives must reference the same 5 SMART objectives (O1–O5)
- All WP references must use the 7-WP structure above (WP1–WP7)
- Budget must not exceed EUR 4,000,000
- Duration is fixed at 36 months
- Deliverable types: R, DATA, DEMO, SW, WEB, G, TOOL, CERT
- Dissemination levels: PU, CO, RE
- 1 PM = 140 productive hours
- Overhead: 25% flat rate on direct costs