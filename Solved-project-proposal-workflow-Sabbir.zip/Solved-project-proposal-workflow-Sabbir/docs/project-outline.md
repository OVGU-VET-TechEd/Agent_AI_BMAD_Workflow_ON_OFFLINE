# TRUSTEDAI — Enhancing Trustworthy Artificial Intelligence for Europe's Digital Infrastructure and Public Services

## 1. Executive Summary
### Overview
TRUSTEDAI is a Horizon Europe Research and Innovation Action (RIA) project that seeks to develop novel explainable, privacy-preserving, and resilient AI systems tailored for critical digital infrastructure and public services. With a budget of EUR 4,000,000 and a duration of 36 months, the consortium consists of five partners from four EU Member States (DE, BE, IT, EE): TUM, KU Leuven, CyberEthics Lab, Fraunhofer AISEC, and TalTech. The project addresses the need for trustworthy AI by focusing on the following specific objectives:

1. **O1:** Develop explainable AI (XAI) methods that make high-stakes public-service decisions interpretable by non-technical stakeholders, validated through 2 pilot deployments by Month 30
2. **O2:** Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure by Month 28
3. **O3:** Create privacy-preserving AI techniques (federated learning, differential privacy) that comply with GDPR while maintaining ≥95% of baseline model performance by Month 30
4. **O4:** Build and publish ≥3 open-source AI trustworthiness toolkits under Apache 2.0, registered on the EU AI-on-Demand platform by Month 32
5. **O5:** Demonstrate solutions through 2 real-world pilots (Estonian e-Government, German Healthcare) and produce ≥2 validated policy recommendations by Month 34

### Impact
TRUSTEDAI will contribute to increased trust in AI-based public services, improved cyber-resilience of critical digital infrastructure, and the development of open-source tools and benchmarks for trustworthiness assessment. This project aims to strengthen Europe's position as a global leader in trustworthy AI while reducing dependency on non-European AI technology. By implementing these solutions, TRUSTEDAI will support the uptake of AI in public administration while safeguarding fundamental rights.

### Partnership
The consortium consists of five partners from four EU Member States:

| Partner | Institution | Country | Type | Role |
|---------|------------|---------|------|------|
| P1 (Coordinator) | Technische Universität München (TUM) | Germany | University | Project coordination, XAI research lead |
| P2 | KU Leuven | Belgium | University | Privacy-preserving AI, federated learning |
| P3 | CyberEthics Lab | Italy | SME (AI/Ethics) | AI ethics toolkits, bias detection, ELSI |
| P4 | Fraunhofer AISEC | Germany | Research Centre | Cybersecurity frameworks, threat detection |
| P5 | Tallinn University of Technology (TalTech) | Estonia | University | E-government AI pilots, policy validation |

### Budget and Duration
- Total budget: EUR 4,000,000
- Maximum EU contribution per project: EUR 4,000,000
- Project duration: 36 months

## 2. Context and Problem Analysis
### Sector Landscape and Documented Problem
AI systems deployed in critical digital infrastructure and public services are increasingly common but face challenges related to trustworthiness, explainability, resilience, and compliance with data protection regulations. These issues have led to a lack of citizen trust in AI-driven decisions affecting their lives. Additionally, cybersecurity monitoring tools struggle to keep pace with the evolving threat landscape, leaving infrastructure vulnerable to attacks.

### Policy Relevance (EU Strategies, National Policies)
TRUSTEDAI aligns with the following EU policies:

- European Commission: Coordinated Plan on AI (2024 update)
- European Commission: Digital Decade Policy Programme 2030
- European Commission: European Data Strategy (COM/2020/66)
- Ethics Guidelines for Trustworthy AI — AI HLEG (2019)
- Regulation (EU) 2016/679 — General Data Protection Regulation (GDPR)
- Regulation (EU) 2024/1689 — Artificial Intelligence Act

### Gap Analysis — Why Existing Solutions are Insufficient
Existing solutions lack several key elements, including:

1. **Lack of Explainability**: AI systems are often difficult for non-technical stakeholders to understand, which hinders trust in the results produced by these systems.
2. **Insufficient Cybersecurity**: Current cybersecurity monitoring tools do not adequately respond to threats in real time across distributed digital infrastructure.
3. **Privacy Violations**: Existing AI solutions frequently fail to comply with GDPR and other data protection regulations, leading to potential privacy breaches.
4. **Bias in AI Systems**: Many AI systems exhibit algorithmic bias that disproportionately affects certain demographic groups.
5. **Lack of Transparency and Accountability**: There is a need for greater transparency and accountability in the development and deployment of AI systems, especially in high-stakes decision support environments.

### Evidence Base (Statistics, Previous Studies)
Several studies highlight the current challenges faced by trustworthy AI:

1. A 2024 survey found that only 32% of EU citizens trust AI-driven decisions affecting their lives (Eurobarometer 2024).
2. A 2024 study revealed that 56% of organizations have experienced data breaches due to insufficient cybersecurity measures (Ponemon Institute 2024).
3. A 2025 report found that AI systems are often biased against certain demographic groups, leading to unfair outcomes (MIT Media Lab 2025).

### Needs Assessment Framing
The development of novel explainable, privacy-preserving, and resilient AI systems is crucial to addressing the needs of the following stakeholders:

1. Citizens: Enhanced trust in AI-driven public services leads to increased confidence in digital government.
2. Decision-makers: Transparent and interpretable AI outputs empower decision-makers to make informed decisions based on AI recommendations.
3. Critical infrastructure operators: Improved cybersecurity monitoring tools reduce the risk of data breaches and improve resilience against threats.
4. Regulators: Compliance with GDPR and the EU AI Act ensures that AI systems are developed ethically and responsibly.
5. European economy: By supporting the uptake of trustworthy AI in public administration, Europe can increase its competitiveness globally.

## 3. Objectives and Methodology
TRUSTEDAI seeks to address the challenges identified in Section 2 through the following specific objectives:

1. **O1:** Develop explainable AI (XAI) methods that make high-stakes public-service decisions interpretable by non-technical stakeholders, validated through 2 pilot deployments by Month 30
2. **O2:** Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure by Month 28
3. **O3:** Create privacy-preserving AI techniques (federated learning, differential privacy) that comply with GDPR while maintaining ≥95% of baseline model performance by Month 30
4. **O4:** Build and publish ≥3 open-source AI trustworthiness toolkits under Apache 2.0, registered on the EU AI-on-Demand platform by Month 32
5. **O5:** Demonstrate solutions through 2 real-world pilots (Estonian e-Government, German Healthcare) and produce ≥2 validated policy recommendations by Month 34

The project's methodology is designed to deliver on these objectives by combining foundational AI advances with practical validation in real-world pilot environments. The consortium will leverage each partner's core competencies to achieve the desired outcomes:

- TUM (Coordinator): Expertise in explainable AI, XAI research, and project management
- KU Leuven: Privacy-preserving AI and federated learning
- CyberEthics Lab: AI ethics toolkits, bias detection, ELSI
- Fraunhofer AISEC: Cybersecurity frameworks, threat detection
- TalTech: E-government AI pilots, policy validation

## 4. Expected Impact
### Direct Beneficiaries (Numbers, Descriptions)
1. Citizens: Increased trust in AI-based public services
2. End-user organisations: Improved cyber-resilience of critical digital infrastructure
3. Regulators: Compliance with the EU AI Act and GDPR
4. European economy: Strengthened Europe's position as a global leader in trustworthy AI, reduced dependency on non-European AI technology, and support for the uptake of AI in public administration while safeguarding fundamental rights

### Indirect Beneficiaries
1. National governments: Enhanced digital public services that lead to improved efficiency and reduced costs
2. SMEs: Opportunities for growth and innovation through the adoption of trustworthy AI
3. Researchers: Advances in explainable, privacy-preserving, and resilient AI techniques contribute to the broader research community
4. Society at large: Improved trust in AI leads to greater acceptance and adoption of AI-driven solutions across various sectors

### Short-Term Outcomes (During Project)
1. Novel XAI methods developed and validated through simulation and pilot deployments
2. Open-source AI toolkits and benchmarks for trustworthiness assessment released under permissive licenses (e.g., Apache 2.0)
3. Policy recommendations for AI governance in public services, validated with at least 2 national or regional public authorities
4. At least 1 standards-track document submitted to CEN/CENELEC or ETSI during the project lifetime
5. Increased awareness and understanding of trustworthy AI among consortium partners, resulting in knowledge transfer and collaboration opportunities beyond the project lifespan

### Medium-Term Outcomes (1–3 Years After)
1. Uptake of developed solutions by public administration bodies across Europe
2. Integration of open-source toolkits into existing AI infrastructure within partner institutions and associated entities
3. Further development and improvement of trustworthy AI techniques based on feedback from pilot deployments and real-world usage
4. Increased awareness of the importance of trustworthy AI among stakeholders, leading to greater demand for such solutions in various sectors

### Long-Term Systemic Change
TRUSTEDAI aims to contribute to a more secure, trustworthy, and transparent digital Europe by fostering innovation in explainable, privacy-preserving, and resilient AI systems. By addressing the identified challenges, the project will help build a foundation for responsible AI adoption in public services, critical infrastructure, and other sectors.

### Sustainability Plan (Financial and Institutional)
The sustainability plan encompasses both financial and institutional aspects:

1. **Financial sustainability**: By adopting open-source licensing for the developed tools and techniques, TRUSTEDAI ensures that its contributions remain accessible to the broader research community beyond the project's lifespan. Additionally, the consortium will seek opportunities for commercialization and further funding to maintain the long-term development of trustworthy AI.
2. **Institutional sustainability**: Each partner institution has committed to integrating the developed solutions into their respective research and innovation strategies. This ensures that the project's outcomes will have a lasting impact on the institutions themselves, as well as their broader networks and collaborations.

## 5. Consortium
TRUSTEDAI consists of five partners from four EU Member States: TUM (Coordinator), KU Leuven, CyberEthics Lab, Fraunhofer AISEC, and TalTech. The consortium's composition provides a diverse skillset essential for the successful completion of the project objectives:

| Partner | Institution | Country | Type | Role |
|---------|------------|---------|------|------|
| P1 (Coordinator) | Technische Universität München (TUM) | Germany | University | Project coordination, XAI research lead |
| P2 | KU Leuven | Belgium | University | Privacy-preserving AI, federated learning |
| P3 | CyberEthics Lab | Italy | SME (AI/Ethics) | AI ethics toolkits, bias detection, ELSI |
| P4 | Fraunhofer AISEC | Germany | Research Centre | Cybersecurity frameworks, threat detection |
| P5 | Tallinn University of Technology (TalTech) | Estonia | University | E-government AI pilots, policy validation |

### Coordinator Justification
TUM is the coordinator due to its strong track record in XAI research and project management, as well as its position as a top-ranked European university in AI and computer science. TUM's dedicated EU project management office ensures effective coordination throughout the duration of the project.

### Collaboration Mechanism (Working Language, Meeting Schedule)
The working language for TRUSTEDAI is English. The consortium will hold regular meetings (at least monthly) via teleconference and face-to-face meetings (minimum 2 per year). The meeting schedule will be established during the project kickoff to ensure effective collaboration among partners.

## 6. Work Plan
The work plan is structured into seven work packages (WPs) that address the specific objectives of TRUSTEDAI:

1. **WP1 — Project Management, Quality Assurance & Coordination** (TUM, P1)
2. **WP2 — Explainable AI Methods for Public Services** (TUM, P1; KU Leuven, P2; CyberEthics Lab, P3)
3. **WP3 — AI-Driven Cybersecurity & Real-Time Threat Detection** (Fraunhofer AISEC, P4)
4. **WP4 — Privacy-Preserving AI Techniques** (KU Leuven, P2; CyberEthics Lab, P3)
5. **WP5 — Open-Source Trustworthiness Toolkits & Benchmarks** (CyberEthics Lab, P3)
6. **WP6 — Real-World Pilot Deployments & Validation** (TalTech, P5)
7. **WP7 — Dissemination, Exploitation, Ethics & Sustainability** (CyberEthics Lab, P3)

### Work Package Overview Table
| WP | Title | Lead | Duration | Est. PM | Key Deliverables |
|---|-------|------|----------|---------|-----------------|
| WP1 | Project Management, Quality Assurance & Coordination | TUM (P1) | M1–M36 | 30 | Management Plan (M2), Progress Reports (M12, M24), Final Report (M35) |
| WP2 | Explainable AI Methods for Public Services | TUM (P1) | M1–M30 | 60 | XAI Framework v1.0 (M12), Interpretability Layer Toolkit (M22), XAI Toolkit v2.0 (M26), Validation Report (M30) |
| WP3 | AI-Driven Cybersecurity & Real-Time Threat Detection | Fraunhofer AISEC (P4) | M1–M28 | 55 | Threat Detection Architecture (M10), Monitoring Platform v1.0 (M20), Validation Report (M28) |
| WP4 | Privacy-Preserving AI Techniques | KU Leuven (P2) | M4–M30 | 50 | Privacy Techniques Survey (M10), Federated Learning Framework (M18), Differential Privacy Module (M22), GDPR Compliance Report (M30) |
| WP5 | Open-Source Trustworthiness Toolkits & Benchmarks | CyberEthics Lab (P3) | M6–M32 | 45 | Fairness Toolkit (M20), Robustness & Transparency Toolkit (M24), Benchmark Suite (M26), Validation Report (M32) |
| WP6 | Real-World Pilot Deployments & Validation | TalTech (P5) | M18–M34 | 50 | Pilot Design Report (M20), Pilot 1 — Estonia e-Gov (M28), Pilot 2 — Germany Healthcare (M32), Evaluation Report (M34) |
| WP7 | Dissemination, Exploitation, Ethics & Sustainability | CyberEthics Lab (P3) | M1–M36 | 40 | Project Website (M2), Exploitation Plan (M6), Ethics Assessment & ELSI Report (M12), Policy Briefs (M30), Standards Submission (M34), Final Conference (M35) |

**Total estimated PM: 330**

### Timeline Narrative
The timeline for TRUSTEDAI is structured as follows:

1. M1–M6: Project kickoff, establishment of the consortium, project planning and management setup, state-of-the-art analysis, and initial design work on XAI methods, privacy-preserving techniques, and cybersecurity frameworks.
2. M7–M18: Development and design of XAI framework, federated learning modules, and threat detection architecture, as well as the establishment of pilot deployment sites (Estonia and Germany).
3. M19–M24: Integration of XAI methods, privacy-preserving techniques, and cybersecurity frameworks into pilot deployments, development of the open-source toolkit, and continued research on trustworthiness assessment.
4. M25–M30: Validation of pilots through real-world testing, refinement based on feedback, and finalization of the open-source toolkits and benchmarks.
5. M31–M36: Finalization of project deliverables (reports, policy recommendations, standards submissions), dissemination activities, exploitation planning, and project closure.

### Critical Path and Dependencies
The critical path for TRUSTEDAI consists of the following dependencies:

- WP2/WP3/WP4: Research (XAI methods, privacy-preserving techniques, cybersecurity frameworks) → WP5 (toolkits) → WP6 (pilots) → WP7 (policy/standards)

## 7. Budget Overview
The budget for TRUSTEDAI is divided into the following categories: personnel costs, travel and subsistence, equipment, other direct costs, and indirect costs (overhead). The total budget is EUR 4,000,000, with the maximum EU contribution per project being EUR 4,000,000.

### Budget Justification Narrative
The budget for TRUSTEDAI is allocated as follows:

1. **Personnel**: Funding for project staff (researchers, administrators, etc.) to ensure the timely completion of the research objectives.
2. **Travel and Subsistence**: Coverage of costs related to project-related travel, including consortium meetings, conferences, and research visits.
3. **Equipment**: Funding for hardware required for the successful execution of the project, such as servers, workstations, or specialized equipment.
4. **Other Direct Costs**: Covers consumables, software licenses, publication charges (Open Access fees), subcontracting costs, and audit costs.
5. **Indirect / Overhead**: A flat rate of 25% applied automatically to all direct costs except for subcontracting and in-kind contributions not used on the premises.

## 8. Risk Management
### Risk Register (At Least 5 Risks)
| # | Risk | Category | Likelihood | Impact | Mitigation |
|---|------|----------|-----------|--------|------------|
| R1 | XAI methods fail to achieve interpretability by non-technical stakeholders | Technical | Medium | High | Iterative co-design with end-users from M6; usability testing at M16 checkpoint |
| R2 | Federated learning performance degradation with heterogeneous partner data | Technical | Medium | Medium | Use state-of-the-art aggregation strategies; fallback to centralised anonymised approach |
| R3 | Pilot site delays due to institutional approvals (ethics boards, data access) | External | High | High | Start ethics/data access applications at M6 (12 months before pilots); identify backup pilot sites |
| R4 | GDPR compliance challenges with cross-border data processing | Legal | Medium | High | KU Leuven GDPR expertise embedded in WP4; Data Protection Impact Assessment at M10 |
| R5 | Partner withdrawal or key staff turnover | Consortium | Low | High | Shadow roles assigned for all WP leads; consortium agreement includes replacement procedure |
| R6 | Model outputs exhibit undetected algorithmic bias in pilot deployments | Ethical | Medium | High | WP5 bias detection toolkit applied to all models before deployment; Ethics Advisory Board oversight |
| R7 | Insufficient engagement from public authorities for policy validation | External | Medium | Medium | TalTech's existing government relationships; early stakeholder mapping at M3; formal MoUs by M12 |

## 9. Ethics, Data Protection, and Sustainability

### Ethical Considerations
TRUSTEDAI embeds ethical oversight throughout the project lifecycle. An external Ethics Advisory Board (established by M3) will provide independent guidance on algorithmic fairness, human oversight mechanisms, and alignment with the EU Ethics Guidelines for Trustworthy AI and the EU AI Act risk categories. All AI systems developed will undergo bias audits using the WP5 trustworthiness toolkit prior to pilot deployment.

### Data Protection and GDPR
All data processing activities comply with Regulation (EU) 2016/679 (GDPR). A Data Protection Impact Assessment (DPIA) will be completed by M10 under KU Leuven's lead (WP4). Privacy-by-design principles are embedded in all technical work packages. Cross-border data processing follows standard contractual clauses. Pilot data will be processed under federated learning architectures to minimise data transfer.

### Open Access and Data Management
All publications will be open access (Gold or Green route). Software outputs will be released under Apache 2.0 licenses and registered on the EU AI-on-Demand platform. A Data Management Plan (DMP) will be produced by M4 and updated at M18, following FAIR principles (Findable, Accessible, Interoperable, Reusable).

### Environmental Sustainability
The project minimises environmental impact through virtual-first collaboration (monthly teleconferences, max 2 in-person meetings per year), cloud-based model training where feasible, and energy-efficient computing practices at partner institutions.

### Post-Project Sustainability
Long-term sustainability is ensured through: (1) open-source licensing enabling community-driven maintenance; (2) institutional adoption by pilot partners (TalTech for e-government, Fraunhofer AISEC for healthcare security); (3) commercial exploitation pathways identified in the WP7 exploitation plan; (4) standards contributions to CEN/CENELEC and ETSI providing lasting normative impact.