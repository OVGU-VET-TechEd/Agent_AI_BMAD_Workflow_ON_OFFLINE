﻿# TRUSTEDAI — Detailed Work Package Plan

> Work Package descriptions for HORIZON-CL4-2025-DIGITAL-01-03
> Total: 7 Work Packages | 330 Person-Months | 36 Months

---

## WP Summary Table

| WP | Title | Lead | Total PM | Start | End |
|----|-------|------|----------|-------|-----|
| WP1 | Project Management, Quality Assurance & Coordination | TUM (P1) | 30 | M1 | M36 |
| WP2 | Explainable AI Methods for Public Services | TUM (P1) | 60 | M1 | M30 |
| WP3 | AI-Driven Cybersecurity & Real-Time Threat Detection | Fraunhofer AISEC (P4) | 55 | M1 | M28 |
| WP4 | Privacy-Preserving AI Techniques | KU Leuven (P2) | 50 | M4 | M30 |
| WP5 | Open-Source Trustworthiness Toolkits & Benchmarks | CyberEthics Lab (P3) | 45 | M6 | M32 |
| WP6 | Real-World Pilot Deployments & Validation | TalTech (P5) | 50 | M18 | M34 |
| WP7 | Dissemination, Exploitation, Ethics & Sustainability | CyberEthics Lab (P3) | 40 | M1 | M36 |
| **Total** | | | **330** | | |

---

## PM Allocation by Partner

| WP | TUM (P1) | KU Leuven (P2) | CyberEthics Lab (P3) | Fraunhofer AISEC (P4) | TalTech (P5) | Total |
|----|----------|----------------|----------------------|-----------------------|--------------|-------|
| WP1 | 12 | 4 | 4 | 4 | 6 | 30 |
| WP2 | 24 | 12 | 8 | 6 | 10 | 60 |
| WP3 | 8 | 4 | 6 | 28 | 9 | 55 |
| WP4 | 8 | 22 | 8 | 6 | 6 | 50 |
| WP5 | 6 | 8 | 18 | 6 | 7 | 45 |
| WP6 | 8 | 6 | 6 | 10 | 20 | 50 |
| WP7 | 6 | 4 | 16 | 4 | 10 | 40 |
| **Total** | **72** | **60** | **66** | **64** | **68** | **330** |

---

## WP1 — Project Management, Quality Assurance & Coordination

**Lead Partner:** Technische Universität München — TUM (P1, DE)
**Duration:** Month 1–36
**Total PM:** 30

### Objectives

- Ensure effective coordination of all project activities across 5 partners and 7 work packages
- Establish and maintain project governance, decision-making, and communication structures
- Implement quality assurance processes including internal peer review of all deliverables
- Manage financial reporting, EU compliance, and contractual obligations
- Monitor and mitigate risks throughout the project lifecycle

### Description of Work

WP1 provides the management backbone for TRUSTEDAI. TUM, as coordinator, establishes the Project Management Board (PMB) comprising one representative from each partner, meeting monthly via teleconference and bi-annually in person. The PMB oversees work plan execution, resource allocation, and conflict resolution. A dedicated Project Manager at TUM handles day-to-day coordination, financial tracking, and EU reporting obligations.

Quality assurance follows a structured peer review process: each deliverable is reviewed by at least one partner not involved in its production before submission. A risk register is maintained and reviewed quarterly, with escalation procedures for critical risks. The project uses shared digital tools (document repository, task tracker, shared calendar) to ensure transparent communication across the consortium.

### Tasks

**T1.1: Project Coordination and Governance**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M1–M36
- Dependencies: None
- Establish the Project Management Board, define roles and decision-making procedures. Organise kickoff meeting (M1). Maintain project work plan and monitor progress against milestones. Prepare and submit periodic reports to the European Commission.

**T1.2: Financial Management and Reporting**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M1–M36
- Dependencies: None
- Manage consortium budget, process cost claims, and prepare financial statements. Coordinate pre-financing distribution and interim payments. Ensure compliance with Horizon Europe financial regulations. Conduct internal financial audits at M12 and M24.

**T1.3: Quality Assurance and Internal Peer Review**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M3–M36
- Dependencies: None
- Develop and implement the Quality Assurance Plan (QAP) by M3. Define quality criteria for all deliverables. Assign peer reviewers for each deliverable. Conduct quality reviews at M12, M24, and M34.

**T1.4: Risk Monitoring and Mitigation**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M1–M36
- Dependencies: None
- Maintain and update the risk register quarterly. Implement mitigation actions for identified risks. Report risk status at each PMB meeting. Escalate critical risks to the European Commission when necessary.

**T1.5: Consortium Meetings and Communication**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M1–M36
- Dependencies: None
- Organise bi-annual consortium meetings (M1, M6, M12, M18, M24, M30, M35). Maintain internal communication platform. Coordinate with the EC Project Officer. Organise the final project review meeting (M36).

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D1.1 | Project Management Plan | R | TUM | M2 | CO | Governance structure, communication plan, QAP, risk register, meeting schedule |
| D1.2 | Progress Report — Year 1 | R | TUM | M12 | RE | Technical and financial progress, risk update, plan for Year 2 |
| D1.3 | Progress Report — Year 2 | R | TUM | M24 | RE | Technical and financial progress, risk update, plan for Year 3 |
| D1.4 | Final Technical Report | R | TUM | M35 | PU | Comprehensive summary of all results, impact, and sustainability plan |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS1.1 | Consortium kickoff completed | TUM | M1 | Signed meeting minutes, PMB established |
| MS1.2 | Mid-term review passed | TUM | M18 | EC review report, no critical issues |
| MS1.3 | Final review completed | TUM | M36 | EC acceptance of final report |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Partner withdrawal or key staff turnover | Low | High | Shadow roles assigned for all WP leads; consortium agreement includes replacement procedure |
| Delays in deliverable submission | Medium | Medium | QAP includes 4-week buffer before deadlines; peer review tracked in shared system |
| Communication breakdown between partners | Low | Medium | Monthly teleconferences, shared digital workspace, bi-annual face-to-face meetings |

---

## WP2 — Explainable AI Methods for Public Services

**Lead Partner:** Technische Universität München — TUM (P1, DE)
**Duration:** Month 1–30
**Total PM:** 60

### Objectives

- Conduct a comprehensive state-of-the-art analysis of XAI methods applicable to high-stakes decision support
- Design novel XAI architectures that produce explanations understandable by non-technical public-service stakeholders
- Develop interpretability layers for AI models used in healthcare and e-government domains
- Integrate XAI methods with privacy-preserving techniques from WP4
- Validate XAI methods through pilot deployments in WP6

### Description of Work

WP2 is the core research work package for explainable AI. TUM leads an iterative research-develop-validate cycle, starting with a systematic literature review and gap analysis (M1–M6), followed by novel XAI architecture design targeting healthcare decision support and e-government applications (M4–M16). The focus is on post-hoc explanation methods (SHAP, LIME extensions) and inherently interpretable model architectures (attention-based, rule-extraction) that produce natural-language explanations accessible to non-technical stakeholders.

In the second phase (M10–M22), TUM and KU Leuven develop interpretability layers that can be appended to existing AI models, converting complex model outputs into structured explanations with confidence indicators, feature importance rankings, and counterfactual scenarios ("what would need to change for a different outcome"). CyberEthics Lab contributes ethical assessment of explanation quality, ensuring explanations do not perpetuate bias or create false confidence.

The final phase (M18–M30) integrates XAI methods with WP4 privacy-preserving techniques and validates them through WP6 pilot deployments, collecting end-user feedback from public-service decision-makers.

### Tasks

**T2.1: State-of-the-Art Analysis and Gap Identification**
- Lead: TUM (P1) | Contributors: KU Leuven (P2), CyberEthics Lab (P3)
- Duration: M1–M6
- Dependencies: None
- Systematic review of XAI methods (SHAP, LIME, attention mechanisms, concept-based explanations). Map methods to public-service use cases. Identify gaps in interpretability for non-technical stakeholders. Publish D2.1 survey report.

**T2.2: Novel XAI Architecture Design**
- Lead: TUM (P1) | Contributors: KU Leuven (P2)
- Duration: M4–M16
- Dependencies: T2.1
- Design XAI architectures for two domains: (a) healthcare decision support (diagnostic recommendations), (b) e-government eligibility decisions. Focus on inherently interpretable models and post-hoc explanation enhancement. Develop prototype implementations.

**T2.3: Interpretability Layer Development**
- Lead: TUM (P1) | Contributors: KU Leuven (P2), CyberEthics Lab (P3)
- Duration: M10–M22
- Dependencies: T2.2
- Build modular interpretability layers that convert model outputs into natural-language explanations, feature importance rankings, and counterfactual scenarios. Ensure explanations are calibrated — confidence indicators reflect actual model uncertainty. Conduct initial usability testing with 20 non-technical users.

**T2.4: Integration with Privacy-Preserving Techniques**
- Lead: KU Leuven (P2) | Contributors: TUM (P1)
- Duration: M18–M26
- Dependencies: T2.3, WP4 (T4.2, T4.3)
- Integrate XAI methods with federated learning and differential privacy modules from WP4. Ensure explanations remain accurate and informative when operating on privacy-protected data. Measure explanation quality degradation and optimise.

**T2.5: Validation through Pilot Deployments**
- Lead: TUM (P1) | Contributors: TalTech (P5), Fraunhofer AISEC (P4)
- Duration: M24–M30
- Dependencies: T2.3, T2.4, WP6 (T6.2, T6.3)
- Deploy XAI methods in Estonian e-government (Pilot 1) and German healthcare (Pilot 2) environments. Collect structured feedback from 50+ non-technical decision-makers. Measure interpretability using standardised metrics (explanation satisfaction, decision confidence, task accuracy). Refine methods based on feedback.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D2.1 | XAI State-of-the-Art Survey and Gap Analysis | R | TUM | M6 | PU | Comprehensive review of XAI methods, gap identification, research roadmap |
| D2.2 | XAI Framework v1.0 | SW | TUM | M12 | PU | Prototype XAI architectures for healthcare and e-government domains |
| D2.3 | Interpretability Layer Toolkit | SW | TUM | M22 | PU | Modular toolkit for natural-language explanations, feature importance, counterfactuals |
| D2.4 | XAI Toolkit v2.0 (integrated with privacy) | SW | TUM | M26 | PU | XAI toolkit integrated with WP4 privacy-preserving modules |
| D2.5 | XAI Validation Report | R | TUM | M30 | PU | Pilot deployment results, user feedback analysis, final recommendations |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS2.1 | XAI survey completed, research roadmap approved | TUM | M6 | PMB approval of D2.1 |
| MS2.2 | XAI Framework v1.0 demonstrated | TUM | M12 | Live demonstration at consortium meeting |
| MS2.3 | XAI methods validated in both pilots | TUM | M30 | D2.5 accepted, ≥75% user satisfaction |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| XAI methods fail to achieve interpretability for non-technical stakeholders | Medium | High | Iterative co-design with end-users from M6; usability testing at M16 checkpoint |
| Explanation quality degrades when combined with privacy-preserving techniques | Medium | Medium | Dedicated T2.4 integration task; accept marginal quality loss if privacy compliance requires it |
| Insufficient pilot participants for validation | Low | Medium | TalTech and Fraunhofer leverage institutional networks; target 50 users with 30 minimum |

---

## WP3 — AI-Driven Cybersecurity & Real-Time Threat Detection

**Lead Partner:** Fraunhofer AISEC (P4, DE)
**Duration:** Month 1–28
**Total PM:** 55

### Objectives

- Analyse existing AI-driven cybersecurity monitoring frameworks and identify capability gaps
- Design a modular architecture for real-time threat detection across distributed digital infrastructure
- Develop and train anomaly detection models for network and system monitoring
- Build an automated response and alerting subsystem with human-in-the-loop oversight
- Validate the framework through simulation and real-world pilot deployment in WP6

### Description of Work

WP3 develops an AI-driven cybersecurity monitoring platform designed for distributed public-sector digital infrastructure. Fraunhofer AISEC leads the technical development, leveraging its established expertise in applied security research. The work begins with a comprehensive review of existing monitoring frameworks (M1–M6), identifying gaps in real-time detection capabilities, explainability of threat alerts, and scalability for distributed systems.

The architecture design phase (M4–M10) produces a modular, containerised platform architecture that can be deployed across heterogeneous infrastructure. The core innovation is AI-powered anomaly detection that combines supervised classifiers (trained on known attack patterns) with unsupervised models (for zero-day detection), integrated with WP2 XAI methods to produce human-interpretable threat alerts.

The development phase (M8–M22) builds the detection engine, automated response subsystem, and dashboard. Human-in-the-loop mechanisms ensure that automated responses (network isolation, service throttling) require human confirmation for high-impact actions. The final phase (M20–M28) validates the platform through simulated attack scenarios and real-world deployment in the German healthcare pilot (WP6, Pilot 2).

### Tasks

**T3.1: Cybersecurity Framework Review and Gap Analysis**
- Lead: Fraunhofer AISEC (P4) | Contributors: TUM (P1), TalTech (P5)
- Duration: M1–M6
- Dependencies: None
- Review existing AI-driven monitoring frameworks (MITRE ATT&CK, NIST CSF, ENISA guidelines). Identify gaps in real-time detection for distributed public-sector infrastructure. Define requirements specification for the TRUSTEDAI monitoring platform.

**T3.2: Threat Detection Architecture Design**
- Lead: Fraunhofer AISEC (P4) | Contributors: TUM (P1)
- Duration: M4–M10
- Dependencies: T3.1
- Design modular, containerised platform architecture. Define data ingestion pipelines (network flow, system logs, application events). Specify anomaly detection model architecture (supervised + unsupervised ensemble). Publish D3.1 architecture document.

**T3.3: Anomaly Detection Model Development**
- Lead: Fraunhofer AISEC (P4) | Contributors: TUM (P1), KU Leuven (P2)
- Duration: M8–M18
- Dependencies: T3.2
- Develop and train anomaly detection models using public threat datasets (CICIDS, NSL-KDD) and partner-provided data. Implement supervised classifiers for known attack patterns and unsupervised models for zero-day detection. Integrate WP2 XAI methods for interpretable threat alerts. Achieve ≥95% detection rate with ≤5% false positive rate.

**T3.4: Automated Response and Alerting Subsystem**
- Lead: Fraunhofer AISEC (P4) | Contributors: TalTech (P5)
- Duration: M14–M22
- Dependencies: T3.3
- Build automated response engine with graduated actions (alert, throttle, isolate). Implement human-in-the-loop confirmation for high-impact responses. Develop security operations dashboard with real-time visualisation. Integrate with standard SIEM platforms.

**T3.5: Validation through Simulation and Pilot Deployment**
- Lead: Fraunhofer AISEC (P4) | Contributors: TalTech (P5), TUM (P1)
- Duration: M20–M28
- Dependencies: T3.3, T3.4, WP6 (T6.3)
- Conduct simulated attack scenarios (DDoS, lateral movement, data exfiltration) against test infrastructure. Deploy platform in German healthcare pilot (Pilot 2). Evaluate detection rate, response time, and false positive rate. Collect operator feedback on alert interpretability.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D3.1 | Threat Detection Architecture Specification | R | Fraunhofer AISEC | M10 | PU | Modular architecture, data pipelines, model specifications |
| D3.2 | Cybersecurity Monitoring Platform v1.0 | SW | Fraunhofer AISEC | M20 | PU | Core platform with anomaly detection and dashboard |
| D3.3 | Automated Response Subsystem | SW | Fraunhofer AISEC | M22 | CO | Response engine with human-in-the-loop mechanisms |
| D3.4 | Cybersecurity Validation Report | R | Fraunhofer AISEC | M28 | PU | Simulation results, pilot deployment evaluation, performance metrics |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS3.1 | Architecture specification approved | Fraunhofer AISEC | M10 | PMB approval of D3.1 |
| MS3.2 | Platform v1.0 demonstrated with simulated attacks | Fraunhofer AISEC | M20 | Live demonstration, ≥95% detection rate |
| MS3.3 | Platform validated in healthcare pilot | Fraunhofer AISEC | M28 | D3.4 accepted, operator feedback positive |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Insufficient labelled threat data for model training | Medium | High | Use public datasets (CICIDS, NSL-KDD); generate synthetic attack data; federated approach with hospital partner |
| False positive rate too high for operational use | Medium | Medium | Ensemble approach combining supervised + unsupervised; iterative threshold tuning with pilot operators |
| Hospital pilot site delays due to security approvals | High | High | Start approval process at M6; identify backup pilot with TalTech e-gov infrastructure |

---

## WP4 — Privacy-Preserving AI Techniques

**Lead Partner:** KU Leuven (P2, BE)
**Duration:** Month 4–30
**Total PM:** 50

### Objectives

- Survey and evaluate privacy-preserving AI techniques with respect to GDPR compliance and model performance
- Develop novel federated learning methods that maintain model performance while ensuring data locality
- Create differential privacy mechanisms calibrated for public-service AI applications
- Integrate privacy-preserving modules into WP2 (XAI) and WP3 (cybersecurity) frameworks
- Conduct GDPR compliance audit and Data Protection Impact Assessment for all project outputs

### Description of Work

WP4 addresses the critical challenge of building AI systems that comply with European data protection regulations while maintaining performance. KU Leuven, with its internationally recognised expertise in privacy engineering, leads the development of privacy-preserving AI techniques that can be integrated with the XAI and cybersecurity frameworks developed in WP2 and WP3.

The work starts with a comprehensive survey of federated learning, differential privacy, and secure multi-party computation techniques (M4–M10), assessing each against GDPR requirements (data minimisation, purpose limitation, right to erasure). The development phase (M8–M22) produces two core modules: (1) a federated learning framework that enables model training across partner institutions without centralising sensitive data, and (2) differential privacy mechanisms that add calibrated noise to model outputs while maintaining ≥95% of baseline performance.

The integration phase (M18–M28) connects these modules with WP2 XAI methods and WP3 cybersecurity frameworks, ensuring that privacy protections do not degrade explainability or threat detection capabilities. A formal GDPR compliance audit (M24–M30) verifies all project outputs against data protection requirements.

### Tasks

**T4.1: Privacy Techniques Survey and GDPR Assessment**
- Lead: KU Leuven (P2) | Contributors: CyberEthics Lab (P3)
- Duration: M4–M10
- Dependencies: None
- Survey federated learning variants (FedAvg, FedProx, personalised FL), differential privacy mechanisms (ε-DP, local DP, Rényi DP), and secure multi-party computation. Assess each against GDPR articles (Art. 5 data minimisation, Art. 17 right to erasure, Art. 25 data protection by design). Publish D4.1 survey and recommendations.

**T4.2: Federated Learning Framework Development**
- Lead: KU Leuven (P2) | Contributors: TUM (P1), Fraunhofer AISEC (P4)
- Duration: M8–M18
- Dependencies: T4.1
- Develop a federated learning framework supporting heterogeneous data distributions across partner institutions. Implement privacy-preserving aggregation strategies (secure aggregation, gradient masking). Benchmark against centralised training baseline — target ≥95% performance retention. Handle non-IID data distributions common in multi-institution settings.

**T4.3: Differential Privacy Mechanisms**
- Lead: KU Leuven (P2) | Contributors: TUM (P1)
- Duration: M12–M22
- Dependencies: T4.1
- Design differential privacy mechanisms calibrated for public-service applications (where over-noising can lead to harmful decisions). Implement adaptive privacy budgets that balance privacy guarantee strength with output utility. Create tools for privacy budget accounting across model lifecycle.

**T4.4: Integration with WP2 and WP3 Frameworks**
- Lead: KU Leuven (P2) | Contributors: TUM (P1), Fraunhofer AISEC (P4)
- Duration: M18–M28
- Dependencies: T4.2, T4.3, WP2 (T2.3), WP3 (T3.3)
- Integrate federated learning module into WP2 XAI pipeline — enable federated XAI model training. Integrate differential privacy into WP3 cybersecurity monitoring — protect sensitive network metadata. Measure and document performance-privacy trade-offs for each integration.

**T4.5: GDPR Compliance Audit and DPIA**
- Lead: KU Leuven (P2) | Contributors: CyberEthics Lab (P3)
- Duration: M24–M30
- Dependencies: T4.4
- Conduct formal Data Protection Impact Assessment (DPIA) for all AI systems developed in WP2, WP3, and WP5. Verify compliance with GDPR Art. 35. Review data flows across all pilot deployments (WP6). Produce compliance certification documentation.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D4.1 | Privacy Techniques Survey and GDPR Assessment | R | KU Leuven | M10 | PU | Comprehensive survey, GDPR mapping, technique recommendations |
| D4.2 | Federated Learning Framework v1.0 | SW | KU Leuven | M18 | PU | FL framework with secure aggregation, heterogeneous data support |
| D4.3 | Differential Privacy Module | SW | KU Leuven | M22 | PU | Adaptive privacy mechanisms with budget accounting tools |
| D4.4 | Privacy-Performance Integration Report | R | KU Leuven | M28 | PU | Trade-off analysis for WP2/WP3 integration, optimisation results |
| D4.5 | GDPR Compliance Report and DPIA | R | KU Leuven | M30 | CO | Formal DPIA, compliance certification, data flow documentation |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS4.1 | Privacy techniques survey completed | KU Leuven | M10 | D4.1 published |
| MS4.2 | Federated learning achieves ≥95% of baseline performance | KU Leuven | M18 | Benchmark report appended to D4.2 |
| MS4.3 | GDPR compliance confirmed for all AI outputs | KU Leuven | M30 | D4.5 accepted, no critical findings |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Federated learning performance degradation with heterogeneous partner data | Medium | Medium | State-of-the-art aggregation strategies; fallback to centralised anonymised approach |
| Differential privacy noise too aggressive for safety-critical applications | Medium | High | Adaptive privacy budgets; domain expert calibration for healthcare/e-gov use cases |
| GDPR compliance challenges with cross-border data processing in pilots | Medium | High | KU Leuven GDPR expertise; DPIAs completed before pilot deployment; standard contractual clauses |

---

## WP5 — Open-Source Trustworthiness Toolkits & Benchmarks

**Lead Partner:** CyberEthics Lab (P3, IT)
**Duration:** Month 6–32
**Total PM:** 45

### Objectives

- Define trustworthiness dimensions (fairness, robustness, transparency, accountability) and operationalise them into measurable metrics
- Develop open-source assessment toolkits with standardised APIs for evaluating AI system trustworthiness
- Create benchmark datasets and evaluation protocols for trustworthiness testing
- Validate toolkits against WP2, WP3, and WP4 outputs and external AI systems
- Publish all tools under Apache 2.0 and register on the EU AI-on-Demand platform

### Description of Work

WP5 translates the research advances from WP2–WP4 into reusable, open-source tools that the broader European AI community can use to assess and improve AI trustworthiness. CyberEthics Lab leads this work package, drawing on its expertise in AI ethics, fairness assessment, and responsible AI governance.

The work begins with a definition phase (M6–M12) establishing the trustworthiness framework — mapping dimensions (fairness, robustness, transparency, accountability) to concrete metrics aligned with the EU AI Act risk categories and the AI HLEG Ethics Guidelines. The development phase (M10–M24) produces three toolkit components: (1) a fairness assessment tool (bias detection, demographic parity, equalised odds), (2) a robustness testing tool (adversarial perturbation, distribution shift, edge-case generation), and (3) a transparency assessment tool (explanation quality metrics, model documentation scoring).

Alongside the toolkit, the team creates benchmark datasets and standardised evaluation protocols that enable reproducible trustworthiness testing. The validation phase (M22–M30) applies the toolkit to all TRUSTEDAI AI outputs and to 5 external AI systems for comparison. Final publication (M28–M32) includes Apache 2.0 licensing, comprehensive documentation, PyPI packaging, and registration on the EU AI-on-Demand platform.

### Tasks

**T5.1: Trustworthiness Framework and Metrics Definition**
- Lead: CyberEthics Lab (P3) | Contributors: All partners
- Duration: M6–M12
- Dependencies: None
- Define trustworthiness dimensions aligned with EU AI Act and AI HLEG guidelines. Operationalise each dimension into quantitative metrics. Create a trustworthiness assessment methodology. Produce D5.1 framework document.

**T5.2: Fairness and Bias Assessment Toolkit**
- Lead: CyberEthics Lab (P3) | Contributors: KU Leuven (P2), TUM (P1)
- Duration: M10–M20
- Dependencies: T5.1
- Develop bias detection algorithms (demographic parity, equalised odds, calibration). Build fairness dashboard with visualisation. Support tabular, text, and image data modalities. Package as Python library with standardised API.

**T5.3: Robustness and Transparency Testing Toolkit**
- Lead: CyberEthics Lab (P3) | Contributors: Fraunhofer AISEC (P4), TUM (P1)
- Duration: M12–M24
- Dependencies: T5.1
- Build robustness testing module (adversarial perturbations, distribution shift simulation, edge-case generation). Build transparency assessment module (explanation quality scoring, model card generation, documentation completeness checking). Integrate with T5.2 into unified toolkit.

**T5.4: Benchmark Datasets and Evaluation Protocols**
- Lead: CyberEthics Lab (P3) | Contributors: TalTech (P5), KU Leuven (P2)
- Duration: M14–M24
- Dependencies: T5.1
- Curate benchmark datasets for healthcare and e-government domains (synthetic + anonymised real data from pilot partners). Define standardised evaluation protocols enabling reproducible trustworthiness testing. Publish datasets on Zenodo under open licence.

**T5.5: Validation, Publication, and Platform Registration**
- Lead: CyberEthics Lab (P3) | Contributors: All partners
- Duration: M22–M32
- Dependencies: T5.2, T5.3, T5.4, WP2 (D2.3), WP3 (D3.2), WP4 (D4.2)
- Apply toolkit to all TRUSTEDAI AI outputs (WP2, WP3, WP4) and 5 external AI systems. Compare results, identify improvement areas. Publish toolkit on PyPI under Apache 2.0. Create comprehensive documentation and tutorials. Register on EU AI-on-Demand platform.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D5.1 | Trustworthiness Assessment Framework | R | CyberEthics Lab | M12 | PU | Dimensions, metrics, methodology aligned with EU AI Act |
| D5.2 | Fairness and Bias Assessment Toolkit | TOOL | CyberEthics Lab | M20 | PU | Python library for bias detection, fairness dashboard, Apache 2.0 |
| D5.3 | Robustness and Transparency Toolkit | TOOL | CyberEthics Lab | M24 | PU | Adversarial testing, transparency assessment, model card generation |
| D5.4 | Trustworthiness Benchmark Suite | DATA | CyberEthics Lab | M26 | PU | Benchmark datasets and evaluation protocols on Zenodo |
| D5.5 | Toolkit Validation Report and AI-on-Demand Registration | R | CyberEthics Lab | M32 | PU | Validation results, comparison with external systems, platform registration confirmation |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS5.1 | Trustworthiness framework approved | CyberEthics Lab | M12 | PMB approval of D5.1 |
| MS5.2 | Fairness toolkit released on PyPI | CyberEthics Lab | M20 | Package available on PyPI, ≥3 test runs completed |
| MS5.3 | ≥3 tools registered on EU AI-on-Demand platform | CyberEthics Lab | M32 | Registration confirmation from platform |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Insufficient diversity in benchmark datasets leading to biased evaluation | Medium | Medium | Curate data from multiple pilot domains; include synthetic augmentation; external review |
| Low adoption of open-source tools by external users | Low | Medium | Strong documentation, tutorials, conference workshops; AI-on-Demand platform visibility |
| Integration issues between fairness/robustness/transparency modules | Low | Medium | Unified API design from M10; continuous integration testing; modular architecture |

---

## WP6 — Real-World Pilot Deployments & Validation

**Lead Partner:** Tallinn University of Technology — TalTech (P5, EE)
**Duration:** Month 18–34
**Total PM:** 50

### Objectives

- Design pilot deployment scenarios with clear KPIs and evaluation methodology for two EU Member States
- Deploy XAI and privacy-preserving AI in Estonian e-government public service decision support (Pilot 1)
- Deploy cybersecurity monitoring and XAI in German hospital digital infrastructure (Pilot 2)
- Collect end-user feedback, conduct usability assessment, and iteratively refine deployed solutions
- Produce a cross-pilot comparative evaluation and lessons learned report

### Description of Work

WP6 validates all TRUSTEDAI research outputs through real-world deployment in two complementary pilot environments. TalTech leads overall pilot coordination, leveraging Estonia's advanced digital government infrastructure for Pilot 1, while Fraunhofer AISEC coordinates the German healthcare deployment for Pilot 2.

Pilot 1 (Estonia — e-Government) deploys XAI methods (WP2) and privacy-preserving AI (WP4) in a public-service decision support context — specifically, automated eligibility assessment for social services, where citizens receive AI-explained decisions about benefit applications. The pilot involves 3 government agencies and targets 100+ citizen interactions.

Pilot 2 (Germany — Healthcare) deploys the cybersecurity monitoring platform (WP3) and XAI methods (WP2) in a hospital digital infrastructure environment. The platform monitors network traffic, medical device communications, and access patterns for threats, with XAI-powered alert explanations for security operators. The pilot targets 1 regional hospital with ≥6 months of continuous monitoring.

Both pilots follow a plan-deploy-evaluate-refine cycle, with structured feedback from end-users feeding back into WP2, WP3, and WP4 for final improvements.

### Tasks

**T6.1: Pilot Design — Scenarios, KPIs, and Evaluation Methodology**
- Lead: TalTech (P5) | Contributors: All partners
- Duration: M18–M20
- Dependencies: WP2 (D2.2), WP3 (D3.2), WP4 (D4.2)
- Define pilot deployment scenarios for both sites. Establish KPIs: explanation satisfaction (≥75%), detection rate (≥95%), false positive rate (≤5%), GDPR compliance (pass/fail). Design mixed-methods evaluation framework (quantitative metrics + qualitative user interviews). Produce D6.1.

**T6.2: Pilot 1 — Estonian e-Government Deployment**
- Lead: TalTech (P5) | Contributors: TUM (P1), KU Leuven (P2)
- Duration: M20–M28
- Dependencies: T6.1, WP2 (D2.3), WP4 (D4.2)
- Partner with 3 Estonian government agencies for social service eligibility assessment. Deploy XAI-powered decision support system with privacy-preserving data processing. Process ≥100 citizen cases with XAI explanations. Collect citizen and caseworker feedback through structured surveys and interviews.

**T6.3: Pilot 2 — German Healthcare Deployment**
- Lead: Fraunhofer AISEC (P4) | Contributors: TUM (P1), CyberEthics Lab (P3)
- Duration: M22–M32
- Dependencies: T6.1, WP2 (D2.3), WP3 (D3.2)
- Deploy cybersecurity monitoring platform in 1 regional hospital. Monitor network traffic, medical devices, and access patterns for ≥6 months. Integrate XAI explanations into threat alerts for security operators. Conduct simulated attack exercises alongside real-world monitoring.

**T6.4: End-User Feedback and Iterative Refinement**
- Lead: TalTech (P5) | Contributors: TUM (P1), Fraunhofer AISEC (P4)
- Duration: M24–M32
- Dependencies: T6.2, T6.3
- Aggregate feedback from both pilots. Identify usability issues, explanation gaps, and performance bottlenecks. Feed improvements back to WP2, WP3, and WP4. Conduct second-round evaluation after refinements to measure improvement.

**T6.5: Cross-Pilot Comparative Evaluation**
- Lead: TalTech (P5) | Contributors: All partners
- Duration: M30–M34
- Dependencies: T6.4
- Compare pilot results across domains (e-government vs healthcare), geographies (Estonia vs Germany), and technology stacks (XAI+privacy vs XAI+cybersecurity). Extract generalisable lessons for trustworthy AI deployment in public services. Produce D6.4 final evaluation report with recommendations for scaling.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D6.1 | Pilot Design and Evaluation Framework | R | TalTech | M20 | PU | Scenarios, KPIs, evaluation methodology for both pilots |
| D6.2 | Pilot 1 Report — Estonian e-Government | R | TalTech | M28 | PU | Deployment description, results, citizen/caseworker feedback |
| D6.3 | Pilot 2 Report — German Healthcare | R | Fraunhofer AISEC | M32 | PU | Deployment description, monitoring results, operator feedback |
| D6.4 | Cross-Pilot Evaluation and Lessons Learned | R | TalTech | M34 | PU | Comparative analysis, generalisable recommendations, scaling roadmap |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS6.1 | Pilot 1 operational in Estonia | TalTech | M22 | System live, first citizen cases processed |
| MS6.2 | Pilot 2 operational in Germany | Fraunhofer AISEC | M24 | Monitoring platform live in hospital |
| MS6.3 | Both pilots completed, evaluation report accepted | TalTech | M34 | D6.4 accepted by PMB |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Pilot site delays due to institutional ethics/data access approvals | High | High | Start approval process at M6 (12 months before pilots); identify backup sites |
| Low citizen participation in Estonian pilot | Medium | Medium | TalTech government partnerships; incentivise participation; target agencies with high case volume |
| Hospital security policies prevent full platform deployment | Medium | High | Pre-deployment security assessment at M18; modular architecture allows partial deployment |
| Insufficient feedback quality from non-technical end-users | Low | Medium | Structured survey instruments; trained interviewers; pre-testing of feedback tools |

---

## WP7 — Dissemination, Exploitation, Ethics & Sustainability

**Lead Partner:** CyberEthics Lab (P3, IT)
**Duration:** Month 1–36
**Total PM:** 40

### Objectives

- Maximise visibility and impact of project results through targeted dissemination activities
- Develop and maintain exploitation and IPR management plans for commercialisation pathways
- Ensure comprehensive ethical governance including Ethics Advisory Board and ELSI monitoring
- Produce policy recommendations validated with public authorities and contribute to European standards
- Establish post-project sustainability through open-source licensing and institutional adoption

### Description of Work

WP7 runs throughout the entire project, ensuring that TRUSTEDAI's innovations reach the widest possible audience and have lasting impact. CyberEthics Lab leads this cross-cutting work package, coordinating dissemination, exploitation, ethics, and sustainability activities across all partners.

Dissemination activities begin at project start with the project website (M2) and social media presence, building to targeted publications (≥6 peer-reviewed papers), conference presentations, and community workshops on the AI-on-Demand platform. The exploitation plan (M6, updated M24) identifies commercial opportunities for the open-source toolkits, training services, and consultancy based on TRUSTEDAI expertise.

Ethical governance is embedded throughout, with an external Ethics Advisory Board providing independent oversight and regular ELSI assessments ensuring alignment with the EU AI Act and Ethics Guidelines for Trustworthy AI. Policy impact is achieved through policy briefs co-developed with public authorities and at least one standards-track submission to CEN/CENELEC or ETSI.

### Tasks

**T7.1: Project Communication and Online Presence**
- Lead: CyberEthics Lab (P3) | Contributors: TalTech (P5)
- Duration: M1–M36
- Dependencies: None
- Create and maintain project website (live by M2). Establish social media channels (Twitter/X, LinkedIn). Produce quarterly newsletters. Develop visual identity and project branding. Target: 5,000+ unique website visitors, 1,000+ social media followers by M36.

**T7.2: Exploitation and IPR Management**
- Lead: CyberEthics Lab (P3) | Contributors: All partners
- Duration: M3–M36
- Dependencies: None
- Develop exploitation plan identifying commercialisation pathways (M6). Define IPR ownership and licensing for all project outputs. Update exploitation plan at M24 based on results. Identify spin-off and licensing opportunities for each partner.

**T7.3: Ethics Advisory Board and ELSI Monitoring**
- Lead: CyberEthics Lab (P3) | Contributors: KU Leuven (P2)
- Duration: M3–M36
- Dependencies: None
- Establish Ethics Advisory Board with ≥1 external member by M3. Conduct bi-annual ethics reviews (M6, M12, M18, M24, M30). Perform algorithmic bias audits on WP2/WP3 outputs. Monitor alignment with EU AI Act risk categories. Produce ELSI assessment report (D7.2).

**T7.4: Scientific Dissemination**
- Lead: TUM (P1) | Contributors: All partners
- Duration: M6–M36
- Dependencies: None
- Publish ≥6 peer-reviewed papers in high-impact venues (NeurIPS, ICML, AAAI, ACM FAccT, IEEE S&P). Present at ≥4 international conferences. Organise ≥2 community workshops on AI-on-Demand platform. All publications open access (Gold or Green route).

**T7.5: Policy Briefs and Stakeholder Engagement**
- Lead: TalTech (P5) | Contributors: CyberEthics Lab (P3)
- Duration: M20–M34
- Dependencies: WP6 (pilot results)
- Produce ≥2 policy briefs targeting EU and national policy-makers on trustworthy AI governance in public services. Validate recommendations with ≥2 national or regional public authorities. Disseminate through EU policy networks and stakeholder events.

**T7.6: Standards Contribution**
- Lead: Fraunhofer AISEC (P4) | Contributors: CyberEthics Lab (P3), TUM (P1)
- Duration: M28–M34
- Dependencies: WP3 (D3.4), WP5 (D5.3)
- Submit ≥1 standards-track document to CEN/CENELEC or ETSI on AI-driven cybersecurity monitoring or trustworthiness assessment. Engage with relevant technical committees. Contribute TRUSTEDAI trustworthiness metrics to ongoing standardisation discussions.

**T7.7: Sustainability Roadmap and Final Conference**
- Lead: CyberEthics Lab (P3) | Contributors: All partners
- Duration: M30–M36
- Dependencies: All WPs
- Develop sustainability roadmap identifying institutional, commercial, and community-driven pathways for post-project continuation. Organise final dissemination conference (M35) presenting all project results. Produce final exploitation report.

### Deliverables

| No. | Title | Type | Lead | Month | Diss. | Description |
|-----|-------|------|------|-------|-------|-------------|
| D7.1 | Project Website | WEB | CyberEthics Lab | M2 | PU | Public website with project information, news, and results |
| D7.2 | Ethics Assessment and ELSI Report | R | CyberEthics Lab | M12 | PU | First ethics review, bias audit results, EU AI Act alignment |
| D7.3 | Exploitation and IPR Plan | R | CyberEthics Lab | M6 | CO | Commercialisation pathways, IPR ownership, licensing strategy |
| D7.4 | Policy Briefs (set of ≥2) | R | TalTech | M30 | PU | AI governance recommendations for public services |
| D7.5 | Standards-Track Submission | G | Fraunhofer AISEC | M34 | PU | Document submitted to CEN/CENELEC or ETSI |
| D7.6 | Sustainability Roadmap and Final Conference Report | R | CyberEthics Lab | M35 | PU | Post-project sustainability plan, conference proceedings |

### Milestones

| No. | Milestone | Lead | Month | Verification Means |
|-----|-----------|------|-------|-------------------|
| MS7.1 | Project website live | CyberEthics Lab | M2 | URL accessible, content published |
| MS7.2 | Ethics Advisory Board operational | CyberEthics Lab | M3 | Board members confirmed, first meeting scheduled |
| MS7.3 | ≥6 peer-reviewed publications submitted | TUM | M34 | Publication list with DOIs or submission confirmations |
| MS7.4 | Standards document submitted to CEN/CENELEC or ETSI | Fraunhofer AISEC | M34 | Submission receipt from standards body |

### Risks and Dependencies

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Insufficient engagement from public authorities for policy validation | Medium | Medium | TalTech's existing government relationships; early stakeholder mapping at M3; formal MoUs by M12 |
| Publication delays due to long peer review cycles | Medium | Low | Submit to multiple venues; use preprint servers (arXiv) for early visibility |
| Ethics Advisory Board members unavailable or disengaged | Low | Medium | Recruit 3 members (only 1 required); provide modest compensation; structured meeting agenda |
| Standards submission timeline misalignment with CEN/CENELEC cycles | Medium | Medium | Engage with technical committee early (M12); Fraunhofer's existing standards relationships |

---

## Deliverable Summary Table (All WPs)

| No. | WP | Title | Type | Lead | Month | Diss. |
|-----|-----|-------|------|------|-------|-------|
| D1.1 | WP1 | Project Management Plan | R | TUM | M2 | CO |
| D1.2 | WP1 | Progress Report — Year 1 | R | TUM | M12 | RE |
| D1.3 | WP1 | Progress Report — Year 2 | R | TUM | M24 | RE |
| D1.4 | WP1 | Final Technical Report | R | TUM | M35 | PU |
| D2.1 | WP2 | XAI State-of-the-Art Survey | R | TUM | M6 | PU |
| D2.2 | WP2 | XAI Framework v1.0 | SW | TUM | M12 | PU |
| D2.3 | WP2 | Interpretability Layer Toolkit | SW | TUM | M22 | PU |
| D2.4 | WP2 | XAI Toolkit v2.0 (integrated) | SW | TUM | M26 | PU |
| D2.5 | WP2 | XAI Validation Report | R | TUM | M30 | PU |
| D3.1 | WP3 | Threat Detection Architecture | R | Fraunhofer AISEC | M10 | PU |
| D3.2 | WP3 | Cybersecurity Platform v1.0 | SW | Fraunhofer AISEC | M20 | PU |
| D3.3 | WP3 | Automated Response Subsystem | SW | Fraunhofer AISEC | M22 | CO |
| D3.4 | WP3 | Cybersecurity Validation Report | R | Fraunhofer AISEC | M28 | PU |
| D4.1 | WP4 | Privacy Techniques Survey | R | KU Leuven | M10 | PU |
| D4.2 | WP4 | Federated Learning Framework | SW | KU Leuven | M18 | PU |
| D4.3 | WP4 | Differential Privacy Module | SW | KU Leuven | M22 | PU |
| D4.4 | WP4 | Privacy-Performance Report | R | KU Leuven | M28 | PU |
| D4.5 | WP4 | GDPR Compliance Report | R | KU Leuven | M30 | CO |
| D5.1 | WP5 | Trustworthiness Framework | R | CyberEthics Lab | M12 | PU |
| D5.2 | WP5 | Fairness Toolkit | TOOL | CyberEthics Lab | M20 | PU |
| D5.3 | WP5 | Robustness & Transparency Toolkit | TOOL | CyberEthics Lab | M24 | PU |
| D5.4 | WP5 | Benchmark Suite | DATA | CyberEthics Lab | M26 | PU |
| D5.5 | WP5 | Toolkit Validation Report | R | CyberEthics Lab | M32 | PU |
| D6.1 | WP6 | Pilot Design Framework | R | TalTech | M20 | PU |
| D6.2 | WP6 | Pilot 1 — Estonia Report | R | TalTech | M28 | PU |
| D6.3 | WP6 | Pilot 2 — Germany Report | R | Fraunhofer AISEC | M32 | PU |
| D6.4 | WP6 | Cross-Pilot Evaluation | R | TalTech | M34 | PU |
| D7.1 | WP7 | Project Website | WEB | CyberEthics Lab | M2 | PU |
| D7.2 | WP7 | Ethics & ELSI Report | R | CyberEthics Lab | M12 | PU |
| D7.3 | WP7 | Exploitation & IPR Plan | R | CyberEthics Lab | M6 | CO |
| D7.4 | WP7 | Policy Briefs | R | TalTech | M30 | PU |
| D7.5 | WP7 | Standards Submission | G | Fraunhofer AISEC | M34 | PU |
| D7.6 | WP7 | Sustainability Roadmap | R | CyberEthics Lab | M35 | PU |

**Total deliverables: 33**

---

## Milestone Summary Table (All WPs)

| No. | WP | Milestone | Lead | Month |
|-----|-----|-----------|------|-------|
| MS1.1 | WP1 | Consortium kickoff completed | TUM | M1 |
| MS1.2 | WP1 | Mid-term review passed | TUM | M18 |
| MS1.3 | WP1 | Final review completed | TUM | M36 |
| MS2.1 | WP2 | XAI survey and roadmap approved | TUM | M6 |
| MS2.2 | WP2 | XAI Framework v1.0 demonstrated | TUM | M12 |
| MS2.3 | WP2 | XAI validated in both pilots | TUM | M30 |
| MS3.1 | WP3 | Architecture specification approved | Fraunhofer AISEC | M10 |
| MS3.2 | WP3 | Platform v1.0 demonstrated | Fraunhofer AISEC | M20 |
| MS3.3 | WP3 | Platform validated in healthcare pilot | Fraunhofer AISEC | M28 |
| MS4.1 | WP4 | Privacy survey completed | KU Leuven | M10 |
| MS4.2 | WP4 | FL achieves ≥95% baseline performance | KU Leuven | M18 |
| MS4.3 | WP4 | GDPR compliance confirmed | KU Leuven | M30 |
| MS5.1 | WP5 | Trustworthiness framework approved | CyberEthics Lab | M12 |
| MS5.2 | WP5 | Fairness toolkit on PyPI | CyberEthics Lab | M20 |
| MS5.3 | WP5 | ≥3 tools on AI-on-Demand platform | CyberEthics Lab | M32 |
| MS6.1 | WP6 | Pilot 1 operational in Estonia | TalTech | M22 |
| MS6.2 | WP6 | Pilot 2 operational in Germany | Fraunhofer AISEC | M24 |
| MS6.3 | WP6 | Both pilots completed, evaluation accepted | TalTech | M34 |
| MS7.1 | WP7 | Project website live | CyberEthics Lab | M2 |
| MS7.2 | WP7 | Ethics Advisory Board operational | CyberEthics Lab | M3 |
| MS7.3 | WP7 | ≥6 publications submitted | TUM | M34 |
| MS7.4 | WP7 | Standards document submitted | Fraunhofer AISEC | M34 |

**Total milestones: 22**
