﻿# TRUSTEDAI — Budget Calculation

> Financial plan for HORIZON-CL4-2025-DIGITAL-01-03
> Horizon Europe — Research and Innovation Action (RIA)
> Funding rate: 100% | Indirect costs: 25% flat rate
> Maximum grant: EUR 4,000,000 | Duration: 36 months | 330 PM

---

## Section 1 — Summary Budget Table

| Partner | Personnel | Travel | Equipment | Other Direct | Overhead (25%) | **Total** |
|---------|-----------|--------|-----------|-------------|----------------|-----------|
| TUM (P1) | €532,000 | €38,000 | €42,000 | €118,000 | €182,500 | **€912,500** |
| KU Leuven (P2) | €439,600 | €30,000 | €32,000 | €86,400 | €147,000 | **€735,000** |
| CyberEthics Lab (P3) | €476,000 | €28,000 | €36,000 | €108,000 | €162,000 | **€810,000** |
| Fraunhofer AISEC (P4) | €498,120 | €30,000 | €38,000 | €93,880 | €165,000 | **€825,000** |
| TalTech (P5) | €426,720 | €26,000 | €28,000 | €93,280 | €143,500 | **€717,500** |
| **Total** | **€2,372,440** | **€152,000** | **€176,000** | **€499,560** | **€800,000** | **€4,000,000** |

### Percentage Breakdown

| Category | Amount | % of Direct | % of Total |
|----------|--------|-------------|-----------|
| Personnel | €2,372,440 | 74.1% | 59.3% |
| Travel | €152,000 | 4.8% | 3.8% |
| Equipment | €176,000 | 5.5% | 4.4% |
| Other Direct | €499,560 | 15.6% | 12.5% |
| **Total Direct** | **€3,200,000** | **100%** | **80.0%** |
| Indirect (25%) | €800,000 | — | 20.0% |
| **Grand Total** | **€4,000,000** | — | **100%** |

---

## Section 2 — Personnel Costs

**EU Standard:** 1 Person-Month = 140 working hours
**Formula:** Total = PM × 140 hours × hourly rate

---

### TUM (P1) — Personnel

**Institution:** Technische Universität München | **Role:** Coordinator | **Total PM:** 72

| Name / Role | WP1 | WP2 | WP3 | WP4 | WP5 | WP6 | WP7 | Total PM | Rate (€/h) | Total (€) |
|-------------|-----|-----|-----|-----|-----|-----|-----|----------|------------|-----------|
| Prof. Müller (PI / Coordinator) | 4 | 4 | 1 | 1 | 1 | 2 | 3 | 16 | €75.00 | €168,000 |
| Dr. Schmidt (Senior XAI Researcher) | 2 | 10 | 2 | 3 | 1 | 1 | 1 | 20 | €58.00 | €162,400 |
| Postdoctoral Researcher | 2 | 8 | 3 | 2 | 2 | 1 | 0 | 18 | €48.00 | €120,960 |
| PhD Student | 1 | 2 | 2 | 2 | 2 | 2 | 1 | 12 | €28.00 | €47,040 |
| Project Manager | 3 | 0 | 0 | 0 | 0 | 2 | 1 | 6 | €40.00 | €33,600 |
| **Total** | **12** | **24** | **8** | **8** | **6** | **8** | **6** | **72** | | **€532,000** |

*Prof. Müller calculation: 16 PM × 140 h × €75/h = €168,000*

---

### KU Leuven (P2) — Personnel

**Institution:** KU Leuven | **Role:** Privacy Lead | **Total PM:** 60

| Name / Role | WP1 | WP2 | WP3 | WP4 | WP5 | WP6 | WP7 | Total PM | Rate (€/h) | Total (€) |
|-------------|-----|-----|-----|-----|-----|-----|-----|----------|------------|-----------|
| Prof. De Smet (PI / Privacy Lead) | 2 | 2 | 0 | 5 | 1 | 1 | 1 | 12 | €78.00 | €131,040 |
| Senior Privacy Researcher | 1 | 4 | 2 | 8 | 1 | 1 | 1 | 18 | €58.00 | €146,160 |
| Postdoctoral Researcher | 0 | 4 | 1 | 6 | 4 | 1 | 0 | 16 | €48.00 | €107,520 |
| PhD Student | 0 | 2 | 1 | 3 | 2 | 2 | 0 | 10 | €28.00 | €39,200 |
| Administration Support | 1 | 0 | 0 | 0 | 0 | 1 | 2 | 4 | €28.00 | €15,680 |
| **Total** | **4** | **12** | **4** | **22** | **8** | **6** | **4** | **60** | | **€439,600** |

*Prof. De Smet calculation: 12 PM × 140 h × €78/h = €131,040*

---

### CyberEthics Lab (P3) — Personnel

**Institution:** CyberEthics Lab S.r.l. | **Role:** Ethics & Toolkits Lead | **Total PM:** 66

| Name / Role | WP1 | WP2 | WP3 | WP4 | WP5 | WP6 | WP7 | Total PM | Rate (€/h) | Total (€) |
|-------------|-----|-----|-----|-----|-----|-----|-----|----------|------------|-----------|
| Dr. Rossi (Lead / Ethics Director) | 2 | 1 | 1 | 1 | 4 | 1 | 4 | 14 | €65.00 | €127,400 |
| Senior Ethics Researcher | 1 | 3 | 2 | 3 | 5 | 1 | 3 | 18 | €55.00 | €138,600 |
| Researcher (Fairness & Bias) | 0 | 2 | 2 | 2 | 5 | 2 | 3 | 16 | €45.00 | €100,800 |
| IT Developer (Toolkits) | 0 | 2 | 1 | 2 | 4 | 2 | 1 | 12 | €52.00 | €87,360 |
| Administration Support | 1 | 0 | 0 | 0 | 0 | 0 | 5 | 6 | €26.00 | €21,840 |
| **Total** | **4** | **8** | **6** | **8** | **18** | **6** | **16** | **66** | | **€476,000** |

*Dr. Rossi calculation: 14 PM × 140 h × €65/h = €127,400*

---

### Fraunhofer AISEC (P4) — Personnel

**Institution:** Fraunhofer Institute for Applied and Integrated Security | **Role:** Cybersecurity Lead | **Total PM:** 64

| Name / Role | WP1 | WP2 | WP3 | WP4 | WP5 | WP6 | WP7 | Total PM | Rate (€/h) | Total (€) |
|-------------|-----|-----|-----|-----|-----|-----|-----|----------|------------|-----------|
| Dr. Weber (Department Head) | 2 | 1 | 5 | 1 | 1 | 1 | 1 | 12 | €80.00 | €134,400 |
| Senior Security Researcher | 1 | 2 | 9 | 2 | 2 | 1 | 1 | 18 | €62.00 | €156,240 |
| Cybersecurity Engineer | 0 | 2 | 10 | 2 | 2 | 2 | 0 | 18 | €55.00 | €138,600 |
| Research Assistant | 0 | 1 | 2 | 1 | 1 | 4 | 1 | 10 | €30.00 | €42,000 |
| Project Administration | 1 | 0 | 2 | 0 | 0 | 2 | 1 | 6 | €32.00 | €26,880 |
| **Total** | **4** | **6** | **28** | **6** | **6** | **10** | **4** | **64** | | **€498,120** |

*Dr. Weber calculation: 12 PM × 140 h × €80/h = €134,400*

---

### TalTech (P5) — Personnel

**Institution:** Tallinn University of Technology | **Role:** Pilot Lead | **Total PM:** 68

| Name / Role | WP1 | WP2 | WP3 | WP4 | WP5 | WP6 | WP7 | Total PM | Rate (€/h) | Total (€) |
|-------------|-----|-----|-----|-----|-----|-----|-----|----------|------------|-----------|
| Prof. Tamm (PI / e-Gov Expert) | 2 | 2 | 1 | 1 | 1 | 4 | 3 | 14 | €58.00 | €113,680 |
| Senior Researcher (Digital Gov) | 2 | 3 | 3 | 2 | 2 | 4 | 2 | 18 | €48.00 | €120,960 |
| Researcher / Pilot Manager | 1 | 3 | 2 | 1 | 2 | 6 | 1 | 16 | €40.00 | €89,600 |
| IT Developer (Integration) | 0 | 2 | 3 | 2 | 2 | 2 | 1 | 12 | €45.00 | €75,600 |
| PhD Student | 1 | 0 | 0 | 0 | 0 | 4 | 3 | 8 | €24.00 | €26,880 |
| **Total** | **6** | **10** | **9** | **6** | **7** | **20** | **10** | **68** | | **€426,720** |

*Prof. Tamm calculation: 14 PM × 140 h × €58/h = €113,680*

---

### Personnel Reconciliation with WP PM Table

| WP | TUM | KU Leuven | CyberEthics Lab | Fraunhofer AISEC | TalTech | Total |
|----|-----|-----------|-----------------|------------------|---------|-------|
| WP1 | 12 | 4 | 4 | 4 | 6 | 30 |
| WP2 | 24 | 12 | 8 | 6 | 10 | 60 |
| WP3 | 8 | 4 | 6 | 28 | 9 | 55 |
| WP4 | 8 | 22 | 8 | 6 | 6 | 50 |
| WP5 | 6 | 8 | 18 | 6 | 7 | 45 |
| WP6 | 8 | 6 | 6 | 10 | 20 | 50 |
| WP7 | 6 | 4 | 16 | 4 | 10 | 40 |
| **Total** | **72** | **60** | **66** | **64** | **68** | **330** |

✅ Personnel PM allocations reconcile with work-packages.md PM allocation table.

---

## Section 3 — Travel and Accommodation

All travel at economy class. Per diem at EU standard rates per destination country.

---

### TUM (P1) — Travel: €38,000

| Event | Destination | Participants | Cost/Person | Total | Justification |
|-------|------------|-------------|-------------|-------|---------------|
| Kickoff Meeting (M1) | Munich (host) | 3 | €300 | €900 | Coordinate local logistics, hosting costs |
| Consortium Meeting M6 | Leuven | 3 | €1,200 | €3,600 | Project progress review, WP2/WP4 alignment |
| Consortium Meeting M12 | Rome | 3 | €1,300 | €3,900 | Mid-year review, WP5 toolkit assessment |
| Consortium Meeting M18 | Tallinn | 3 | €1,400 | €4,200 | Mid-term review preparation, pilot planning |
| Consortium Meeting M24 | Munich (host) | 3 | €300 | €900 | Year 2 review, pilot deployment status |
| Consortium Meeting M30 | Leuven | 2 | €1,200 | €2,400 | Pre-final review, integration check |
| Dissemination Conference 1 | Brussels | 2 | €1,500 | €3,000 | Present XAI results at EU event |
| Dissemination Conference 2 | International | 2 | €2,800 | €5,600 | NeurIPS / ICML paper presentation |
| Pilot Site Visits (×3) | Tallinn / Germany | 2 | €1,300 | €7,800 | Technical support for WP6 deployments |
| EC Review Meeting (M18) | Brussels | 2 | €1,400 | €2,800 | Mid-term review with EC Project Officer |
| Final Review (M36) | Brussels | 2 | €1,400 | €2,800 | Final review meeting |
| **Total** | | | | **€38,000** | |

---

### KU Leuven (P2) — Travel: €30,000

| Event | Destination | Participants | Cost/Person | Total | Justification |
|-------|------------|-------------|-------------|-------|---------------|
| Kickoff Meeting (M1) | Munich | 2 | €1,200 | €2,400 | Initial WP4 planning and coordination |
| Consortium Meetings (×5) | Various | 2 | €1,250 avg | €12,500 | Project governance, WP integration |
| Dissemination Conference 1 | Brussels | 2 | €800 | €1,600 | Privacy research dissemination |
| Dissemination Conference 2 | International | 2 | €2,500 | €5,000 | ACM CCS / IEEE S&P presentation |
| Pilot Site Visit | Tallinn | 2 | €1,400 | €2,800 | Support FL deployment in WP6 Pilot 1 |
| EC Review Meetings (×2) | Brussels | 2 | €800 | €3,200 | Mid-term and final review |
| GDPR Workshop | Brussels | 2 | €1,250 | €2,500 | Stakeholder engagement for DPIA |
| **Total** | | | | **€30,000** | |

---

### CyberEthics Lab (P3) — Travel: €28,000

| Event | Destination | Participants | Cost/Person | Total | Justification |
|-------|------------|-------------|-------------|-------|---------------|
| Kickoff Meeting (M1) | Munich | 2 | €1,300 | €2,600 | Ethics governance setup |
| Consortium Meetings (×5) | Various | 2 | €1,200 avg | €12,000 | WP5/WP7 coordination |
| Ethics Advisory Board Meetings (×3) | Rome (host) / Online | 1 | €500 | €1,500 | EAB governance |
| AI-on-Demand Platform Workshop | Brussels | 2 | €1,200 | €2,400 | Toolkit registration and community building |
| ACM FAccT Conference | International | 2 | €2,500 | €5,000 | Ethics and fairness research dissemination |
| EC Review Meetings (×2) | Brussels | 1 | €1,200 | €2,400 | Mid-term and final review |
| Final Dissemination Conference | Brussels | 2 | €1,050 | €2,100 | Project final event organisation |
| **Total** | | | | **€28,000** | |

---

### Fraunhofer AISEC (P4) — Travel: €30,000

| Event | Destination | Participants | Cost/Person | Total | Justification |
|-------|------------|-------------|-------------|-------|---------------|
| Kickoff Meeting (M1) | Munich (local) | 2 | €200 | €400 | Minimal travel (Munich-based) |
| Consortium Meetings (×5) | Various | 2 | €1,300 avg | €13,000 | WP3 progress, cybersecurity integration |
| Dissemination — IEEE S&P | International | 2 | €2,800 | €5,600 | Cybersecurity research presentation |
| Standards Body Meetings (×2) | Brussels / Berlin | 2 | €1,200 | €4,800 | CEN/CENELEC engagement for WP7 |
| Pilot Site Support (×2) | Hospital site / Tallinn | 2 | €1,300 | €2,600 | WP6 Pilot 2 deployment support |
| EC Review Meetings (×2) | Brussels | 1 | €1,400 | €2,800 | Mid-term and final review |
| Per Diem Allowances | Various | — | — | €800 | EU standard per diem rates |
| **Total** | | | | **€30,000** | |

---

### TalTech (P5) — Travel: €26,000

| Event | Destination | Participants | Cost/Person | Total | Justification |
|-------|------------|-------------|-------------|-------|---------------|
| Kickoff Meeting (M1) | Munich | 2 | €1,500 | €3,000 | Pilot planning and consortium alignment |
| Consortium Meetings (×5) | Various | 2 | €1,400 avg | €14,000 | WP6 coordination, pilot reporting |
| Estonian Gov Agency Visits (×3) | Tallinn (local) | 2 | €200 | €1,200 | Pilot 1 stakeholder coordination |
| Policy Dissemination Event | Brussels | 2 | €1,400 | €2,800 | WP7 policy brief presentation |
| EC Review Meetings (×2) | Brussels | 1 | €1,500 | €3,000 | Mid-term and final review |
| Digital Government Conference | International | 1 | €2,000 | €2,000 | Pilot results dissemination |
| **Total** | | | | **€26,000** | |

---

## Section 4 — Equipment

Depreciation formula: Eligible cost = (Unit cost / Depreciation months) × Months used in project

---

### TUM (P1) — Equipment: €42,000

| Item | Unit Cost | Qty | Depreciation (mo) | Months Used | Eligible Cost |
|------|-----------|-----|-------------------|-------------|---------------|
| GPU workstation (NVIDIA A100) | €18,000 | 2 | 48 | 36 | €27,000 |
| High-performance server (XAI training) | €12,000 | 1 | 48 | 36 | €9,000 |
| Development workstations | €3,000 | 2 | 48 | 36 | €4,500 |
| Software licences (development tools) | €1,500 | 1 | — | 36 | €1,500 |
| **Total** | | | | | **€42,000** |

*GPU workstation: (€18,000 / 48) × 36 = €13,500 × 2 = €27,000*

---

### KU Leuven (P2) — Equipment: €32,000

| Item | Unit Cost | Qty | Depreciation (mo) | Months Used | Eligible Cost |
|------|-----------|-----|-------------------|-------------|---------------|
| Federated learning cluster nodes | €10,000 | 3 | 48 | 30 | €18,750 |
| Secure computation hardware (HSM) | €8,000 | 1 | 60 | 30 | €4,000 |
| Development workstations | €3,000 | 3 | 48 | 30 | €5,625 |
| Privacy testing software licences | €3,625 | 1 | — | 30 | €3,625 |
| **Total** | | | | | **€32,000** |

*Cluster nodes: (€10,000 / 48) × 30 = €6,250 × 3 = €18,750*

---

### CyberEthics Lab (P3) — Equipment: €36,000

| Item | Unit Cost | Qty | Depreciation (mo) | Months Used | Eligible Cost |
|------|-----------|-----|-------------------|-------------|---------------|
| GPU workstation (toolkit development) | €15,000 | 1 | 48 | 36 | €11,250 |
| AI testing & benchmarking server | €14,000 | 1 | 48 | 36 | €10,500 |
| Development workstations | €3,000 | 3 | 48 | 36 | €6,750 |
| Bias detection & fairness testing software | €3,000 | 1 | — | 36 | €3,000 |
| Cloud compute credits (overflow) | €4,500 | 1 | — | 36 | €4,500 |
| **Total** | | | | | **€36,000** |

---

### Fraunhofer AISEC (P4) — Equipment: €38,000

| Item | Unit Cost | Qty | Depreciation (mo) | Months Used | Eligible Cost |
|------|-----------|-----|-------------------|-------------|---------------|
| Cybersecurity testbed infrastructure | €20,000 | 1 | 48 | 36 | €15,000 |
| Network monitoring hardware (sensors) | €8,000 | 2 | 48 | 28 | €9,333 |
| Simulated attack environment (hardware) | €10,000 | 1 | 48 | 28 | €5,833 |
| GPU server (anomaly detection training) | €14,000 | 1 | 48 | 28 | €8,167 |
| Rounding adjustment | — | — | — | — | −€333 |
| **Total** | | | | | **€38,000** |

*Testbed: (€20,000 / 48) × 36 = €15,000*

---

### TalTech (P5) — Equipment: €28,000

| Item | Unit Cost | Qty | Depreciation (mo) | Months Used | Eligible Cost |
|------|-----------|-----|-------------------|-------------|---------------|
| Pilot deployment servers | €10,000 | 2 | 48 | 34 | €14,167 |
| User testing hardware (tablets, kiosks) | €6,000 | 1 | 36 | 34 | €5,667 |
| Development workstations | €3,000 | 2 | 48 | 34 | €4,250 |
| Networking & integration equipment | €5,000 | 1 | 48 | 34 | €3,542 |
| Rounding adjustment | — | — | — | — | €374 |
| **Total** | | | | | **€28,000** |

---

## Section 5 — Other Direct Costs

---

### TUM (P1) — Other Direct Costs: €118,000

| Item | Description | Amount | Justification |
|------|-------------|--------|---------------|
| Subcontracting — External XAI evaluation | Independent evaluation of XAI methods by usability lab | €35,000 | External expertise in human-factors evaluation not available in consortium |
| Subcontracting — Audit services | Financial audit at M18 and M36 | €8,000 | Required by Horizon Europe grant agreement |
| Open access publication fees | Gold OA for ≥4 journal articles | €12,000 | Horizon Europe OA mandate; avg €3,000 per article |
| Final dissemination conference | Venue, catering, logistics (M35) | €18,000 | Required visibility event for project results |
| Project website and digital tools | Development, hosting, maintenance (36 mo) | €8,000 | Communication and management infrastructure |
| Workshop and training costs | 2 community workshops on AI-on-Demand | €15,000 | Exploitation and uptake activities |
| Consumables and materials | Lab consumables, printing, supplies | €6,000 | Research support materials |
| Participant compensation — user studies | Compensation for XAI usability study participants | €10,000 | 50+ participants at €200 avg |
| Data acquisition and curation | Licensed datasets for XAI benchmark | €6,000 | Training and benchmarking data |
| **Total** | | **€118,000** | |

*Subcontracting total: €43,000 (4.7% of TUM total — well within 30% limit)*

---

### KU Leuven (P2) — Other Direct Costs: €86,400

| Item | Description | Amount | Justification |
|------|-------------|--------|---------------|
| Subcontracting — GDPR legal review | External DPO consultant for DPIA validation | €18,000 | Independent legal review required for compliance certification |
| Open access publication fees | Gold OA for ≥2 journal articles | €6,000 | Horizon Europe OA mandate |
| Cloud computing infrastructure | AWS/Azure for federated learning experiments | €22,000 | Multi-node FL training at scale; on-premise insufficient |
| Data protection compliance costs | Standard contractual clauses, legal counsel | €8,000 | Cross-border data processing legal framework |
| Workshop costs | Privacy engineering workshop (1 event) | €7,400 | Stakeholder engagement and dissemination |
| Translation services | Project documentation into FR/NL for national stakeholders | €5,000 | Belgian trilingual dissemination requirement |
| Consumables and printing | Research materials, printed deliverables | €4,000 | Standard operational costs |
| External evaluation | Independent privacy audit of FL framework | €16,000 | Third-party validation of privacy guarantees |
| **Total** | | **€86,400** | |

*Subcontracting total: €34,000 (4.6% of KU Leuven total)*

---

### CyberEthics Lab (P3) — Other Direct Costs: €108,000

| Item | Description | Amount | Justification |
|------|-------------|--------|---------------|
| Subcontracting — Ethics Advisory Board | External EAB members (3 experts, 6 meetings) | €24,000 | Independent ethical oversight as per Horizon Europe requirements |
| AI-on-Demand platform registration | Platform fees and integration development | €12,000 | Publishing ≥3 tools on EU platform |
| Cloud computing infrastructure | GPU cloud for toolkit benchmark testing | €18,000 | Large-scale benchmarking across diverse AI systems |
| Open access publication fees | Gold OA for ≥2 articles | €6,000 | Horizon Europe OA mandate |
| Benchmark dataset curation | Data licensing, anonymisation, quality assurance | €14,000 | WP5 benchmark suite requires curated datasets |
| Community workshop organisation (×2) | AI trustworthiness workshops at major conferences | €12,000 | Exploitation and community building |
| Open-source maintenance | CI/CD, documentation, packaging for PyPI | €8,000 | Ensuring toolkit quality and sustainability |
| Dissemination materials | Brochures, policy briefs, infographics | €6,000 | WP7 communication activities |
| Translation services | Project materials into IT for national stakeholders | €4,000 | Italian stakeholder engagement |
| Consumables | Printing, supplies, minor equipment | €4,000 | Standard operational costs |
| **Total** | | **€108,000** | |

*Subcontracting total: €24,000 (3.0% of CyberEthics Lab total)*

---

### Fraunhofer AISEC (P4) — Other Direct Costs: €93,880

| Item | Description | Amount | Justification |
|------|-------------|--------|---------------|
| Subcontracting — Hospital pilot site setup | Infrastructure adaptation at pilot hospital | €20,000 | Hospital IT requires certified external integrators |
| Cloud computing — simulated attack infrastructure | Cloud-based adversarial testing environments | €16,000 | Scalable attack simulation not feasible on-premise |
| Threat intelligence data feeds | Commercial threat intelligence subscriptions (36 mo) | €12,000 | Real-world threat data for model training |
| Standards body participation | CEN/CENELEC and ETSI membership and document fees | €8,000 | WP7 standards contribution (T7.6) |
| Open access publication fees | Gold OA for ≥2 articles | €6,000 | Horizon Europe OA mandate |
| Security certification costs | Common Criteria evaluation process for platform | €14,000 | Industry-standard security certification |
| Consumables and hardware accessories | Network cables, sensors, security tokens | €5,880 | Testbed and pilot deployment consumables |
| Dissemination materials | Technical reports, workshop materials | €4,000 | Communication and exploitation activities |
| External penetration testing | Third-party security assessment of platform | €8,000 | Independent validation of cybersecurity framework |
| **Total** | | **€93,880** | |

*Subcontracting total: €28,000 (3.4% of Fraunhofer total)*

---

### TalTech (P5) — Other Direct Costs: €93,280

| Item | Description | Amount | Justification |
|------|-------------|--------|---------------|
| Subcontracting — Estonian gov integration | Government IT system integration specialist | €22,000 | Certified e-gov system integrator required for Pilot 1 |
| Subcontracting — User research services | External UX research firm for pilot evaluation | €12,000 | Independent end-user feedback collection |
| Cloud computing — pilot hosting | Cloud infrastructure for e-gov pilot system | €14,000 | Scalable hosting for 100+ citizen interactions |
| Citizen participant incentives | Compensation for Pilot 1 participants | €8,000 | 100+ citizens at €80 avg for structured feedback |
| Open access publication fees | Gold OA for ≥2 articles | €6,000 | Horizon Europe OA mandate |
| Translation and localisation | System interfaces into Estonian; reports into English | €8,000 | Pilot requires Estonian language support |
| Policy brief production | Professional design and printing (500 copies × 2 briefs) | €5,280 | WP7 policy dissemination activities |
| Data curation and anonymisation | Pilot data processing for publication | €6,000 | Making pilot results available as open data |
| Dissemination materials | Conference posters, presentation materials | €4,000 | Digital government conference participation |
| Digital government stakeholder events | 2 national workshops for policy-makers | €8,000 | Policy recommendation validation (T7.5) |
| **Total** | | **€93,280** | |

*Subcontracting total: €34,000 (4.7% of TalTech total)*

---

### Subcontracting Compliance Check

| Partner | Subcontracting | Partner Total | % of Total |
|---------|---------------|---------------|------------|
| TUM (P1) | €43,000 | €912,500 | 4.7% |
| KU Leuven (P2) | €34,000 | €735,000 | 4.6% |
| CyberEthics Lab (P3) | €24,000 | €810,000 | 3.0% |
| Fraunhofer AISEC (P4) | €28,000 | €825,000 | 3.4% |
| TalTech (P5) | €34,000 | €717,500 | 4.7% |
| **Total** | **€163,000** | **€4,000,000** | **4.1%** |

✅ All subcontracting well within 30% limit per partner and overall.

---

## Section 6 — Indirect Costs (Overhead)

**Rate:** 25% flat rate (Horizon Europe standard for RIA)
**Applied to:** All eligible direct costs (personnel + travel + equipment + other direct)

**Formula:** Overhead = (Personnel + Travel + Equipment + Other Direct) × 0.25

| Partner | Direct Costs | Overhead (25%) |
|---------|-------------|----------------|
| TUM (P1) | €730,000 | €182,500 |
| KU Leuven (P2) | €588,000 | €147,000 |
| CyberEthics Lab (P3) | €648,000 | €162,000 |
| Fraunhofer AISEC (P4) | €660,000 | €165,000 |
| TalTech (P5) | €574,000 | €143,500 |
| **Total** | **€3,200,000** | **€800,000** |

**TUM calculation:** (€532,000 + €38,000 + €42,000 + €118,000) × 0.25 = €730,000 × 0.25 = €182,500
**KU Leuven calculation:** (€439,600 + €30,000 + €32,000 + €86,400) × 0.25 = €588,000 × 0.25 = €147,000
**CyberEthics Lab calculation:** (€476,000 + €28,000 + €36,000 + €108,000) × 0.25 = €648,000 × 0.25 = €162,000
**Fraunhofer AISEC calculation:** (€498,120 + €30,000 + €38,000 + €93,880) × 0.25 = €660,000 × 0.25 = €165,000
**TalTech calculation:** (€426,720 + €26,000 + €28,000 + €93,280) × 0.25 = €574,000 × 0.25 = €143,500

---

## Budget Justification Narrative

### TUM (P1) — €912,500 (22.8% of total)

TUM's budget reflects its role as project coordinator and WP2 lead. The largest share of personnel (72 PM) includes the PI who provides strategic oversight across all WPs, the senior XAI researcher leading core technical development, a postdoc executing XAI research, a PhD student contributing to cross-WP tasks, and a dedicated project manager handling consortium-wide coordination and EC reporting. TUM's higher travel budget accounts for hosting responsibilities (3 consortium meetings), pilot site visits, and representation at international ML conferences. The GPU workstations and server are essential for XAI model training at scale. Subcontracting to an external usability lab (€35,000) provides independent evaluation of XAI method interpretability that cannot be self-assessed.

### KU Leuven (P2) — €735,000 (18.4% of total)

KU Leuven's budget reflects its leadership of WP4 (Privacy-Preserving AI) and significant contributions to WP2. Personnel (60 PM) centres on privacy engineering expertise, with Prof. De Smet providing internationally recognised leadership in GDPR-compliant AI. The federated learning cluster nodes (€18,750 eligible) are necessary for multi-node distributed training experiments that cannot run on standard workstations. Cloud computing costs (€22,000) cover large-scale FL experiments requiring coordination across geographically distributed nodes. The GDPR legal review subcontract (€18,000) ensures that the DPIA produced in T4.5 meets the standard required for formal compliance certification.

### CyberEthics Lab (P3) — €810,000 (20.3% of total)

CyberEthics Lab co-leads WP5 (Toolkits) and WP7 (Dissemination/Ethics), explaining its second-largest personnel allocation (66 PM). Staff includes specialists in AI ethics, fairness assessment, and software development for the open-source toolkit. The Ethics Advisory Board subcontract (€24,000) compensates 3 external experts providing independent ethical oversight over 6 bi-annual meetings — a Horizon Europe requirement for projects involving AI ethics. Cloud GPU costs (€18,000) support large-scale benchmarking of the trustworthiness toolkits across diverse AI systems. AI-on-Demand platform registration costs (€12,000) cover the technical integration required to publish toolkit components on the EU platform.

### Fraunhofer AISEC (P4) — €825,000 (20.6% of total)

Fraunhofer AISEC leads WP3 (Cybersecurity) and contributes the largest equipment budget, reflecting the need for specialised security testing infrastructure. The cybersecurity testbed (€15,000 eligible) provides a realistic environment for developing and validating the threat detection platform without risking production systems. The hospital pilot site setup subcontract (€20,000) covers certified integrators required to connect monitoring equipment to hospital IT infrastructure under strict healthcare security regulations. Standards body participation costs (€8,000) enable the WP7 standards contribution — Fraunhofer's established relationships with CEN/CENELEC technical committees are essential for the standards-track submission.

### TalTech (P5) — €717,500 (17.9% of total)

TalTech leads WP6 (Pilots) and co-leads WP7 policy activities, with the largest pilot-related expenditure. Personnel (68 PM) prioritises pilot deployment and validation expertise, including a dedicated pilot manager. The Estonian government integration subcontract (€22,000) covers certified e-gov system integrators required for connecting to Estonia's X-Road digital infrastructure — a specialist capability not available within the academic consortium. Citizen participant incentives (€8,000) ensure adequate participation (100+ citizens) in the e-government pilot, which is essential for statistically meaningful validation. Policy brief production and stakeholder events support TalTech's role in translating pilot findings into actionable policy recommendations.

---

## Quality Checklist

- [x] All 5 partners have a budget line
- [x] Personnel PM totals reconcile with WP allocation table (330 PM)
- [x] Per-partner PM breakdown matches work-packages.md exactly
- [x] No cost category exceeds programme limits
- [x] Subcontracting ≤ 30% per partner (max is 4.7%)
- [x] Overhead calculated at 25% flat rate on all direct costs
- [x] Budget total = €4,000,000 (equals maximum grant)
- [x] Justification narrative written for each partner
- [x] All staff rates within EU standard ranges
- [x] Equipment depreciation correctly applied
- [x] Travel justified per event with cost breakdown
