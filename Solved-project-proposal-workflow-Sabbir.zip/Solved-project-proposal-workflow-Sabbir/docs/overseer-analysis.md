# HORIZON EUROPE - Work Programme 2025-2027 HORIZON-CL4-2025-DIGITAL-01-03 Analysis

## 1. Call Requirements Summary
- Programme: Horizon Europe
- Reference Number: HORIZON-CL4-2025-DIGITAL-01-03
- Topic: Trustworthy Artificial Intelligence for Resilient Digital Infrastructure and Public Services
- Type of Action: Research and Innovation Action (RIA)
- Funding Rate: 100% of eligible costs
- Budget Envelope: EUR 8,000,000 (indicative: 2 projects)
- Max EU contribution per project: EUR 4,000,000
- Project Duration: 36 months
- Opening Date: 15 January 2025
- Deadline: 23 September 2025, 17:00 Brussels time
- Submission Procedure: Electronic submission via the EU Funding & Tenders Portal

## 2. Strategic Opportunities
- Top priority 1: Development of explainable AI (XAI) methods for public services
- Top priority 2: Creation of privacy-preserving AI techniques that comply with GDPR
- Top priority 3: Building trustworthy, explainable, and resilient AI systems across various sectors
- Innovation angle: Advancements in XAI, federated learning, differential privacy, and real-time threat detection
- Gaps in the current landscape: Limited trustworthiness and interpretability of AI systems; insufficient focus on GDPR compliance in AI research
- Preferred consortium type: Mixed (academic, SMEs, NGOs, government)
- Budget sweet spot: EUR 4,000,000 per project

## 3. Proposed Project Concept
### Title: TRUSTEDAI - Enhancing Trustworthy Artificial Intelligence for Europe's Digital Infrastructure and Public Services
### Acronym: TRUSTEDAI
### Core Problem: Lack of trustworthiness, explainability, and resilience in AI systems deployed across critical digital infrastructure and public services
### Innovative Solution: Development of cutting-edge XAI methods, privacy-preserving techniques, and real-time threat detection frameworks
### Main Objective: Develop novel explainable AI methods for high-stakes decision support in public services, ensuring outputs are interpretable by non-technical stakeholders
#### Specific Objectives:
1. Develop explainable AI (XAI) methods suitable for high-stakes decision support in public services
2. Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure
3. Create privacy-preserving AI techniques (e.g., federated learning, differential privacy) that comply with GDPR while maintaining model performance
4. Build open-source AI toolkits and benchmarks for trustworthiness assessment
5. Demonstrate the developed solutions through at least two real-world pilot deployments in different EU Member States
6. Contribute to European standardisation bodies (CEN/CENELEC, ETSI) with at least one standards-track document submitted during the project lifetime
7. Provide policy recommendations for AI governance in public services, validated with at least 2 national or regional public authorities
#### Key Outputs:
1. XAI methodologies and frameworks
2. Real-time cybersecurity monitoring tools
3. Privacy-preserving AI techniques (e.g., federated learning, differential privacy)
4. Open-source AI toolkits and benchmarks for trustworthiness assessment
5. Policy recommendations for AI governance in public services
6. Standards-track documents submitted to CEN/CENELEC, ETSI
7. Two real-world pilot deployments in EU Member States
#### Expected Impacts:
1. Increased trust in AI-based public services
2. Improved cyber-resilience of critical digital infrastructure
3. At least 3 open-source tools or libraries published under permissive licenses (Apache 2.0 or equivalent) and registered in the EU AI-on-Demand platform
4. Policy recommendations for AI governance in public services, validated with at least 2 national or regional public authorities
5. Contribution to European standardisation bodies (CEN/CENELEC, ETSI)
6. Strengthened Europe's position as a global leader in trustworthy AI
7. Reduced dependency on non-European AI technology
8. Support for the uptake of AI in public administration while safeguarding fundamental rights

## 4. Consortium Design

| Partner | Institution | Country | Type | Role |
|---------|------------|---------|------|------|
| P1 (Coordinator) | Technische Universität München (TUM) | Germany | University | Project coordination, XAI research lead |
| P2 | KU Leuven | Belgium | University | Privacy-preserving AI, federated learning |
| P3 | CyberEthics Lab | Italy | SME (AI/Ethics) | AI ethics toolkits, bias detection, ELSI |
| P4 | Fraunhofer AISEC | Germany | Research Centre | Cybersecurity frameworks, threat detection |
| P5 | Tallinn University of Technology (TalTech) | Estonia | University | E-government AI pilots, policy validation |

- Number of partners: 5
- Countries: 4 EU Member States (Germany, Belgium, Italy, Estonia) — geographic balance across Western, Southern, and Northern/Eastern Europe
- Expertise coverage: AI/ML (TUM, KU Leuven), Cybersecurity (Fraunhofer AISEC), Ethics & Governance (CyberEthics Lab), Digital Public Services (TalTech)
- Coordinator profile: TUM — top-ranked European university in AI and computer science, strong Horizon Europe track record, dedicated EU project management office

## 5. Work Package Architecture (7 WPs)

| WP | Title | Lead | Duration | Est. PM | Key Deliverables |
|----|-------|------|----------|---------|-----------------|
| WP1 | Project Management, Quality Assurance & Coordination | TUM (P1) | M1–M36 | 30 | Management Plan (M2), Progress Reports (M12, M24), Final Report (M35) |
| WP2 | Explainable AI Methods for Public Services | TUM (P1) | M1–M30 | 60 | XAI Framework v1.0 (M12), Interpretability Layer Toolkit (M22), XAI Toolkit v2.0 (M26), Validation Report (M30) |
| WP3 | AI-Driven Cybersecurity & Real-Time Threat Detection | Fraunhofer AISEC (P4) | M1–M28 | 55 | Threat Detection Architecture (M10), Monitoring Platform v1.0 (M20), Validation Report (M28) |
| WP4 | Privacy-Preserving AI Techniques | KU Leuven (P2) | M4–M30 | 50 | Privacy Techniques Survey (M10), Federated Learning Framework (M18), Differential Privacy Module (M22), GDPR Compliance Report (M30) |
| WP5 | Open-Source Trustworthiness Toolkits & Benchmarks | CyberEthics Lab (P3) | M6–M32 | 45 | Fairness Toolkit (M20), Robustness & Transparency Toolkit (M24), Benchmark Suite (M26), Validation Report (M32) |
| WP6 | Real-World Pilot Deployments & Validation | TalTech (P5) | M18–M34 | 50 | Pilot Design Report (M20), Pilot 1 — Estonia e-Gov (M28), Pilot 2 — Germany Healthcare (M32), Evaluation Report (M34) |
| WP7 | Dissemination, Exploitation, Ethics & Sustainability | CyberEthics Lab (P3) | M1–M36 | 40 | Project Website (M2), Exploitation Plan (M6), Ethics Assessment & ELSI Report (M12), Policy Briefs (M30), Standards Submission (M34), Final Conference (M35) |

**Total estimated PM: 330**

### WP1: Project Management, Quality Assurance & Coordination
**Lead:** TUM (P1) | **Duration:** M1–M36 | **PM:** 30
#### Tasks:
1. T1.1: Overall project coordination, consortium governance, and administrative management
2. T1.2: Financial management, EU reporting, and subcontracting oversight
3. T1.3: Quality assurance plan, internal peer reviews, and risk monitoring
4. T1.4: Consortium meetings (kickoff M1, bi-annual meetings M6/M12/M18/M24/M30), decision-making
5. T1.5: Final evaluation, lessons learned, and project closure (M34–M36)

### WP2: Explainable AI Methods for Public Services
**Lead:** TUM (P1) | **Contributors:** KU Leuven (P2), CyberEthics Lab (P3) | **Duration:** M1–M30 | **PM:** 60
#### Tasks:
1. T2.1: Systematic literature review and state-of-the-art analysis of XAI methods (M1–M6)
2. T2.2: Design novel XAI architectures for high-stakes decision support in healthcare, social services, and public administration (M4–M16)
3. T2.3: Develop interpretability layers that produce explanations understandable by non-technical stakeholders (M10–M22)
4. T2.4: Integrate XAI methods with privacy-preserving techniques from WP4 (M18–M26) — Dependency: WP4
5. T2.5: Validate XAI methods through pilot deployments in WP6 (M24–M30) — Dependency: WP6

### WP3: AI-Driven Cybersecurity & Real-Time Threat Detection
**Lead:** Fraunhofer AISEC (P4) | **Contributors:** TUM (P1), TalTech (P5) | **Duration:** M1–M28 | **PM:** 55
#### Tasks:
1. T3.1: Review and gap analysis of existing AI-driven cybersecurity monitoring frameworks (M1–M6)
2. T3.2: Design architecture for real-time threat detection across distributed digital infrastructure (M4–M10)
3. T3.3: Develop and train anomaly detection models for network/system monitoring (M8–M18)
4. T3.4: Build automated response and alerting subsystem (M14–M22)
5. T3.5: Validate framework through simulation and integration into WP6 pilots (M20–M28) — Dependency: WP6

### WP4: Privacy-Preserving AI Techniques
**Lead:** KU Leuven (P2) | **Contributors:** TUM (P1), CyberEthics Lab (P3) | **Duration:** M4–M30 | **PM:** 50
#### Tasks:
1. T4.1: Survey privacy-preserving techniques (federated learning, differential privacy, secure multi-party computation) and assess GDPR alignment (M4–M10)
2. T4.2: Develop novel federated learning methods that maintain model performance while ensuring data locality (M8–M18)
3. T4.3: Create differential privacy mechanisms calibrated for public-service AI applications (M12–M22)
4. T4.4: Integrate privacy-preserving modules into WP2 (XAI) and WP3 (cybersecurity) frameworks (M18–M28) — Dependencies: WP2, WP3
5. T4.5: GDPR compliance audit and data protection impact assessment for all project outputs (M24–M30)

### WP5: Open-Source Trustworthiness Toolkits & Benchmarks
**Lead:** CyberEthics Lab (P3) | **Contributors:** All partners | **Duration:** M6–M32 | **PM:** 45
#### Tasks:
1. T5.1: Define trustworthiness dimensions (fairness, robustness, transparency, accountability) and metrics (M6–M12)
2. T5.2: Develop open-source assessment toolkits with standardised APIs (M10–M22)
3. T5.3: Create benchmark datasets and evaluation protocols for trustworthiness testing (M14–M24)
4. T5.4: Validate toolkits against WP2/WP3/WP4 outputs and external AI systems (M22–M30) — Dependencies: WP2, WP3, WP4
5. T5.5: Publish toolkits under Apache 2.0, register on EU AI-on-Demand platform, prepare documentation (M28–M32)

### WP6: Real-World Pilot Deployments & Validation
**Lead:** TalTech (P5) | **Contributors:** All partners | **Duration:** M18–M34 | **PM:** 50
#### Tasks:
1. T6.1: Pilot design — define deployment scenarios, KPIs, and evaluation methodology (M18–M20)
2. T6.2: Pilot 1 — Estonian e-Government: deploy XAI + privacy-preserving AI in public service decision support (M20–M28) — Dependencies: WP2, WP4
3. T6.3: Pilot 2 — German Healthcare: deploy cybersecurity monitoring + XAI in hospital digital infrastructure (M22–M32) — Dependencies: WP2, WP3
4. T6.4: End-user feedback collection, usability assessment, and iterative refinement (M24–M32)
5. T6.5: Cross-pilot comparative evaluation and lessons learned report (M30–M34)

### WP7: Dissemination, Exploitation, Ethics & Sustainability
**Lead:** CyberEthics Lab (P3) | **Contributors:** All partners | **Duration:** M1–M36 | **PM:** 40
#### Tasks:
1. T7.1: Create project website (M1–M2), social media channels, and communication plan
2. T7.2: Develop exploitation and IPR management plan; identify commercialisation pathways (M3–M6, updated M24)
3. T7.3: Conduct project-wide ethics assessments, GDPR compliance monitoring, algorithmic bias audits, and alignment with EU AI Act risk categories (M1–M36)
4. T7.4: Establish and manage external Ethics Advisory Board (at least 1 external member); integrate feedback into project decisions (M3–M36)
5. T7.5: Publish ≥6 peer-reviewed publications in high-impact journals/conferences (M6–M36)
6. T7.6: Produce ≥2 policy briefs for EU/national policy-makers; validate with ≥2 public authorities (M20–M34)
7. T7.7: Submit ≥1 standards-track document to CEN/CENELEC or ETSI (M28–M34)
8. T7.8: Organise final dissemination conference and produce sustainability roadmap (M34–M36)

## 6. Risk and Compliance Flags

| # | Risk | Category | Likelihood | Impact | Mitigation |
|---|------|----------|-----------|--------|------------|
| R1 | XAI methods fail to achieve interpretability by non-technical stakeholders | Technical | M | H | Iterative co-design with end-users from M6; usability testing at M16 checkpoint |
| R2 | Federated learning performance degradation with heterogeneous partner data | Technical | M | M | Use state-of-the-art aggregation strategies; fallback to centralised anonymised approach |
| R3 | Pilot site delays due to institutional approvals (ethics boards, data access) | External | H | H | Start ethics/data access applications at M6 (12 months before pilots); identify backup pilot sites |
| R4 | GDPR compliance challenges with cross-border data processing | Legal | M | H | KU Leuven GDPR expertise embedded in WP4; Data Protection Impact Assessment at M10 |
| R5 | Partner withdrawal or key staff turnover | Consortium | L | H | Shadow roles assigned for all WP leads; consortium agreement includes replacement procedure |
| R6 | Model outputs exhibit undetected algorithmic bias in pilot deployments | Ethical | M | H | WP5 bias detection toolkit applied to all models before deployment; Ethics Advisory Board oversight |
| R7 | Insufficient engagement from public authorities for policy validation | External | M | M | TalTech's existing government relationships; early stakeholder mapping at M3; formal MoUs by M12 |

## 7. Handoff Brief for Agent 2 (Info Page)

- **Project title:** TRUSTEDAI — Enhancing Trustworthy Artificial Intelligence for Europe's Digital Infrastructure and Public Services
- **Acronym:** TRUSTEDAI
- **Programme:** Horizon Europe | **Call:** HORIZON-CL4-2025-DIGITAL-01-03
- **Budget:** EUR 4,000,000 | **Duration:** 36 months
- **Consortium:** 5 partners, 4 EU countries (DE, BE, IT, EE): TUM (coordinator), KU Leuven, CyberEthics Lab, Fraunhofer AISEC, TalTech

**5 specific objectives for the info page:**
1. Develop explainable AI (XAI) methods that make high-stakes public-service decisions interpretable by non-technical stakeholders, validated through 2 pilot deployments by M30
2. Design and validate AI-driven cybersecurity monitoring frameworks that detect and respond to threats in real time across distributed digital infrastructure by M28
3. Create privacy-preserving AI techniques (federated learning, differential privacy) that comply with GDPR while maintaining ≥95% of baseline model performance by M30
4. Build and publish ≥3 open-source AI trustworthiness toolkits under Apache 2.0, registered on the EU AI-on-Demand platform by M32
5. Demonstrate solutions through 2 real-world pilots (Estonian e-Government, German Healthcare) and produce ≥2 validated policy recommendations by M34

**Key selling points:** Novel XAI methods for public services, privacy-by-design AI, real-time cyber-resilience, open-source trustworthiness toolkits, dual-country pilot validation, policy impact through standards and governance recommendations

**Tone:** Innovative, evidence-based, collaborative, impact-driven — positioning Europe as a global leader in trustworthy AI for public benefit