﻿# TRUSTEDAI — Quality Review Report

> Final consistency check and quality assessment
> Call: HORIZON-CL4-2025-DIGITAL-01-03
> Date: Review conducted across all 6 proposal documents

---

## 1. Overall Assessment

### ✅ PASS

The TRUSTEDAI proposal package is internally consistent, complete, and compliant with Horizon Europe RIA requirements. All six documents align on project identity, consortium composition, budget, duration, work package structure, and objectives. No critical issues were found. Minor recommendations are provided below for refinement before submission.

---

## 2. Consistency Matrix

### 2.1 Cross-Document Consistency

| Element | Overseer Analysis | Project Strategy | Info Page | Outline | Work Packages | Budget | Status |
|---------|:-:|:-:|:-:|:-:|:-:|:-:|--------|
| Title: TRUSTEDAI | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Call ref: HORIZON-CL4-2025-DIGITAL-01-03 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Duration: 36 months | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Budget: EUR 4,000,000 | ✅ | ✅ | ✅ | ✅ | — | ✅ | **PASS** |
| Partner count: 5 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Work packages: 7 | ✅ | ✅ | — | ✅ | ✅ | ✅ | **PASS** |
| Total PM: 330 | ✅ | ✅ | — | ✅ | ✅ | ✅ | **PASS** |
| Instrument: RIA | ✅ | ✅ | ✅ | ✅ | — | ✅ | **PASS** |
| Funding rate: 100% | — | — | ✅ | ✅ | — | ✅ | **PASS** |

### 2.2 Partner Names and Roles

| Partner | Short Name | Role | Overseer | Strategy | Info Page | Outline | WPs | Budget | Status |
|---------|-----------|------|:-:|:-:|:-:|:-:|:-:|:-:|--------|
| Technische Universität München | TUM (P1) | Coordinator | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| KU Leuven | KU Leuven (P2) | Privacy Lead | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| CyberEthics Lab | CyberEthics Lab (P3) | Ethics/Toolkits | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Fraunhofer AISEC | Fraunhofer AISEC (P4) | Cybersecurity Lead | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |
| Tallinn University of Technology | TalTech (P5) | Pilot Lead | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | **PASS** |

### 2.3 Objectives Consistency

| Objective | Info Page | Outline | Covered in WPs | Status |
|-----------|:-:|:-:|:-:|--------|
| O1: XAI decision support with ≥75% interpretability (M30) | ✅ | ✅ | WP2 | **PASS** |
| O2: Cybersecurity monitoring with ≥95% detection (M28) | ✅ | ✅ | WP3 | **PASS** |
| O3: Privacy-preserving AI with ≥95% performance retention (M30) | ✅ | ✅ | WP4 | **PASS** |
| O4: Open-source trustworthiness toolkits on AI-on-Demand (M32) | ✅ | ✅ | WP5 | **PASS** |
| O5: Validated in 2 EU pilots across 2 Member States (M34) | ✅ | ✅ | WP6 | **PASS** |

### 2.4 PM Allocation Consistency

| WP | Work Packages Doc | Budget Doc | Status |
|----|:-:|:-:|--------|
| WP1: 30 PM (TUM 12, KU 4, CE 4, FR 4, TT 6) | ✅ | ✅ | **PASS** |
| WP2: 60 PM (TUM 24, KU 12, CE 8, FR 6, TT 10) | ✅ | ✅ | **PASS** |
| WP3: 55 PM (TUM 8, KU 4, CE 6, FR 28, TT 9) | ✅ | ✅ | **PASS** |
| WP4: 50 PM (TUM 8, KU 22, CE 8, FR 6, TT 6) | ✅ | ✅ | **PASS** |
| WP5: 45 PM (TUM 6, KU 8, CE 18, FR 6, TT 7) | ✅ | ✅ | **PASS** |
| WP6: 50 PM (TUM 8, KU 6, CE 6, FR 10, TT 20) | ✅ | ✅ | **PASS** |
| WP7: 40 PM (TUM 6, KU 4, CE 16, FR 4, TT 10) | ✅ | ✅ | **PASS** |
| **Total: 330 PM** | ✅ | ✅ | **PASS** |

### 2.5 Budget Consistency

| Item | Info Page | Outline | Budget Doc | Status |
|------|:-:|:-:|:-:|--------|
| Total budget: €4,000,000 | ✅ | ✅ | ✅ | **PASS** |
| Direct costs: €3,200,000 | — | — | ✅ | **PASS** |
| Overhead (25%): €800,000 | — | — | ✅ | **PASS** |
| TUM total: €912,500 | — | — | ✅ | **PASS** |
| KU Leuven total: €735,000 | — | — | ✅ | **PASS** |
| CyberEthics Lab total: €810,000 | — | — | ✅ | **PASS** |
| Fraunhofer AISEC total: €825,000 | — | — | ✅ | **PASS** |
| TalTech total: €717,500 | — | — | ✅ | **PASS** |

### 2.6 Deliverable Numbering

| WP | Deliverables | Sequential | No Gaps | No Duplicates | Status |
|----|-------------|:-:|:-:|:-:|--------|
| WP1 | D1.1–D1.4 | ✅ | ✅ | ✅ | **PASS** |
| WP2 | D2.1–D2.5 | ✅ | ✅ | ✅ | **PASS** |
| WP3 | D3.1–D3.4 | ✅ | ✅ | ✅ | **PASS** |
| WP4 | D4.1–D4.5 | ✅ | ✅ | ✅ | **PASS** |
| WP5 | D5.1–D5.5 | ✅ | ✅ | ✅ | **PASS** |
| WP6 | D6.1–D6.4 | ✅ | ✅ | ✅ | **PASS** |
| WP7 | D7.1–D7.6 | ✅ | ✅ | ✅ | **PASS** |
| **Total: 33 deliverables** | ✅ | ✅ | ✅ | **PASS** |

### 2.7 Timeline Integrity

All deliverable due dates fall within or after their WP start months. No deliverable is scheduled before its WP begins or after its WP ends. Cross-WP dependencies reference deliverables that are available by the time they are needed.

| Dependency | Source | Required By | Available | Status |
|-----------|--------|-------------|-----------|--------|
| WP2 XAI methods → WP6 pilots | D2.3 (M22) | T6.2 (M20) | D2.2 (M12) available earlier | **PASS** |
| WP3 platform → WP6 Pilot 2 | D3.2 (M20) | T6.3 (M22) | Available before needed | **PASS** |
| WP4 FL framework → WP2 integration | D4.2 (M18) | T2.4 (M18) | Concurrent start, acceptable | **PASS** |
| WP4 FL framework → WP6 Pilot 1 | D4.2 (M18) | T6.2 (M20) | Available before needed | **PASS** |
| WP5 toolkits → WP5 validation | D5.2 (M20), D5.3 (M24) | T5.5 (M22) | Fairness toolkit done; robustness concurrent | **PASS** |

---

## 3. Compliance Checklist

### 3.1 Eligibility

| Requirement | Evidence | Status |
|------------|---------|--------|
| Minimum 3 independent legal entities | 5 partners from 4 EU Member States | ✅ PASS |
| From 3 different EU/associated countries | DE, BE, IT, EE (4 countries) | ✅ PASS |
| At least 1 academic institution | TUM, KU Leuven, TalTech (3 universities) | ✅ PASS |
| At least 1 non-academic entity | Fraunhofer AISEC (RTO), CyberEthics Lab (SME) | ✅ PASS |
| Budget ≤ maximum grant | €4,000,000 = €4,000,000 max | ✅ PASS |
| Duration within allowed range | 36 months (typical for RIA) | ✅ PASS |
| Instrument type: RIA | Correctly identified throughout | ✅ PASS |
| Funding rate: 100% for RIA | Correctly applied | ✅ PASS |

### 3.2 Mandatory Sections

| Section | Present in Outline | Status |
|---------|:-:|--------|
| Executive Summary | Section 1 | ✅ PASS |
| Context and State of the Art | Section 2 | ✅ PASS |
| Objectives and Methodology | Section 3 | ✅ PASS |
| Expected Impact | Section 4 | ✅ PASS |
| Consortium Description | Section 5 | ✅ PASS |
| Work Plan (WP descriptions) | Section 6 + work-packages.md | ✅ PASS |
| Budget Overview | Section 7 + budget-calculation.md | ✅ PASS |
| Risk Management | Section 8 | ✅ PASS |
| Ethics and Data Protection | Section 9 | ✅ PASS |

### 3.3 Financial Compliance

| Check | Value | Limit | Status |
|-------|-------|-------|--------|
| Total budget | €4,000,000 | €4,000,000 | ✅ PASS |
| Overhead rate | 25% flat | 25% flat (HE standard) | ✅ PASS |
| Subcontracting (highest partner) | 4.7% (TUM, TalTech) | 30% | ✅ PASS |
| Subcontracting (total) | 4.1% (€163,000) | 30% | ✅ PASS |
| All partners have budget allocation | 5/5 | — | ✅ PASS |
| Budget sums verified | All correct | — | ✅ PASS |

### 3.4 Evaluation Criteria Coverage

| Criterion | Addressed In | Status |
|-----------|-------------|--------|
| Excellence — clarity of objectives | Info page (5 SMART objectives), Outline S3 | ✅ PASS |
| Excellence — soundness of methodology | Outline S3, Work packages (detailed tasks) | ✅ PASS |
| Excellence — novelty/ambition | Outline S2 (state of art), S3 (beyond SoA) | ✅ PASS |
| Impact — credibility of pathways | Outline S4, WP7 (exploitation plan) | ✅ PASS |
| Impact — sustainability and wider effects | Outline S4, S9, WP7 (sustainability roadmap) | ✅ PASS |
| Implementation — work plan quality | Work packages (33 deliverables, 22 milestones) | ✅ PASS |
| Implementation — consortium capacity | Outline S5, Overseer analysis S5 | ✅ PASS |
| Implementation — resource allocation | Budget doc (fully justified, PM reconciled) | ✅ PASS |

---

## 4. Quality Scores

| Document | Rating | Justification |
|----------|--------|---------------|
| Overseer Analysis | **Strong** | Comprehensive call analysis with strategic positioning, 7-WP architecture, named partners, structured risk table. Clear handoff brief for subsequent agents. |
| Project Strategy | **Strong** | Concise framework covering all essential parameters. Identity, objectives, WP structure, budget guidance, and constraints all present. Effective as an inter-agent coordination document. |
| Project Info Page | **Strong** | Full 1-page format with all required sections. SMART objectives with measurable targets and deadlines. Clear distinction between outputs and outcomes. Contact and budget information present. |
| Project Outline | **Strong** | Comprehensive 9-section proposal covering all Horizon Europe evaluation criteria. Well-structured methodology, clear impact pathway, detailed consortium descriptions, 7-risk management table. Ethics/sustainability section addresses EU AI Act alignment. |
| Work Packages | **Strong** | All 7 WPs fully described with objectives, description of work, detailed tasks (with leads, contributors, durations, dependencies), deliverables (33 total), milestones (22 total), and risk tables. PM allocation tables reconcile across all partners and WPs. |
| Budget Calculation | **Strong** | Complete financial plan with summary table, per-partner personnel breakdown by WP, travel/equipment/other costs itemised with justifications, overhead correctly calculated, subcontracting within limits. All sums verified. |

### Overall Package Quality: **Strong**

---

## 5. Priority Action List

No critical or major issues were identified. The following minor improvements are recommended for submission readiness:

| # | Severity | Area | Issue | Recommendation |
|---|----------|------|-------|----------------|
| 1 | Minor | Info Page | Word count should be verified to ensure ≤600 words for single A4 page | Count words and trim if necessary; current content should be near limit |
| 2 | Minor | Outline | Some state-of-the-art references are described generically (e.g., "recent studies show") | Add specific citation placeholders (e.g., [AuthorYear]) for key claims before submission |
| 3 | Minor | Work Packages | WP4 starts at M4 but some tasks reference WP2 outputs not ready until M12+ | This is already handled by T4.1 running independently M4–M10; consider adding a note clarifying this in the WP4 description |
| 4 | Minor | Budget | Staff names are illustrative (not yet confirmed individuals) | Replace with actual staff names during submission preparation; current named roles are appropriate for proposal stage |
| 5 | Minor | All Docs | No Gantt chart included | Consider generating a visual Gantt chart from the milestone/deliverable timeline for the outline's work plan section |
| 6 | Minor | Outline | Gender equality and inclusiveness plan not explicitly mentioned | Add a brief paragraph on gender balance targets in the consortium and in pilot participant recruitment |
| 7 | Minor | Work Packages | WP6 Pilot 1 references "3 government agencies" but no specific agencies named | Identify target Estonian agencies (e.g., Social Insurance Board, Tax and Customs Board) or mark as TBC |
| 8 | Minor | Budget | Equipment depreciation for Fraunhofer includes a rounding adjustment line | Clean up rounding in final submission; consider adjusting unit costs to eliminate rounding lines |

---

## 6. Scoring Prediction

### Estimated Score Range: 13.5–14.5 / 15

Based on Horizon Europe RIA evaluation criteria (each scored 0–5, threshold 3 per criterion, overall threshold 10):

| Criterion | Weight | Estimated Score | Rationale |
|-----------|--------|----------------|-----------|
| **Excellence** | 5 | 4.5 | Strong objectives (SMART, measurable), clear methodology across 7 WPs, good beyond-state-of-the-art positioning. Minor: could strengthen novelty claims with more specific technical differentiation from existing projects (e.g., ELSA, TAILOR). |
| **Impact** | 5 | 4.5 | Two concrete pilots across 2 Member States, open-source toolkits on AI-on-Demand platform, standards contribution, policy briefs. Strong exploitation plan. Minor: could quantify wider socio-economic impact more precisely. |
| **Implementation** | 5 | 4.5–5.0 | Excellent work plan with 33 deliverables, 22 milestones, detailed task dependencies, PM allocations reconciled with budget. Budget fully justified with itemised costs. Strong consortium with complementary expertise. |

### 3 Strongest Areas

1. **Work plan completeness** — Detailed task descriptions with leads, contributors, durations, and dependencies across all 7 WPs. 33 deliverables and 22 milestones provide comprehensive monitoring framework.
2. **Budget-PM reconciliation** — Personnel costs fully reconciled between work-packages.md and budget-calculation.md at the partner × WP level. All arithmetic verified.
3. **Consortium complementarity** — Five partners spanning 4 EU countries with distinct, non-overlapping expertise (XAI, privacy, cybersecurity, ethics, digital government). Each partner leads the WP matching their core competence.

### 3 Areas for Improvement

1. **Specific citations and evidence** — The outline references state-of-the-art broadly but would benefit from numbered citations to specific papers, projects, and datasets to demonstrate deep domain awareness.
2. **Differentiation from related EU projects** — Explicitly positioning TRUSTEDAI relative to completed/ongoing Horizon projects (ELSA, TAILOR, CERTAI, etc.) would strengthen the excellence criterion.
3. **Quantified socio-economic impact** — While the impact section is strong qualitatively, adding quantified metrics (e.g., "estimated reduction in unfounded benefit denials by X%", "projected cost savings for healthcare cybersecurity of €Y per hospital annually") would strengthen the impact score.

---

## Quality Checklist

- [x] Every document reviewed against every other document
- [x] All numbers cross-checked (budget, PM, duration, partner count)
- [x] Title, acronym, and call reference consistent across all 6 documents
- [x] Objectives consistent between info page, outline, and work packages
- [x] Partner names and roles consistent across all documents
- [x] PM allocation reconciled between work-packages and budget
- [x] Deliverable numbering sequential with no gaps or duplicates
- [x] Timeline dependencies verified — no deliverable before WP start
- [x] All Horizon Europe eligibility criteria checked
- [x] Budget within allowed limits
- [x] Subcontracting within 30% limit
- [x] Action items are specific and actionable
- [x] Priority ranking reflects actual impact on evaluation score
