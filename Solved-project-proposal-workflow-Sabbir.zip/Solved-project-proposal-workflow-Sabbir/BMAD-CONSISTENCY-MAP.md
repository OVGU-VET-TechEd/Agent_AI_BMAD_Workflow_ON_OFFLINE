# BMAD Consistency Map — Project Proposal Workflow System

> How the BMAD Method (Breakthrough Method for Agile AI-Driven Development) is applied
> to generate a complete EU Horizon Europe funding proposal through 6 specialised AI agents

---

## 1. Executive Summary

This document maps every file in the `project-proposal-workflow` repository to the
five BMAD components (**Agents**, **Templates/Artifacts**, **Tasks**, **Data**, **Workflows**)
and traces the generation pipeline from raw funding-call input through to final quality-reviewed output.
The system adapts Brian Madison's BMAD Method — originally designed for software engineering —
into a structured proposal-writing factory where AI agents replace traditional development
roles (analyst, architect, developer, QA) with proposal-specific equivalents (overseer,
outline writer, budget specialist, quality reviewer).

**Repository:** `project-proposal-workflow/`
**Current Project:** TRUSTEDAI — Horizon Europe HORIZON-CL4-2025-DIGITAL-01-03


---

## 2. BMAD Method — Four-Phase Mapping

The BMAD Method organises AI-supported development in four phases. The proposal system
implements all four, mapped to a 6-agent sequential pipeline:

### Phase 1: Analysis — Gathering and Understanding Requirements

| BMAD Concept | Proposal System Implementation |
|--------------|-------------------------------|
| **Purpose** | Dissect the funding call, extract constraints, identify strategic opportunities |
| **Agent** | Agent 1 — Overseer Agent (`/overseer`) |
| **Task file** | `tasks/agent-1-overseer.md` |
| **Input** | `call/Call-README.md` — the raw funding call document |
| **Outputs** | `docs/overseer-analysis.md` — full strategic analysis (7 sections) |
| | `docs/project-strategy.md` — concise 1-page framework for all subsequent agents |
| **What happens** | The Overseer reads the call document, extracts budget ceilings, eligible partner types, duration limits, evaluation criteria, and mandatory sections. It then designs the project concept (title, acronym, SMART objectives), recommends a consortium of named partners with assigned roles, architects 7 work packages with PM estimates, and flags risks with H/M/L ratings and mitigations. |
| **BMAD parallel** | Like a Product Analyst + Business Analyst who reads the RFP and produces a requirements specification before any design begins |

**Key principle demonstrated:** No downstream agent writes a single word until the Analysis phase has produced a versioned specification (`project-strategy.md`) that locks the project's identity — name, partners, objectives, WP structure, and budget envelope. This mirrors BMAD's "specs before code" rule.

---

### Phase 2: Planning — Define Structure and Process

| BMAD Concept | Proposal System Implementation |
|--------------|-------------------------------|
| **Purpose** | Distill the analysis into a structured, constrained plan that subsequent agents follow |
| **Agents** | Agent 2 — Info Page Agent (`/info-page`) + Agent 3 — Outline Agent (`/outline`) |
| **Task files** | `tasks/agent-2-info-page.md`, `tasks/agent-3-outline.md` |
| **Inputs** | `docs/overseer-analysis.md`, `docs/project-strategy.md`, templates, skeletons |
| **Outputs** | `docs/project-info-page.md` — 1-page A4 summary (≤600 words, SMART objectives) |
| | `docs/project-outline.md` — full proposal narrative (15–25 pages, 9 sections) |
| **What happens** | The Info Page agent compresses the project concept into a constrained 1-page format — forcing clarity and prioritisation. The Outline agent then expands this into a full proposal narrative covering context, methodology, impact, consortium, work plan overview, budget overview, risk management, and ethics. |
| **BMAD parallel** | Like a Product Manager writing the PRD (Info Page) and an Architect writing the system design document (Outline) — planning the full scope before implementation begins |

**Key principle demonstrated:** The planning phase produces two documents at different granularity levels (summary → full narrative). Each is structurally locked by its YAML template, ensuring consistent section ordering across any project that uses the system.

---

### Phase 3: Solution Development — Developing Concepts into Concrete Detail

| BMAD Concept | Proposal System Implementation |
|--------------|-------------------------------|
| **Purpose** | Transform the planned outline into implementable, detailed work packages and a fully calculated budget |
| **Agents** | Agent 4 — Work Package Agent (`/work-packages`) + Agent 5 — Budget Agent (`/budget`) |
| **Task files** | `tasks/agent-4-work-packages.md`, `tasks/agent-5-budget.md` |
| **Inputs** | All previous docs + templates + skeletons + call document + financial parameters |
| **Outputs** | `docs/work-packages.md` — detailed work plan (7 WPs, 33 deliverables, 22 milestones) |
| | `docs/budget-calculation.md` — complete financial calculation (per-partner, per-WP) |
| **What happens** | The WP agent decomposes each work package into 4–8 tasks with leads, contributors, dependencies, and delivery months. It produces typed deliverables (R, DATA, SW, TOOL, WEB, G, CERT) and milestones with verification means. The Budget agent then costs every PM allocation using standard hourly rates (1 PM = 140 hours), adds travel, equipment, other direct costs, and 25% flat-rate overhead, producing the full EUR 4,000,000 budget with line-by-line justification. |
| **BMAD parallel** | Like a Developer writing the implementation (Work Packages = feature specs) and an Architect costing the infrastructure (Budget = resource allocation) |

**Key principle demonstrated:** Solution development is data-driven. The WP agent's PM allocation table (330 PM across 5 partners) directly feeds the Budget agent's personnel cost calculations. No numbers are invented — they flow from upstream analysis through planning into implementation.

---

### Phase 4: Implementation — Creating Concrete Results (Quality Gate)

| BMAD Concept | Proposal System Implementation |
|--------------|-------------------------------|
| **Purpose** | Validate the entire artifact set for internal consistency, call compliance, and competitive quality |
| **Agent** | Agent 6 — Quality Review Agent (`/review`) |
| **Task file** | `tasks/agent-6-review.md` |
| **Inputs** | All 6 output documents + original call document (7 files total) |
| **Output** | `docs/quality-review.md` — consistency check, compliance audit, scoring prediction |
| **What happens** | The QA agent cross-checks every data point across all documents: same acronym, same 5 SMART objectives (O1–O5), same 5 partners, same 7 WPs, same 330 PM total, same EUR 4,000,000 budget. It verifies call compliance (eligibility, budget ceilings, mandatory sections), rates each document's quality, identifies gaps, and predicts the evaluation score. |
| **BMAD parallel** | Like a QA Engineer running the test suite — the "implementation" here is the verified, submission-ready proposal package |

**Key principle demonstrated:** The final phase doesn't create new content — it validates everything produced in Phases 1–3. This separation of creation from verification is a core BMAD principle: the agent that writes the budget never reviews the budget.

---

## 3. The Five BMAD Components — Repository Mapping

### 3.1 🤖 Agents — Specialised AI Instances with Defined Roles

The system implements 6 agents, each with a clearly scoped role, specific inputs, and a single output target:

| # | Agent | Role | BMAD Equivalent | Activation | Output File |
|---|-------|------|-----------------|------------|-------------|
| 1 | Overseer | Strategic analyst — reads the call, designs the project | Analyst | `/overseer` | `overseer-analysis.md` + `project-strategy.md` |
| 2 | Info Page | Compression specialist — distills concept to 1 page | Product Manager | `/info-page` | `project-info-page.md` |
| 3 | Outline | Narrative writer — expands concept into full proposal | Architect | `/outline` | `project-outline.md` |
| 4 | Work Packages | Implementation planner — decomposes into executable tasks | Developer | `/work-packages` | `work-packages.md` |
| 5 | Budget | Financial specialist — costs every PM, trip, and item | Developer (Resources) | `/budget` | `budget-calculation.md` |
| 6 | Quality Review | Consistency auditor — validates the complete package | QA Engineer | `/review` | `quality-review.md` |

**Agent execution model:**
- Agents run **sequentially** — each reads the outputs of all predecessors
- Agents are **stateless** — they read files, not memories
- Agents are **replaceable** — swap the task file to change behaviour without touching the runner
- Agents can be **re-run** — edit a document, then re-run from that agent onwards

**Agent definition files (instructions):**

| File | Lines | Defines |
|------|-------|---------|
| `tasks/agent-1-overseer.md` | 101 | 7-step analysis process, consortium design rules, WP architecture guidance |
| `tasks/agent-2-info-page.md` | 90 | 9-section structure, SMART criteria, word limits per section |
| `tasks/agent-3-outline.md` | 98 | 9-section narrative structure, page targets per section |
| `tasks/agent-4-work-packages.md` | 97 | Per-WP structure, task format, deliverable typing, consistency checks |
| `tasks/agent-5-budget.md` | 120 | Rate tables, calculation formulas, cost category rules, justification guidance |
| `tasks/agent-6-review.md` | 92 | 5 review areas, scoring prediction methodology, output format |

---

### 3.2 🧩 Templates/Artifacts — Predefined Structures for Documents

Templates enforce structural consistency. Every output document is shaped by a YAML template that defines sections, constraints, and field requirements:

| Template File | Controls | Key Constraints |
|---------------|----------|-----------------|
| `templates/project-info-page-template.yaml` | Agent 2 output | ≤600 words, 1 page, SMART objectives, word limits per section |
| `templates/project-outline-template.yaml` | Agent 3 output | 15–25 pages, 9 sections with page ranges, subsection definitions |
| `templates/work-packages-template.yaml` | Agent 4 output | 10–20 pages, per-WP structure, deliverable types, dissemination levels |
| `templates/budget-calculation-template.yaml` | Agent 5 output | PM constants, rate tables, calculation formulas, cost category rules |

**Skeletons** (quality reference examples) complement templates by showing what a well-executed output looks like:

| Skeleton File | Shows | Source Project |
|---------------|-------|----------------|
| `skeletons/example-project-info-page.md` | Complete info page example | EcoVET-AI (Erasmus+ VET) |
| `skeletons/example-work-package.md` | Single WP fully detailed | EcoVET-AI WP2 |
| `skeletons/example-budget-excerpt.md` | Partner budget breakdown | EcoVET-AI / UPM budget |

**Template → Artifact flow:**

```
Template (YAML schema)  ──→  Agent reads template  ──→  Agent produces artifact (Markdown)
                                    ↑
                              Skeleton (example)
                              gives quality reference
```

---

### 3.3 📋 Tasks — Defined Units of Work Performed by Agents

Each agent's task is fully specified in its task file (`tasks/agent-N-*.md`). A task definition includes:

| Component | Purpose | Example (Agent 4) |
|-----------|---------|--------------------|
| **Agent Role** | Identity and expertise scope | "Work Package Agent — project management expert" |
| **Activation** | Trigger command | `@proposal-agent /work-packages` |
| **Inputs** | Files the agent must read | `project-outline.md`, `project-info-page.md`, `overseer-analysis.md`, `project-strategy.md`, template, skeleton |
| **Output** | File the agent must produce | `docs/work-packages.md` |
| **Step-by-step Instructions** | Ordered procedure | Overview tables → Per-WP blocks → Consistency checks |
| **Quality Criteria** | Self-validation rules | "Total PM across all partners matches budget assumptions" |

**Input chain — how tasks feed each other:**

```
call/Call-README.md
    │
    ▼
Agent 1 (Overseer) ─── reads: call/
    │                   writes: overseer-analysis.md + project-strategy.md
    ▼
Agent 2 (Info Page) ── reads: overseer-analysis + project-strategy + template + skeleton
    │                   writes: project-info-page.md
    ▼
Agent 3 (Outline) ──── reads: info-page + overseer-analysis + project-strategy + template + call/
    │                   writes: project-outline.md
    ▼
Agent 4 (Work Pkgs) ── reads: outline + info-page + overseer-analysis + project-strategy + template + skeleton
    │                   writes: work-packages.md
    ▼
Agent 5 (Budget) ───── reads: work-packages + outline + info-page + project-strategy + template + skeleton + call/
    │                   writes: budget-calculation.md
    ▼
Agent 6 (Review) ───── reads: ALL 6 docs + call/
                        writes: quality-review.md
```

Each downstream agent reads **all** upstream outputs, ensuring full context propagation without lossy handoffs.

---

### 3.4 📚 Data — Structured Information as Reference and Knowledge Base

The system's data layer consists of two categories:

**Input data (user-provided):**

| Data | Location | Purpose |
|------|----------|---------|
| Funding call document | `call/Call-README.md` | The raw requirements — budget limits, eligibility, evaluation criteria |
| User context | Provided at runtime | Programme-specific parameters, staff rates, partner preferences |

**Generated data (agent outputs — the `docs/` folder):**

| File | Agent | Size | Key Data Points |
|------|-------|------|-----------------|
| `docs/overseer-analysis.md` | 1 | ~15 KB | 7 sections: call requirements, strategic fit, project concept, consortium (5 partners), WP architecture (7 WPs), risks (7 risks), handoff brief |
| `docs/project-strategy.md` | 1 | ~5 KB | Locked parameters: title, acronym, 5 SMART objectives (O1–O5), 5 partners with roles, 7 WPs with PM estimates, budget guidance table |
| `docs/project-info-page.md` | 2 | ~4 KB | ≤600-word summary: description, problem, objectives, outputs, outcomes, partnership, budget |
| `docs/project-outline.md` | 3 | ~20 KB | 9-section full narrative: context, objectives/methodology, impact, consortium, work plan, budget overview, risk register, ethics |
| `docs/work-packages.md` | 4 | ~50 KB | 7 WPs fully detailed: 330 PM, 33 deliverables, 22 milestones, per-partner PM allocation table |
| `docs/budget-calculation.md` | 5 | ~30 KB | EUR 4,000,000 budget: per-partner personnel by WP, travel, equipment, other direct, 25% overhead, justification narrative |
| `docs/quality-review.md` | 6 | ~8 KB | PASS assessment, consistency matrix, compliance checklist, quality scores, 8 action items, scoring prediction 13.5–14.5/15 |

**Cross-document data consistency (TRUSTEDAI project):**

| Data Point | Value | Consistent Across |
|------------|-------|-------------------|
| Acronym | TRUSTEDAI | All 7 documents |
| Partners | 5 (TUM, KU Leuven, CyberEthics Lab, Fraunhofer AISEC, TalTech) | All 7 documents |
| Countries | 4 (DE, BE, IT, EE) | All 7 documents |
| WPs | 7 (WP1–WP7) | All 7 documents |
| Total PM | 330 | strategy, outline, work-packages, budget |
| Budget | EUR 4,000,000 | All 7 documents |
| Duration | 36 months | All 7 documents |
| Objectives | O1–O5 (SMART) | strategy, info-page, outline, work-packages |
| Deliverables | 33 | work-packages, quality-review |
| Milestones | 22 | work-packages, quality-review |

---

### 3.5 🛤️ Workflows — Established Processes that Control Collaboration

The system offers three workflow execution modes:

**Mode 1: Manual (Claude / ChatGPT)**

```
User ──→ Paste SESSION_INIT_PROMPT.md ──→ AI confirms ready
     ──→ Upload call/ document
     ──→ Run: /overseer → /info-page → /outline → /work-packages → /budget → /review
     ──→ Copy outputs to docs/
```

- Guided by: `SESSION_INIT_PROMPT.md`, `USAGE_GUIDE.md`, `AGENT_COMMANDS_GUIDE.md`
- User controls pacing — can review and edit between agents
- Supports iterative re-runs (edit info-page → re-run from /outline onwards)

**Mode 2: Automated — Task-File Runner (`run_proposal_agents.py`)**

```
python run_proposal_agents.py         # interactive (pauses between agents)
python run_proposal_agents.py -y      # automatic (runs all 6 sequentially)
python run_proposal_agents.py --agent 3   # run a single agent
python run_proposal_agents.py --from 4    # resume from agent 4
```

- Loads agent instructions from `tasks/` files at runtime
- Loads templates and skeletons as additional context
- Sends structured prompts to local **Ollama** (mistral model)
- Configuration: `MAX_CONTEXT_CHARS = 8000`, `NUM_CTX = 32768`, `REQUEST_TIMEOUT = 600`

**Mode 3: Automated — Self-Contained Runner (`mega_proposal_runner.py`)**

```
python mega_proposal_runner.py        # same CLI options as above
```

- All 6 agent instruction sets embedded inline (no external task file dependency)
- Same Ollama interface, same outputs to `docs/`
- Configuration: `MAX_CONTEXT_CHARS = 8000` (matched to task-file runner)

**Workflow control files:**

| File | Role in Workflow |
|------|------------------|
| `SESSION_INIT_PROMPT.md` | Initialises the AI session with system prompt, commands, financial defaults, output format rules |
| `USAGE_GUIDE.md` | Step-by-step instructions for both manual and automated modes |
| `AGENT_COMMANDS_GUIDE.md` | Full command reference — inputs, outputs, sections for each agent |
| `run_proposal_agents.py` | Python runner: loads tasks/ files, sends to Ollama, writes docs/ |
| `mega_proposal_runner.py` | Python runner: self-contained, embedded instructions, same output |

---

## 4. BMAD Teaching Agent Parallel

The `project-proposal-workflow` is explicitly modelled on the BMAD Teaching Agent System. The README declares the architectural parallel:

| BMAD Teaching Agent | Project Proposal System | Shared Principle |
|---------------------|------------------------|------------------|
| Phase 1: FOUNDATION — `/create-outline` | Stage 1: Overseer — `/overseer` | Define scope, requirements, and structure before any content |
| Phase 2: DIDACTICS — `/create-didactics` | Stage 2: Info Page — `/info-page` | Compress the concept into a constrained format that forces clarity |
| Phase 3: PLANNING — `/create-agenda` | Stage 3: Outline — `/outline` | Structure the full narrative with sections, timing, and dependencies |
| Phase 4: DEVELOPMENT — `/create-session` | Stage 4–5: Work Packages + Budget | Produce the detailed, implementable content |
| Phase 5: FINALIZATION — `/validate-lecture` | Stage 6: Quality Review — `/review` | Consistency check and validation before delivery |

**Structural equivalences:**

| Teaching Agent Component | Proposal System Equivalent | Location |
|--------------------------|---------------------------|----------|
| Agents (AI instances with roles) | 6 proposal agents with task definitions | `tasks/agent-*.md` |
| Templates/Artifacts (predefined structures) | 4 YAML templates + 3 skeleton examples | `templates/`, `skeletons/` |
| Tasks (defined work units) | Step-by-step instructions per agent | `tasks/agent-*.md` |
| Data (reference knowledge base) | Call document + generated docs | `call/`, `docs/` |
| Workflows (collaboration processes) | Sequential 6-agent pipeline + runner scripts | `SESSION_INIT_PROMPT.md`, `*.py` |

---

## 5. Generation Pipeline — End-to-End Traceability

This section traces how a single data point flows from input to final output, demonstrating the consistency chain:

### Example: Objective O1

```
ORIGIN:     call/Call-README.md
            ↓ "Trustworthy AI for public services"
ANALYSIS:   Agent 1 reads call → designs O1 in overseer-analysis.md §3 and §7 (Handoff Brief):
            "Develop explainable AI (XAI) methods that make high-stakes public-service
             decisions interpretable by non-technical stakeholders, validated through
             2 pilot deployments by M30"
            ↓
LOCK:       Agent 1 writes identical O1 into project-strategy.md (the "spec")
            ↓
PLAN:       Agent 2 copies O1 verbatim into project-info-page.md §Objectives
            Agent 3 expands O1 into project-outline.md §1 (Executive Summary) and §3 (Objectives)
            ↓
BUILD:      Agent 4 decomposes O1 into WP2 objectives, tasks T2.1–T2.5,
            deliverables D2.1–D2.5, milestones MS2.1–MS2.3
            Agent 5 costs WP2 PM allocation: 60 PM across TUM (25), KU Leuven (15),
            CyberEthics Lab (12), Fraunhofer AISEC (5), TalTech (3)
            ↓
VERIFY:     Agent 6 checks O1 appears identically in info-page, outline, and WP objectives
            → Consistency Matrix: ✅ MATCH
```

### Example: Budget Total (EUR 4,000,000)

```
ORIGIN:     call/Call-README.md → "maximum EUR 4 000 000 per project"
            ↓
ANALYSIS:   overseer-analysis.md §1 → "Budget: EUR 4,000,000"
            project-strategy.md → "Budget: EUR 4,000,000"
            ↓
PLAN:       project-info-page.md → "Total budget: EUR 4,000,000"
            project-outline.md §7 → "The total budget is EUR 4,000,000"
            ↓
BUILD:      work-packages.md → 330 PM distributed across 5 partners
            budget-calculation.md → €2,372,440 personnel + €152,000 travel +
            €176,000 equipment + €499,560 other + €800,000 overhead = €4,000,000
            ↓
VERIFY:     quality-review.md → Budget Consistency: ✅ All documents show EUR 4,000,000
```

---

## 6. File-to-BMAD Component Matrix

Every file in the repository mapped to its BMAD component and phase:

| File | BMAD Component | BMAD Phase | Role |
|------|---------------|------------|------|
| `call/Call-README.md` | 📚 Data | Input | Raw funding call (requirements source) |
| `tasks/agent-1-overseer.md` | 📋 Task | Analysis | Agent 1 instructions |
| `tasks/agent-2-info-page.md` | 📋 Task | Planning | Agent 2 instructions |
| `tasks/agent-3-outline.md` | 📋 Task | Planning | Agent 3 instructions |
| `tasks/agent-4-work-packages.md` | 📋 Task | Solution Dev | Agent 4 instructions |
| `tasks/agent-5-budget.md` | 📋 Task | Solution Dev | Agent 5 instructions |
| `tasks/agent-6-review.md` | 📋 Task | Implementation | Agent 6 instructions |
| `templates/project-info-page-template.yaml` | 🧩 Template | Planning | Structural schema for info page |
| `templates/project-outline-template.yaml` | 🧩 Template | Planning | Structural schema for outline |
| `templates/work-packages-template.yaml` | 🧩 Template | Solution Dev | Structural schema for WPs |
| `templates/budget-calculation-template.yaml` | 🧩 Template | Solution Dev | Structural schema for budget |
| `skeletons/example-project-info-page.md` | 🧩 Artifact | Planning | Quality reference (EcoVET-AI) |
| `skeletons/example-work-package.md` | 🧩 Artifact | Solution Dev | Quality reference (EcoVET-AI) |
| `skeletons/example-budget-excerpt.md` | 🧩 Artifact | Solution Dev | Quality reference (EcoVET-AI) |
| `docs/overseer-analysis.md` | 📚 Data (generated) | Analysis | Strategic analysis output |
| `docs/project-strategy.md` | 📚 Data (generated) | Analysis | Locked project specification |
| `docs/project-info-page.md` | 📚 Data (generated) | Planning | 1-page summary output |
| `docs/project-outline.md` | 📚 Data (generated) | Planning | Full proposal narrative output |
| `docs/work-packages.md` | 📚 Data (generated) | Solution Dev | Detailed work plan output |
| `docs/budget-calculation.md` | 📚 Data (generated) | Solution Dev | Financial calculation output |
| `docs/quality-review.md` | 📚 Data (generated) | Implementation | Validation report output |
| `SESSION_INIT_PROMPT.md` | 🛤️ Workflow | All phases | AI session initialisation |
| `USAGE_GUIDE.md` | 🛤️ Workflow | All phases | Step-by-step operator guide |
| `AGENT_COMMANDS_GUIDE.md` | 🛤️ Workflow | All phases | Command reference |
| `README.md` | 🛤️ Workflow | All phases | System documentation |
| `run_proposal_agents.py` | 🛤️ Workflow | All phases | Automated runner (task-file mode) |
| `mega_proposal_runner.py` | 🛤️ Workflow | All phases | Automated runner (self-contained) |
| `generate_sample_call.py` | 🛤️ Workflow | Input prep | Utility to generate sample call documents |

---

## 7. Consistency Verification Summary

The following consistency checks confirm alignment across the repository:

### 7.1 Agent Input Chain — Verified

Each agent's task file (`tasks/agent-N-*.md`) lists correct input files, matching the
`AGENT_COMMANDS_GUIDE.md` reference and the runner scripts' prompt construction:

| Agent | Inputs Listed in Task File | Status |
|-------|---------------------------|--------|
| 1 — Overseer | `call/` | ✅ Correct |
| 2 — Info Page | `overseer-analysis.md`, `project-strategy.md`, template, skeleton | ✅ Correct |
| 3 — Outline | `project-info-page.md`, `overseer-analysis.md`, `project-strategy.md`, template, `call/` | ✅ Correct |
| 4 — Work Packages | `project-outline.md`, `project-info-page.md`, `overseer-analysis.md`, `project-strategy.md`, template, skeleton | ✅ Correct |
| 5 — Budget | `work-packages.md`, `project-outline.md`, `project-info-page.md`, `project-strategy.md`, `call/`, template, skeleton, user rates | ✅ Correct |
| 6 — Review | All 6 docs + `call/` | ✅ Correct |

### 7.2 Template ↔ Output — Verified

Each YAML template's section definitions match the actual sections produced in the output documents:

| Template | Output Doc | Sections Match |
|----------|-----------|----------------|
| `project-info-page-template.yaml` (9 sections) | `project-info-page.md` | ✅ All sections present |
| `project-outline-template.yaml` (9 sections) | `project-outline.md` | ✅ All sections present |
| `work-packages-template.yaml` (per-WP structure) | `work-packages.md` | ✅ All WPs follow structure |
| `budget-calculation-template.yaml` (6 cost categories) | `budget-calculation.md` | ✅ All categories present |

### 7.3 Cross-Document Data — Verified

| Data Point | Overseer | Strategy | Info Page | Outline | WPs | Budget | Review |
|------------|----------|----------|-----------|---------|-----|--------|--------|
| Acronym: TRUSTEDAI | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| 5 partners (TUM, KU Leuven, CyberEthics Lab, Fraunhofer AISEC, TalTech) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| 7 WPs (WP1–WP7) | ✅ | ✅ | — | ✅ | ✅ | ✅ | ✅ |
| 330 PM total | ✅ | ✅ | — | ✅ | ✅ | ✅ | ✅ |
| EUR 4,000,000 | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ |
| 36 months | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| O1–O5 (SMART) | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ |
| Risk table (7 risks, aligned ratings) | ✅ | — | — | ✅ | ✅ | — | ✅ |
| Deliverable months | ✅ | — | — | ✅ | ✅ | — | ✅ |

### 7.4 Runner Configuration — Verified

| Parameter | `run_proposal_agents.py` | `mega_proposal_runner.py` | Match |
|-----------|-------------------------|---------------------------|-------|
| MODEL | `mistral` | `mistral` | ✅ |
| MAX_CONTEXT_CHARS | 8000 | 8000 | ✅ |
| NUM_CTX | 32768 | 32768 | ✅ |
| REQUEST_TIMEOUT | 600 | 600 | ✅ |

### 7.5 Guide ↔ Runner — Verified

| Guide Reference | Matches Runner | Status |
|----------------|----------------|--------|
| `USAGE_GUIDE.md` recommends `ollama pull mistral` | Runners use `MODEL = "mistral"` | ✅ |
| `SESSION_INIT_PROMPT.md` lists 6 commands | Runners implement 6 agents | ✅ |
| `AGENT_COMMANDS_GUIDE.md` input lists | Task file input lists | ✅ |

---

## 8. BMAD Principles Demonstrated

| BMAD Principle | How This System Implements It |
|----------------|-------------------------------|
| **Specs before code** | `project-strategy.md` locks all parameters before any downstream agent writes |
| **Specialised agent roles** | 6 agents with non-overlapping responsibilities — no agent does another's job |
| **Versioned artifacts** | Every output is a named Markdown file in `docs/` — diffable, reviewable, editable |
| **Structured templates** | 4 YAML schemas enforce consistent output structure across any project |
| **Sequential dependency chain** | Each agent reads all predecessors — no skipping, no parallel execution |
| **Quality gate** | Agent 6 exists solely to validate — it creates no new content |
| **Traceability** | Every data point can be traced from `call/` through analysis → planning → implementation → verification |
| **Reusability** | Change the call document, re-run all 6 agents — the system works for any funding programme |
| **Separation of concerns** | Tasks, templates, data, and workflows live in separate folders with distinct purposes |

---

Generated: 2026-02-22 | Repository: project-proposal-workflow | Method: BMAD (Brian Madison)
