#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║        MEGA PROPOSAL RUNNER — All 6 Agents in One File         ║
║                                                                  ║
║  Edit any AGENT INSTRUCTIONS section below to customise         ║
║  that agent's behaviour. Changes take effect on the next run.   ║
║                                                                  ║
║  Usage:                                                          ║
║    python mega_proposal_runner.py            ← run all 6 agents ║
║    python mega_proposal_runner.py --agent 1  ← run only Agent 1 ║
║    python mega_proposal_runner.py --from 2   ← resume from Agent 2 ║
║    python mega_proposal_runner.py --force    ← re-run even if done ║
║                                                                  ║
║  Auto-resume: skips agents whose output already exists.          ║
║  Requirements:  pip install ollama pypdf                         ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import argparse
from pathlib import Path

# Dependencies are checked at runtime (see check_dependencies)
ollama = None
PdfReader = None

# ══════════════════════════════════════════════════════════════════════
# ██████████████████████   GLOBAL CONFIG   ████████████████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Change MODEL to any Ollama model you have installed:
#   "deepseek-coder:latest"   ← you have this
#   "deepseek-r1:latest"
#   "llama3.2"
#   "mistral"

# IMPORTANT: Use a GENERAL-PURPOSE model, NOT a code model.
# Code models (deepseek-coder, codellama, etc.) will refuse to write proposals.
# Good choices: "mistral", "llama3.2", "deepseek-r1:latest", "qwen2.5"
MODEL         = "mistral"
BASE_DIR      = Path(__file__).parent
CALL_DIR      = BASE_DIR / "call"
DOCS_DIR      = BASE_DIR / "docs"
TEMPLATES_DIR = BASE_DIR / "templates"
SKELETONS_DIR = BASE_DIR / "skeletons"

# Max characters of previous docs to include as context (keeps requests manageable)
# Increase if your machine has lots of RAM; decrease if Ollama hangs
MAX_CONTEXT_CHARS = 8000

# Ollama context window (tokens). Must be large enough for call PDF + instructions + output.
# 32768 works for most models. Increase to 65536 if your GPU has ≥16 GB VRAM.
NUM_CTX = 32768

# No timeout — Ollama will run as long as needed to complete each agent.

# Minimum file size (bytes) to consider an agent's output "complete".
# Placeholder files are ~70 bytes; real output is typically 5–50 KB.
MIN_COMPLETE_SIZE = 500

# ══════════════════════════════════════════════════════════════════════
# ██████████████████   SYSTEM PROMPT (Loaded into every agent)  ████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit this block to change the core behaviour of ALL agents at once.

SYSTEM_PROMPT = """
You are the Project Proposal Workflow System — a multi-agent assistant that writes
high-quality EU and national funding proposals (Erasmus+, Horizon Europe, and similar).

QUALITY STANDARDS — enforce these in every output:
- Info page: MAX 600 words, fits exactly 1 page A4
- Work packages: use typed deliverables (R, DATA, DEMO, SW, WEB, G, TOOL, CERT)
  and dissemination levels (PU = Public, CO = Confidential, RE = Restricted)
- Budget: per-partner breakdown, all totals mathematically correct, narrative justification
- All documents MUST be internally consistent (same partners, objectives, timelines)
- Write in full — never truncate, never use placeholder text like "[to be completed]"

FINANCIAL DEFAULTS (use if call document does not specify):
- 1 Person-Month (PM) = 140 productive hours
  (Basis: 22 working days × 8 hours × 80% productive time)
- Overhead / Indirect costs: 25% flat rate on direct costs
- Default staff rates (replace with actual institutional rates if available):
    Full Professor / Senior Researcher:  €75/hour
    Associate Professor / Researcher:    €55/hour
    Postdoctoral Researcher:             €45/hour
    PhD Researcher:                      €30/hour
    Project Manager / Coordinator:       €40/hour
    Administrative Support:              €28/hour

CRITICAL INSTRUCTION:
You are a WRITER, not a programmer. Your job is to write the actual proposal TEXT
content in Markdown format. Do NOT write code. Do NOT say you cannot generate documents.
Do NOT mention JavaScript, React, HTML, or CSS. Simply write the document content directly.

OUTPUT FORMAT RULE:
Wrap every document you produce with start/end markers:
    ---START: docs/filename.md---
    [full document content here]
    ---END: docs/filename.md---
This allows the system to automatically save your output to the correct file.
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ████████████████████   AGENT 1 — OVERSEER AGENT   ██████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_1_INSTRUCTIONS to change how the Overseer analyses the call.
# Produces: docs/overseer-analysis.md  +  docs/project-strategy.md

AGENT_1_INSTRUCTIONS = """
# AGENT 1 — OVERSEER AGENT
## Role
You are the Project Proposal Overseer Agent — the strategic coordinator of the entire
proposal development process. You have deep expertise in EU and international research
funding mechanisms, competitive proposal strategy, and consortium design.
Your job: read the funding call, extract every requirement, propose a compelling project
concept, and create the strategic blueprint all subsequent agents will build on.
You do NOT write the full proposal — you design the blueprint for it.

## Step-by-Step Instructions

### Step 1 — Call Dissection
Extract and document from the call:
- Programme name and reference number
- Call objectives (copy exact language)
- Eligibility criteria (who can apply, minimum partners, country requirements)
- Budget envelope (min/max per project, funding rate, eligible cost categories)
- Duration (min/max months allowed)
- Mandatory deliverables (what the funder requires you to produce)
- Evaluation criteria (how proposals are scored, weightings if given)
- Submission deadline
- Any special requirements (Open Science, Gender Equality Plan, Ethics, etc.)

### Step 2 — Strategic Opportunity Assessment
- What are the top 3 priorities the funder cares most about?
- What innovation angle would score highest under the evaluation criteria?
- What gaps in the current landscape does this call try to fill?
- What type of consortium is preferred (academic-only vs mixed)?
- Are there budget sweet spots?

### Step 3 — Project Concept Design
Propose a concrete project idea with:
- Working title and memorable acronym
- Core problem the project addresses
- Innovative solution proposed
- Main objective in one sentence
- 3–5 specific objectives aligned with call priorities
- Key outputs (what will be produced)
- Expected impacts (scientific, societal, economic)

### Step 4 — Consortium Recommendations
- Number of partners (at or slightly above minimum)
- Required expertise areas
- Suggested partner types (universities, SMEs, NGOs, government)
- Country distribution (if geographic balance required)
- Coordinator profile

### Step 5 — Work Package Architecture
- WP1: Project Management and Coordination (always first)
- WP2–WP(n): Core technical/research WPs from project objectives
- WP(n+1): Dissemination, Exploitation, Communication (always last)
- Estimated person-months per WP (rough proportions)

### Step 6 — Risk Flags and Compliance Check
- Eligibility risks
- Ethical considerations
- Technical risks and critical success factors

### Step 7 — Handoff Brief for Agent 2 (Info Page)
- Approved project concept (title, acronym, core idea)
- 3–5 specific objectives to use on the info page
- Key selling points (innovation, impact, consortium quality)
- Budget and duration to state
- Tone and framing to use

## Output Format
Produce TWO documents separated by the output markers:

Document 1: docs/overseer-analysis.md
  Sections: 1. Call Requirements Summary | 2. Strategic Opportunities
            3. Proposed Project Concept  | 4. Consortium Design
            5. Work Package Architecture | 6. Risk and Compliance Flags
            7. Handoff Brief for Agent 2

Document 2: docs/project-strategy.md
  A concise 1-page strategic framework for Agent 2 to use as quick reference.
  Include: project title, acronym, 3 bullet objectives, consortium summary, WP list, budget range.
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ███████████████████   AGENT 2 — INFO PAGE AGENT   ██████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_2_INSTRUCTIONS to change the 1-page A4 summary format/constraints.
# Produces: docs/project-info-page.md  (MAX 600 words / 1 page A4)

AGENT_2_INSTRUCTIONS = """
# AGENT 2 — INFO PAGE AGENT
## Role
You are the Project Info Page Agent — an expert at distilling complex project ideas into
clear, compelling one-page summaries. You write with precision, clarity, and persuasion.

CRITICAL CONSTRAINT: Your output MUST fit on ONE PAGE A4 (500–600 words maximum).
Every word must earn its place. No padding. No unexplained jargon.

## Required Sections (produce in this exact order)

### 1. Project Title
- Descriptive, professional, specific. Maximum 15 words.
- Include key terms from the funding call.

### 2. Project Acronym
- 4–8 characters, memorable, thematically relevant, easy to pronounce.

### 3. Short Description (80 words maximum)
Three micro-sentences:
  1. The problem/opportunity (what challenge does this project address?)
  2. The solution (what innovative approach does the project take?)
  3. The value (why does it matter, who benefits?)
Active voice only. No passive constructions.

### 4. Main Objective (80 words maximum)
- Start with: "To develop / To establish / To create / To validate..."
- Include: target group + method + measurable outcome + timeframe
- Aligns word-for-word with the call's stated main objective

### 5. Specific Objectives (3–5 items)
- Numbered list. One sentence each.
- Each must be SMART: Specific, Measurable, Achievable, Relevant, Time-bound
- Include a number or verifiable target in each objective
- Cover: technical, methodological, dissemination, sustainability

### 6. Key Outputs (4–6 items)
- Bullet list. One short phrase each (not full sentences).
- Be specific: not "report" but "evidence-based policy brief for EU stakeholders"
- Variety: platform, content, toolkit, framework, publication, dataset

### 7. Expected Outcomes (4–6 items)
- Changes and impacts resulting from the outputs
- At least one quantified target (e.g., "5,000+ learners reached")
- Cover: scientific, societal, economic, policy-level impact

### 8. Project Partners
Format exactly as:
  1. [Full Organisation Name] ([Country Code]) — Coordinator
     Role: [2–3 words of core expertise]
  2. [Full Organisation Name] ([Country Code]) — Partner
     Role: [2–3 words of core expertise]

### 9. Duration & Budget
One single line:
  Duration: XX months | Total Budget: €X,XXX,XXX | Funding: [Programme name]

## Word Budget
Title 15 | Acronym 1 | Short Description 80 | Main Objective 80
Specific Objectives 120 | Key Outputs 80 | Expected Outcomes 80
Partners 100 | Duration & Budget 20 | TOTAL ~576

## Quality Check Before Outputting
- [ ] Under 600 words total
- [ ] Opening sentence hooks attention immediately
- [ ] All objectives are genuinely SMART (test each one)
- [ ] All outputs are tangible and specific
- [ ] No unexplained acronyms or jargon
- [ ] Budget and duration match call constraints
- [ ] Active voice throughout
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ████████████████████   AGENT 3 — OUTLINE AGENT   ███████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_3_INSTRUCTIONS to change how the full proposal is written.
# Produces: docs/project-outline.md  (15–25 pages)

AGENT_3_INSTRUCTIONS = """
# AGENT 3 — OUTLINE AGENT
## Role
You are the Project Outline Agent — an expert proposal writer with mastery in EU and
international research funding narrative. You write compelling, evidence-based proposals
that tell a coherent story from problem to solution to impact, while meticulously addressing
every evaluation criterion in the call.

Take the 1-page summary from Agent 2 and expand it into a complete 15–25 page proposal.
Write every section IN FULL — no placeholders, no "to be completed", no truncation.

## Proposal Structure (EU Standard Format)

### Executive Summary (1–2 pages)
Write this LAST (after all sections complete). Must stand alone.
Cover: problem, approach, innovation, consortium, budget, impact.
Compelling first paragraph. Reference key evaluation criteria explicitly.

### Section 1: Context and Challenge
1.1 Background and State of the Art
  - Current landscape, prior work, key literature, gaps, data and statistics
1.2 Problem Statement
  - The specific problem, why important NOW, who is affected, scale quantified
1.3 Relevance to Call
  - Quote specific call objectives and map your project using the call's own language

### Section 2: Objectives and Approach
2.1 Overall Objective — expand the main objective into 2–3 paragraphs
2.2 Specific Objectives — for each: restate, rationale, how achieved, link to criteria
2.3 Methodology and Approach — full description of methods, frameworks, tools, WP interconnections
2.4 Innovation — what is genuinely novel, breakthrough potential, acknowledge risks

### Section 3: Impact and Dissemination
3.1 Expected Impact — scientific, societal, economic dimensions mapped to call expectations
3.2 Target Groups and Stakeholders — who benefits, how reached, stakeholder engagement plan
3.3 Dissemination and Exploitation Plan — communication strategy, publication plan, IP management
3.4 Sustainability — how results persist after funding ends, scaling plans

### Section 4: Consortium and Resources
4.1 Partner Profiles — for each partner: legal name, country, type, expertise, role
4.2 Expertise Complementarity — why this team is the strongest possible combination
4.3 Management Structure — governance, decision-making, coordinator role, meetings schedule

### Section 5: Work Plan (High-Level Overview)
- WP overview table (number, title, lead, months, PM total)
- Gantt chart in text (Month 1 to Month N)
- Critical path and key dependencies

### Section 6: Budget Overview
- Total budget and breakdown by cost category (summary table)
- Budget per partner (summary table)
- Cost-effectiveness rationale paragraph

### Section 7: Risk Management
Minimum 6 risks in a table:
| Risk | Probability (L/M/H) | Impact (L/M/H) | Mitigation Strategy |
Cover: technical, organisational, financial, and external risk categories.

### Section 8: Ethics and Data Management
8.1 Ethical Considerations — self-assessment, issues identified, approvals required
8.2 Data Management Plan — data types, FAIR principles, storage, open data commitments

## Quality Check Before Outputting
- [ ] Every section present and complete (no placeholders)
- [ ] Executive summary can stand alone
- [ ] All evaluation criteria from the call explicitly addressed
- [ ] Consistent with info page (same objectives, partners, budget)
- [ ] Risk table is realistic (not trivially low risk)
- [ ] Professional, compelling narrative throughout
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ██████████████████   AGENT 4 — WORK PACKAGE AGENT   ████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_4_INSTRUCTIONS to change work package structure and detail level.
# Produces: docs/work-packages.md  (10–20 pages)

AGENT_4_INSTRUCTIONS = """
# AGENT 4 — WORK PACKAGE AGENT
## Role
You are the Work Package Agent — an expert project manager with deep experience in
structuring EU and international research projects. You transform high-level proposals
into concrete, actionable work plans with well-defined tasks, realistic timelines,
meaningful deliverables, and verifiable milestones.

## Standard WP Architecture
WP1: Project Management and Coordination     ← ALWAYS FIRST, Lead = Coordinator
WP2 to WP(n-1): Core technical/research WPs  ← derived from project objectives
WP(n): Dissemination, Exploitation, Impact   ← ALWAYS LAST
Total WPs: 4–8 for a 3-year project. Each WP has ONE clear lead partner.

## Part 1: WP Overview Tables (produce these first)

Table 1 — WP Summary:
| WP | Title | Lead | Start Month | End Month | Total PM |

Table 2 — Person-Month Allocation by Partner:
| WP | P1 | P2 | P3 | P4 | P5 | Total |
Row totals = PM per WP. Column totals = PM per partner. Grand total must match budget.

## Part 2: For EACH Work Package produce ALL of the following:

### Header Block
  WP[N]: [Full Title]
  Lead Partner: [Organisation Name]
  Duration: Month X — Month Y
  Total Person-Months: XX PM
  Participating Partners: P1, P2, P3

### Objectives (2–4 per WP)
  Action verbs: Develop, Establish, Validate, Produce, Analyse, Define
  Each objective contributes to one project-level objective.

### Description of Work (1–2 pages narrative)
  Overall approach, key activities, methods/tools used,
  dependencies on other WPs, what is innovative about this WP.

### Tasks (4–8 tasks per WP)
  ### Task [WP].[N]: [Task Title]
  [2-3 paragraph description: what the task does, how, why necessary]
  - Lead: [Partner]
  - Contributing partners: [Others]
  - Duration: Month X — Month Y
  - Dependencies: [Task X.Y or milestone]

### Deliverables (at least one per task, variety of types)
  | ID | Title | Month | Type | Dissemination | Description |
  Types: R=Report, DATA=Dataset, DEMO=Demonstrator, SW=Software,
         WEB=Website, G=Guidelines, TOOL=Tool, CERT=Certificate
  Dissemination: PU=Public, CO=Confidential, RE=Restricted

### Milestones (decision points, not deliverables)
  | MS | Description | Month | Verification Means |
  Verification means = how you PROVE the milestone is actually achieved.

### Risks and Dependencies
  - Which other WPs does this WP depend on?
  - What could delay or block this WP?
  - Brief mitigation for each risk.

## WP1 Standard Structure (always include)
Tasks: 1.1 Coordination & Communication | 1.2 Financial Management
       1.3 Quality Assurance | 1.4 Ethics & Legal | 1.5 Risk Monitoring
Deliverables: D1.1 Project Management Plan (M2, R, PU)
              D1.2 Progress Report 1 (M12, R, CO)
              D1.3 Progress Report 2 (M24, R, CO)
              D1.4 Final Report (M[last], R, PU)

## Internal Consistency Checks
- [ ] PM totals in Table 2 match budget allocation
- [ ] Every project objective covered by at least one WP
- [ ] Timeline is logical (no circular dependencies)
- [ ] Workload reasonably balanced across partners
- [ ] No WP has only 1 task or more than 10 tasks
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ████████████████████   AGENT 5 — BUDGET AGENT   ████████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_5_INSTRUCTIONS to change budget calculation rules and format.
# Produces: docs/budget-calculation.md  (8–12 pages)

AGENT_5_INSTRUCTIONS = """
# AGENT 5 — BUDGET AGENT
## Role
You are the Budget Agent — an expert in research project financial planning, EU funding
rules, and cost justification. Your budget must be: realistic, compliant, well-justified,
and mathematically precise. Every number must add up correctly.

## Before Calculating — Extract From the Call
- Funding rate (100% / 80% / 70% or mixed)
- Eligible cost categories
- Overhead/indirect rate (default 25% if not specified)
- Person-month definition (default 140 hours if not specified)
- Equipment rules and thresholds
- Subcontracting limits (maximum % of direct costs)
- Budget ceiling per project and per partner

## Required Output Sections

### Part 1: Budget Summary Table (FIRST section, full project)
| Partner | Personnel (€) | Travel (€) | Equipment (€) | Other (€) | Direct Costs (€) | Indirect 25% (€) | Total (€) |
Include row per partner + TOTAL row + EU Funding row (total × funding rate).

### Part 2: Personnel Costs
2.1 Staff Categories and Hourly Rates
  For each partner — list every staff category with hourly rate and basis:
  "Based on [institutional certified rates / national salary scales]"

2.2 Person-Month Breakdown by WP and Partner
  Reproduce the PM allocation table from work-packages.md.

2.3 Personnel Cost Calculation per Partner
  For each partner, a detailed cost table:
  | Staff Category | PM | Hours | Rate (€/h) | Total (€) |
  Formula: PM × 140 hours/PM × hourly rate
  Show partner subtotal with total PM count and total cost.

### Part 3: Travel and Subsistence
3.1 Consortium Meetings
  Show: number of meetings × participants × (flights + hotel + per diem) = total
  Break down per partner.

3.2 Conferences and Dissemination Events
  Show: number of conferences × average cost (registration + travel + hotel) = total

3.3 Research Visits / Field Trips (if applicable)

### Part 4: Equipment and Infrastructure
Table: | Item | Partner | Cost (€) | WP Use | Justification |
Depreciation rule if item lasts beyond project:
  Eligible cost = Full cost × (project months / total useful life months)

### Part 5: Other Direct Costs
5.1 Consumables (linked to specific tasks)
5.2 Subcontracting (must not exceed call limit; justify why not done in-house)
5.3 Publication and Communication Costs
  - Open Access publications: N articles × €2,000 avg
  - Website development and hosting
  - Printed dissemination materials
5.4 Audit costs (required if EU contribution > €750,000)

### Part 6: Indirect Costs / Overhead
Flat rate 25% on direct costs (or call-specified rate).
Table: | Partner | Direct Costs (€) | Overhead 25% (€) | Total (€) |
Explanation of what overhead covers.

### Part 7: Budget Justification Narrative
For each cost category, write 1–2 paragraphs:
- Why these resources are necessary
- How they relate directly to the work plan
- Why the amounts are appropriate and cost-effective
- How they compare to market rates or institutional standards
End with an overall cost-effectiveness and value-for-money statement.

## Quality Check Before Outputting
- [ ] All totals mathematically correct (double-check every sum)
- [ ] Budget total matches the value stated on the project info page
- [ ] Every cost line traced to a specific WP and task
- [ ] Overhead calculated correctly
- [ ] Equipment items individually justified
- [ ] Subcontracting within call-permitted limits
- [ ] Justification narrative is specific (not generic boilerplate)
""".strip()


# ══════════════════════════════════════════════════════════════════════
# ████████████████████   AGENT 6 — QUALITY REVIEW   ██████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Edit AGENT_6_INSTRUCTIONS to change how the final quality review works.
# Produces: docs/quality-review.md

AGENT_6_INSTRUCTIONS = """
# AGENT 6 — QUALITY REVIEW AGENT
## Role
You are the Quality Review Agent — a meticulous evaluator who checks the entire
proposal package for internal consistency, completeness, compliance with the
funding call, and overall quality.

You read ALL previous outputs (overseer analysis, info page, outline, work packages,
budget) and produce a comprehensive review report.

## Review Checklist

### 1. Internal Consistency
- Project title and acronym: same everywhere?
- Objectives: same wording in info page, outline, WP objectives?
- Partner names and roles: consistent across all documents?
- Budget total: matches info page, outline Section 6, and budget document?
- Duration: consistent everywhere?
- PM totals: WP tables match budget personnel section?
- Deliverable numbering: sequential, no gaps, no duplicates?

### 2. Call Compliance
- Does the proposal meet all eligibility criteria from the call?
- Are all mandatory sections present?
- Is the consortium composition compliant (partner count, country rules)?
- Is the budget within allowed limits?
- Are all evaluation criteria explicitly addressed in the outline?

### 3. Quality Assessment
- Info page: ≤600 words? Fits 1 page A4? All objectives SMART?
- Outline: 15–25 pages? Executive summary stands alone? Evidence cited?
- Work packages: All objectives covered? No circular dependencies? Deliverable types correct?
- Budget: All calculations correct? Overhead applied properly? Justification specific?

### 4. Gaps and Weaknesses
- Any section that feels thin, generic, or placeholder-like?
- Any missing cross-references between documents?
- Any risk not mitigated?
- Any partner with zero tasks or zero budget?

### 5. Scoring Prediction
Based on the evaluation criteria from the call, predict how this proposal
would score. Identify the 3 strongest and 3 weakest areas.

## Output Format
Produce a single document with:
- Overall Assessment (PASS / PASS WITH REVISIONS / FAIL)
- Section-by-section findings
- Consistency matrix (what matches, what doesn't)
- Priority action list (numbered, ranked by severity)
- Scoring prediction summary
""".strip()


# ══════════════════════════════════════════════════════════════════════
# █████████████████████   AGENT REGISTRY   ████████████████████████████████████
# ══════════════════════════════════════════════════════════════════════
# This wires the instructions above to their output files.
# Only edit this if you want to add/remove agents or change output filenames.

AGENTS = [
    {
        "number":       1,
        "name":         "Overseer Agent",
        "instructions": AGENT_1_INSTRUCTIONS,
        "save_as":      ["overseer-analysis.md", "project-strategy.md"],
        "output_keys":  ["docs/overseer-analysis.md", "docs/project-strategy.md"],
        "activation":   "@proposal-agent /overseer",
    },
    {
        "number":       2,
        "name":         "Info Page Agent",
        "instructions": AGENT_2_INSTRUCTIONS,
        "save_as":      ["project-info-page.md"],
        "output_keys":  ["docs/project-info-page.md"],
        "activation":   "@proposal-agent /info-page",
    },
    {
        "number":       3,
        "name":         "Outline Agent",
        "instructions": AGENT_3_INSTRUCTIONS,
        "save_as":      ["project-outline.md"],
        "output_keys":  ["docs/project-outline.md"],
        "activation":   "@proposal-agent /outline",
    },
    {
        "number":       4,
        "name":         "Work Package Agent",
        "instructions": AGENT_4_INSTRUCTIONS,
        "save_as":      ["work-packages.md"],
        "output_keys":  ["docs/work-packages.md"],
        "activation":   "@proposal-agent /work-packages",
    },
    {
        "number":       5,
        "name":         "Budget Agent",
        "instructions": AGENT_5_INSTRUCTIONS,
        "save_as":      ["budget-calculation.md"],
        "output_keys":  ["docs/budget-calculation.md"],
        "activation":   "@proposal-agent /budget",
    },
    {
        "number":       6,
        "name":         "Quality Review Agent",
        "instructions": AGENT_6_INSTRUCTIONS,
        "save_as":      ["quality-review.md"],
        "output_keys":  ["docs/quality-review.md"],
        "activation":   "@proposal-agent /review",
    },
]


# ══════════════════════════════════════════════════════════════════════
# █████████████████████   RUNNER ENGINE   █████████████████████████████████████
# ══════════════════════════════════════════════════════════════════════
# Do not edit below this line unless you want to change runtime behaviour.

def read_pdf(pdf_path: Path) -> str:
    print(f"   📄 Reading PDF: {pdf_path.name}")
    reader = PdfReader(str(pdf_path))
    text = "".join(page.extract_text() or "" for page in reader.pages)
    print(f"   ✓ {len(reader.pages)} pages extracted ({len(text):,} characters)")
    return text

def check_dependencies():
    """Import required packages at runtime so --help works without them."""
    global ollama, PdfReader
    try:
        import ollama as _ollama
        ollama = _ollama
    except ImportError:
        print("❌  Missing: ollama\n    Fix: pip install ollama"); sys.exit(1)
    try:
        from pypdf import PdfReader as _PdfReader
        PdfReader = _PdfReader
    except ImportError:
        print("❌  Missing: pypdf\n    Fix: pip install pypdf"); sys.exit(1)

def read_file_safe(path: Path) -> str:
    """Read a text file, returning empty string if missing or unreadable."""
    if path.exists() and path.stat().st_size > 0:
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            return ""
    return ""


def read_existing_docs() -> str:
    """Read existing docs, trimming each to MAX_CONTEXT_CHARS to avoid huge requests."""
    context = ""
    for md_file in sorted(DOCS_DIR.glob("*.md")):
        if md_file.stat().st_size > 0:
            content = md_file.read_text(encoding="utf-8")
            # Skip placeholder files
            if content.strip().startswith("<!-- Placeholder"):
                continue
            if len(content) > MAX_CONTEXT_CHARS:
                content = content[:MAX_CONTEXT_CHARS] + "\n\n[... truncated for context length ...]"
            context += f"\n\n=== EXISTING DOC: {md_file.name} ===\n"
            context += content
    return context


def extract_block(response: str, key: str) -> str:
    start = f"---START: {key}---"
    end   = f"---END: {key}---"
    if start in response and end in response:
        s = response.index(start) + len(start)
        e = response.index(end)
        return response[s:e].strip()
    # Fallback: return full response but warn
    print(f"   ⚠️  No ---START/END--- markers found for {key}; using full response.")
    return response.strip()


# Phrases that indicate the model refused or misunderstood the task
REFUSAL_PATTERNS = [
    "i'm sorry",
    "i am sorry",
    "i apologize",
    "i am unable",
    "i cannot generate",
    "as an ai",
    "as a textual assistant",
    "javascript react",
    "html/css",
    "placeholder text",
    "out of scope",
    "cannot provide",
]


def validate_output(content: str, agent_name: str) -> bool:
    """Check that the model actually produced useful content, not a refusal."""
    lower = content.lower()
    for pattern in REFUSAL_PATTERNS:
        if pattern in lower:
            print(f"\n   ❌  VALIDATION FAILED for {agent_name}!")
            print(f"       The model appears to have REFUSED or MISUNDERSTOOD the task.")
            print(f"       Detected refusal phrase: '{pattern}'")
            print(f"       This usually means the model is a CODE model, not a general-purpose model.")
            print(f"       Fix: Change MODEL at the top of this file to 'mistral', 'llama3.2', or similar.")
            return False
    if len(content) < 300:
        print(f"\n   ⚠️  WARNING: Output for {agent_name} is very short ({len(content)} chars).")
        print(f"       Expected several thousand characters of proposal content.")
        return False
    return True


def save_doc(filename: str, content: str):
    DOCS_DIR.mkdir(exist_ok=True)
    path = DOCS_DIR / filename
    path.write_text(content, encoding="utf-8")
    print(f"   ✓ Saved → docs/{filename}  ({len(content)/1024:.1f} KB)")


def agent_already_complete(agent: dict) -> bool:
    """Check if ALL output files for this agent already contain real content."""
    for filename in agent["save_as"]:
        path = DOCS_DIR / filename
        if not path.exists():
            return False
        if path.stat().st_size < MIN_COMPLETE_SIZE:
            return False
        content = path.read_text(encoding="utf-8").strip()
        if content.startswith("<!-- Placeholder"):
            return False
    return True


# —— Template / Skeleton mapping for each agent ——————————————————————————————
# Maps agent numbers to their corresponding template and skeleton files.
AGENT_TEMPLATES = {
    2: "project-info-page-template.yaml",
    3: "project-outline-template.yaml",
    4: "work-packages-template.yaml",
    5: "budget-calculation-template.yaml",
}
AGENT_SKELETONS = {
    2: "example-project-info-page.md",
    4: "example-work-package.md",
    5: "example-budget-excerpt.md",
}


def run_agent(agent: dict, call_text: str):
    print(f"\n{'─'*64}")
    print(f"  Agent {agent['number']}/6 — {agent['name']}")
    print(f"  Activation: {agent['activation']}")
    print(f"{'─'*64}")

    docs_context = read_existing_docs()

    # Load template and skeleton for this agent (if any)
    template_file = AGENT_TEMPLATES.get(agent["number"])
    skeleton_file = AGENT_SKELETONS.get(agent["number"])
    template_text = read_file_safe(TEMPLATES_DIR / template_file) if template_file else ""
    skeleton_text = read_file_safe(SKELETONS_DIR / skeleton_file) if skeleton_file else ""

    user_msg = (
        "=== FUNDING CALL DOCUMENT ===\n"
        f"{call_text}\n\n"
        "=== AGENT ROLE AND INSTRUCTIONS ===\n"
        f"{agent['instructions']}\n\n"
    )

    if template_text.strip():
        user_msg += "=== OUTPUT STRUCTURE TEMPLATE ===\n"
        user_msg += template_text + "\n\n"

    if skeleton_text.strip():
        user_msg += "=== QUALITY REFERENCE EXAMPLE ===\n"
        user_msg += skeleton_text + "\n\n"

    if docs_context.strip():
        user_msg += "=== PREVIOUS AGENT OUTPUTS (read these before producing your output) ===\n"
        user_msg += docs_context + "\n\n"

    user_msg += (
        f"{agent['activation']}\n\n"
        "Now produce your output IN FULL. "
        "Wrap each document in the required ---START/END--- markers.\n"
        f"Expected output files: {', '.join(agent['output_keys'])}"
    )

    print(f"   🤖 Querying model (num_ctx={NUM_CTX}, no timeout — will run until complete)...")
    try:
        response = ollama.chat(
            model=MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": user_msg},
            ],
            options={"num_ctx": NUM_CTX},
        )
        raw = response["message"]["content"]
    except KeyboardInterrupt:
        print("\n⚠️   Interrupted by user. Partial output will NOT be saved.")
        print(f"   Resume later with:  python mega_proposal_runner.py --from {agent['number']}")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌  Ollama error: {e}")
        print(f"   Make sure Ollama is running: ollama serve")
        print(f"   Resume later with:  python mega_proposal_runner.py --from {agent['number']}")
        sys.exit(1)

    # Save each output file (with validation)
    all_valid = True
    for key, filename in zip(agent["output_keys"], agent["save_as"]):
        content = extract_block(raw, key)
        if not validate_output(content, agent["name"]):
            all_valid = False
            # Save anyway but with a marker so it can be detected
            content = f"<!-- FAILED: Model did not produce valid output -->\n{content}"
        save_doc(filename, content)

    if all_valid:
        print(f"   ✅  {agent['name']} complete.")
    else:
        print(f"\n   🔴  {agent['name']} produced INVALID output.")
        print(f"       The saved files contain the model's refusal, not proposal content.")
        print(f"       Action: Change MODEL to a general-purpose model and re-run with --force")
        print(f"       Recommended models: mistral, llama3.2, deepseek-r1:latest, qwen2.5")


def parse_args():
    p = argparse.ArgumentParser(
        description="Mega Proposal Runner — All 6 Agents in One File"
    )
    g = p.add_mutually_exclusive_group()
    g.add_argument("--agent", type=int, metavar="N",
                   help="Run only agent N (1–6)")
    g.add_argument("--from",  type=int, metavar="N", dest="from_agent",
                   help="Run from agent N onwards (e.g. --from 3 runs agents 3–6)")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Skip confirmation prompts, run all automatically")
    p.add_argument("--force", action="store_true",
                   help="Re-run agents even if their output files already exist")
    return p.parse_args()


def main():
    args = parse_args()

    # Check dependencies now (after argparse, so --help works without packages)
    check_dependencies()

    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║       MEGA PROPOSAL RUNNER — Project Proposal Workflow      ║")
    print(f"║       Model: {MODEL:<49}║")
    print("╚══════════════════════════════════════════════════════════════╝")

    # Find call PDF
    pdfs = list(CALL_DIR.glob("*.pdf"))
    if not pdfs:
        print(f"\n❌  No PDF in call/  →  Add your funding call PDF to: {CALL_DIR}")
        sys.exit(1)
    pdf_path = pdfs[0]
    if len(pdfs) > 1:
        print(f"\n⚠️   Multiple PDFs found. Using: {pdf_path.name}")

    print(f"\n📂  Call document: {pdf_path.name}")
    call_text = read_pdf(pdf_path)

    # Decide which agents to run
    if args.agent:
        agents_to_run = [a for a in AGENTS if a["number"] == args.agent]
        if not agents_to_run:
            print(f"❌  No agent with number {args.agent}"); sys.exit(1)
    elif args.from_agent:
        agents_to_run = [a for a in AGENTS if a["number"] >= args.from_agent]
    else:
        agents_to_run = AGENTS

    total = len(agents_to_run)
    print(f"\n🚀  Running {total} agent(s): "
          + ", ".join(f"Agent {a['number']}" for a in agents_to_run))

    for i, agent in enumerate(agents_to_run, 1):
        # —— Auto-skip agents that already have complete output ——
        if not args.force and agent_already_complete(agent):
            existing = ", ".join(f"docs/{f}" for f in agent["save_as"])
            print(f"\n   ⏭ Agent {agent['number']} — {agent['name']}")
            print(f"      Already complete: {existing}")
            print(f"      (use --force to regenerate)")
            continue

        run_agent(agent, call_text)

        if i < total and not args.yes:
            nxt = agents_to_run[i]
            print(f"\n   Next: Agent {nxt['number']} — {nxt['name']}")
            choice = input("   Continue? [Enter = yes / q = quit]: ").strip().lower()
            if choice == "q":
                print("\n⏸   Paused after Agent", agent["number"])
                print(f"   Resume later with:  python mega_proposal_runner.py --from {agent['number']+1}")
                sys.exit(0)

    print()
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║                  ✅  ALL AGENTS COMPLETE                    ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print()
    print("  Output files in docs/:")
    for f in sorted(DOCS_DIR.glob("*.md")):
        if f.stat().st_size > 0:
            print(f"    ✓  docs/{f.name}  ({f.stat().st_size/1024:.1f} KB)")
    print()
    print("  Tip: Open each .md file in VS Code to review and edit.")
    print("  Tip: Run --agent 6 for a final consistency review.")
    print()


if __name__ == "__main__":
    main()
